import { of } from 'rxjs';

var close = "Schließen";
var varList = {
	base: "Basisvariablen",
	derived: "Abgeleitete Variablen",
	add: "Abgeleitete Variable hinzufügen",
	"delete": "Variable(n) löschen",
	rename: "Variable umbenennen",
	"load-save-user-role": "Laden / Speichern / NutzerRechte festlegen",
	"load-variables": "Variablenliste laden",
	"load-coding-scheme": "Antwortschema laden",
	"save-coding-scheme": "Antwortschema speichern",
	role: {
		ro: "Rolle: Nur lesen",
		"rw-minimal": "Rolle: RW minimal",
		"rw-maximal": "Rolle: RW maximal"
	},
	"more-actions": "Weitere Aktionen",
	info: "Info",
	copy: "Kodierung kopieren",
	"copy-code": "Code kopieren",
	"paste-code": "Code einfügen",
	check: "Prüfe Syntax Kodierschema",
	show: "Zeige Kodierschema",
	"activate-base-no-value": "Aktiviere Basisvariable ohne Wert",
	"export-variable": "Variable exportieren",
	"import-variable": "Variable importieren",
	"derived-tree": {
		title: "Ableitungen Liste",
		error: "Darstellung nicht möglich: Zirkelbezug",
		"no-sources": "(Keine Quellen)"
	}
};
var schemer = {
	info: {
		title: "Schemer – Informationen",
		intro: "Der Schemer dient zum Erstellen und Bearbeiten von Kodierschemata für Variablen.",
		"feature-base-title": "Basisvariablen",
		"feature-base-desc": "bilden die Grundlage der Kodierung.",
		"feature-derived-title": "Abgeleitete Variablen",
		"feature-derived-desc": "können Werte aus anderen Variablen übernehmen oder berechnen.",
		"version-text": "Das Kodierschema wird im Format '@iqbspecs/coding-scheme' erzeugt und beim Export immer mit der Version {{major}}.{{minor}} versehen.",
		"compatibility-hint": "Beim Laden älterer Dateien (ohne Versionsfeld oder mit älterer Version) werden die Kodierungen übernommen und beim nächsten Speichern/Export im aktuellen Format ({{major}}.{{minor}}) ausgegeben."
	},
	"version-mismatch": {
		title: "Achtung: Abweichende Daten-Version",
		content: "Sie haben eine abweichende Daten-Version des Kodierschemas geladen: {{mismatch}}.\nNach dem Speichern ist das Schema auf die Version {{major}}.{{minor}} geändert.",
		"minor-greater": "Größere Nebenversion",
		"major-greater": "Größere Hauptversion",
		"major-less": "Geringere Hauptversion"
	},
	"export": {
		title: "Variable exportieren",
		"no-scheme": "Kein Antwortschema bzw. keine Variablen vorhanden.",
		select: {
			title: "Variable exportieren",
			prompt: "Bitte Variable auswählen",
			ok: "Export"
		}
	},
	"import": {
		title: "Variable importieren",
		"no-scheme": "Kein Antwortschema geladen.",
		"invalid-format": "Ungültiges Import-Format.",
		"missing-id": "Import enthält keine Variable-ID.",
		"invalid-identifiers": "Import enthält ungültige oder nicht eindeutige Variablenbezeichner.",
		overwrite: {
			title: "Variable überschreiben?",
			content: "Die Variable '{{variable}}' existiert bereits. Überschreiben?",
			confirm: "Überschreiben"
		},
		error: {
			title: "Variable importieren - Fehler",
			unknown: "Unbekannter Fehler beim Import."
		}
	},
	add: {
		error: {
			title: "Neue Variable - Fehler"
		}
	},
	"delete": {
		title: "Variable/Kodierung löschen",
		prompt: "Abgeleitete Variablen oder verwaiste Basisvariablen werden komplett gelöscht. Bei Basisvariablen wird die Kodierung gelöscht.",
		ok: "Löschen"
	},
	rename: {
		title: "Variable umbenennen",
		prompt: "Bitte neue Kennung der Variablen '{{variable}}' eingeben.",
		placeholder: "Variablen-Kennung",
		save: "Speichern",
		"select-derived-first": "Bitte erst eine abgeleitete Variable auswählen!",
		error: {
			title: "Variable umbenennen - Fehler"
		}
	},
	"activate-base-no-value": {
		title: "Basisvariable ohne Wert aktivieren",
		prompt: "Bitte Variable wählen!",
		ok: "Aktivieren"
	},
	copy: {
		title: "Kodierung von \"{{variable}}\" kopieren",
		prompt: "Die Kodierung der Zielvariable(n) wird überschrieben!",
		ok: "Kopieren"
	}
};
var coding = {
	id: "Variable",
	status: "Status",
	value: "Wert",
	code: "Code",
	score: "Bewertung",
	rule: "Regel",
	"vars-with-codes-only": "Nur Variablen mit Codes",
	"raw-responses": "Rohantworten anzeigen",
	transformed: "Transformiert",
	"transformed-values": "Transformierte Werte (Fragmentierung)",
	"transformed-values-unavailable": "Transformierte Werte sind nicht verfügbar, weil keine Variablenkodierungen übergeben wurden.",
	instruction: "Instruktion",
	variable: "Variable",
	result: "Ergebnis",
	state: "Status",
	subform: "Unterform",
	"result-header": "Antworten nach der Kodierung",
	generate: {
		"dialog-title": "Variableninformation / Kodierung generieren: Variable",
		title: "Vorschlag für Generieren des Kodierschemas:",
		"no-var-info": "Für diese Variable ist keine Variableninformation verfügbar.",
		model: {
			none: "Für diese Variable konnte kein Vorschlag zur Kodierung ermittelt werden.",
			"single-choice-some": "Bitte wählen Sie den Wert für 'Richtig':",
			"single-choice-long-version": "Langformat",
			"single-choice-short-version-text": "Es wird ein Code für die richtige Option erzeugt sowie ein zweiter Code für alle anderen Antwortwerte.",
			"single-choice-long-version-text": "Für jede Option wird ein Code erzeugt und zusätzlich ein Fehler für einen ungültigen Wert.",
			"single-choice-many": "Bitte wählen Sie den Wert für 'Richtig':",
			"new-coding-choice-no-selection": "Zwei Codes werden erzeugt (richtig und falsch). Bitte geben Sie nach der Erzeugung den richtigen Wert ein!",
			"multi-choice": "Bitte wählen Sie den Wert bzw. die Werte für 'Richtig':",
			"multi-choice-order-prompt": "Ist die Reihenfolge wichtig?",
			"multi-choice-drag-prompt": "Bitte ziehen Sie die gewünschten Werte in die gewünschte Position (beachten Sie, dass die Reihenfolge jetzt eine Rolle spielt):",
			"multi-choice-yes": "Die Reihenfolge der Werte in der Liste entspricht der Reihenfolge in den Werte-Positionen.",
			"multi-choice-no": "Die Reihenfolge der Werte in der Liste spielt keine Rolle.",
			"boolean-multi": "Hotspot-Auswahl pro Bereich (Ja/Nein)",
			integer: "Ein Code wird erzeugt für numerische Regeln.",
			"simple-input": "Ein Code wird erzeugt für einen Textinput.",
			"simple-input-not-numeric": "Text input wird als Text interpretiert (ggf. auch mehrere Zeilen, eine Zeile pro Wert).",
			"simple-input-numeric": "Soll der Textinput als Zahl interpretiert werden? (eine Zeile für einen Wert, neue Zeile für weiteren Wert):",
			"geogebra-boolean": "GeoGebra-Wert wird als Wahr/Falsch-Wert kodiert.",
			"math-table": "Rechenkästchen: Es wird eine Kodierstruktur für das strukturierte Antwortformat erzeugt."
		},
		geogebra: {
			"extract-value": "GeoGebra-Wert hinter '=' kodieren",
			"mode-prompt": "Wie soll der GeoGebra-Wert kodiert werden?",
			"mode-numeric": "Zahl",
			"mode-angle": "Winkel",
			"mode-point": "Punkt",
			"mode-boolean": "Wahr/Falsch",
			"mode-text": "Text",
			"boolean-prompt": "Welcher Wert ist richtig?",
			"point-x": "x-Koordinate",
			"point-y": "y-Koordinate"
		},
		"math-table": {
			"mode-prompt": "Welche Kodierstruktur soll erzeugt werden?",
			"mode-result-auto": "Ergebniszeile automatisch prüfen",
			"mode-manual": "Rechenweg manuell prüfen",
			"expected-result": "Erwartetes Ergebnis",
			"expected-result-hint": "Der Wert wird mit der Ergebniszeile des Rechenkästchens verglichen."
		},
		"else-method": {
			prompt: "Methode für Abschluss",
			auto: "Alle anderen - Automatisch",
			instruction: "Alle anderen - Manuell",
			none: "kein Abschluss"
		},
		"lower-limit": "Untere Grenze",
		"upper-limit": "Obere Grenze",
		warning: "Achtung: Sollten Kodierinformationen bereits vorhanden sein, werden diese gelöscht.",
		"true-code": "Wert für 'Richtig'-Code",
		"empty-value": "Bitte Wert eintragen",
		"only-one-lower-limit": "Bitte nur einen Wert für untere Grenze eintragen",
		"only-one-upper-limit": "Bitte nur einen Wert für obere Grenze eintragen",
		action: "Generiere Kodierung"
	}
};
var id = "ID";
var page = "Seite";
var click = {
	"coding-as-text": "Kodierung als Text",
	"smart-schemer": "Variableninformation / Kodierung generieren",
	"deactivate-base-var": "Variable deaktivieren"
};
var processing = {
	label: "Allgemeine Parameter für die Verarbeitung der Antwort",
	prompt: "Antwortverarbeitung und Fragmente",
	IGNORE_CASE: "Groß-/Kleinschreibung ignorieren",
	IGNORE_ALL_SPACES: "Alle Leerzeichen entfernen",
	IGNORE_DISPENSABLE_SPACES: "Doppelte Leerzeichen entfernen",
	SORT_ARRAY: "Werte sortieren",
	REPLAY_REQUIRED: "Für Kodierung komplette Unit-Ansicht erforderlich (Replay)",
	ATTACHMENT: "Für Kodierung separate Datei erforderlich (Bild, Audio)",
	CODER_TRAINING_REQUIRED: "Erhöhter Schulungsaufwand"
};
var fragmenting = {
	prompt: "Fragment(e)",
	tooltip: "Regulärer Ausdruck, um Teile der Antwort zu extrahieren"
};
var code = {
	header: "Codes",
	prompt: {
		add: "Code hinzufügen",
		"add-NO_CREDIT": "Falsch-Code",
		"add-FULL_CREDIT": "Richtig-Code",
		"add-PARTIAL_CREDIT": "Teilweise Richtig-Code",
		"add-RESIDUAL": "Falsch: Alle anderen Antworten",
		"add-RESIDUAL_AUTO": "Falsch: Alle anderen Antworten - AUTOMATISCH",
		"add-TO_CHECK": "Code 'zu prüfen'",
		"add-INTENDED_INCOMPLETE": "Absichtlich unvollständig",
		"add-UNSET": "Code universell",
		"add-is-empty": "Code für 'leere Antwort' hinzufügen",
		"add-is-null": "Code für 'Null-Wert' hinzufügen",
		"delete": "Code löschen",
		"auto-coding": "Regeln für automatisches Kodieren",
		sort: "Codes numerisch sortieren"
	},
	"type-label": {
		NO_CREDIT: "falsch",
		FULL_CREDIT: "richtig",
		PARTIAL_CREDIT: "teilweise richtig",
		INTENDED_INCOMPLETE: "Kodierung soll unvollständig sein",
		RESIDUAL: "falsch",
		RESIDUAL_AUTO: "falsch - AUTOMATISCH",
		TO_CHECK: "zu prüfen",
		UNSET: "-"
	},
	"error-message": {
		"residual-exists": "Es existiert bereits ein Code für 'Alle anderen Antworten'.",
		"nothing-to-paste": "Es wurde kein Code kopiert.",
		"fatal-error": "Ein schwerer Fehler ist aufgetreten",
		"type-not-supported": "Der Code-Typ wird nicht unterstützt.",
		"no-access": "Es fehlen für diese Aktion die Zugriffsrechte."
	},
	"paste-warning": {
		title: "Code einfügen?",
		content: "Der kopierte Code passt möglicherweise nicht vollständig zur Zielvariable. Nach dem Einfügen sollte die Kodierung geprüft werden.",
		confirm: "Trotzdem einfügen",
		"array-reference": "Der Code enthält Positionsbezüge für Mehrfachantworten.",
		"fragment-reference": "Der Code enthält Fragmentbezüge.",
		"numeric-rule": "Der Code enthält numerische Regeln.",
		"boolean-rule": "Der Code enthält Wahr/Falsch-Regeln."
	},
	"post-paste-validation": {
		title: "Code eingefügt",
		content: "Der Code wurde eingefügt, die Zielkodierung enthält dadurch neue Validierungsprobleme:"
	},
	"no-codes": "Derzeit sind keine Codes definiert.",
	"is-invalid": "Kein Code wird vergeben, sondern Status 'ungültig'/'INVALID'.",
	"make-invalid": "Schalte Wert ungültig",
	"make-not-invalid": "Schalte Wert gültig",
	id: "Code",
	description: "Code-Titel",
	score: "Bewertung",
	"has-rule-warning": {
		autocode: "Dieser Code enthält Regeln für das automatische Kodieren.",
		manual: "Dieser Code enthält Instruktionen für das manuelle Kodieren.",
		"manual-else": "Dieser Code enthält Instruktionen für das manuelle Kodieren. Durch die Regel 'Alle anderen Antworten' werden aber alle Fälle automatisch abschließend kodiert."
	},
	type: {
		label: "Code-Typ",
		UNSET: "-",
		FULL_CREDIT: "richtig",
		PARTIAL_CREDIT: "teilweise richtig",
		NO_CREDIT: "falsch",
		RESIDUAL: "Alle anderen Antworten (manuell)",
		RESIDUAL_AUTO: "Alle anderen Antworten (automatisch)"
	}
};
var rule = {
	prompt: {
		add: "Regel hinzufügen",
		"add-alternate": "Alternative Regel hinzufügen",
		"delete": "Regel löschen",
		change: "Regel ändern",
		"add-parameter": "Regel-Parameter hinzufügen",
		"delete-parameter": "Regel-Parameter löschen",
		operator: "Verknüpfung der Regeln"
	},
	"no-rules": "Keine Regeln gesetzt.",
	"no-ruleset": "Kein Regelsatz angelegt.",
	"group-string": "Zeichen/Text",
	"group-numeric": "Numerisch",
	"group-logic": "Logisch",
	MATCH: "Übereinstimmung",
	"MATCH.description": "Es wird Zeichen/Text auf Übereinstimmung geprüft.",
	MATCH_REGEX: "Regulärer Ausdruck",
	"MATCH_REGEX.description": "Zur Prüfung wird ein regulärer Ausdruck verwendet.",
	NUMERIC_MATCH: "Übereinstimmung",
	"NUMERIC_MATCH.description": "Es wird auf genaue Übereinstimmung mit einer Zahl geprüft.",
	NUMERIC_RANGE: "Veraltete Bereichsregel gesetzt, aktuelle im Menü auswählen! ",
	"NUMERIC_RANGE.description": "",
	NUMERIC_FULL_RANGE: "Bereich",
	"NUMERIC_FULL_RANGE.description": "Der zu prüfende Wert muss gleich oder größer als der erste Wert sein und gleich oder kleiner als der zweite Wert.",
	NUMERIC_LESS_THAN: "Kleiner als",
	"NUMERIC_LESS_THAN.description": "Der zu prüfende Wert muss kleiner als dieser Wert sein.",
	NUMERIC_MORE_THAN: "Größer als",
	"NUMERIC_MORE_THAN.description": "Der zu prüfende Wert muss größer als dieser Wert sein.",
	NUMERIC_MAX: "Kleiner gleich",
	"NUMERIC_MAX.description": "Der zu prüfende Wert muss kleiner gleich als dieser Wert sein.",
	NUMERIC_MIN: "Größer gleich",
	"NUMERIC_MIN.description": "Der zu prüfende Wert muss größer gleich als dieser Wert sein.",
	NO_OTHER_MATCHES: "Keine anderen Übereinstimmungen",
	"NO_OTHER_MATCHES.description": "Es sind keine weiteren Werte erlaubt außer die in Übereinstimmungen genannten (wenn Array-/Liste).",
	IS_EMPTY: "Leere Eingabe",
	"IS_EMPTY.description": "Dieser Code wird gesetzt, wenn ein leerer Wert besondere Behandlung erfordert (Standard: Status 'ungültig').",
	IS_NULL: "Technisch 'null'",
	"IS_NULL.description": "Einige Elemente können als Wert auch dieses 'null' liefern und zeigen damit einen bestimmten Zustand an.",
	IS_TRUE: "Wahr",
	"IS_TRUE.description": "Der zu prüfende Wert muss 'WAHR' sein.",
	IS_FALSE: "Falsch",
	"IS_FALSE.description": "Der zu prüfende Wert muss 'FALSCH' sein.",
	"operator.true": "UND",
	"operator.false": "ODER",
	"info-choice-operator": "Die Regeln sind mit UND verknüpft",
	"info-choice-operator-error": "Fehler: Die Regeln sind mit ODER verknüpft",
	reference: {
		label: "Fragment",
		title: "Fragment ändern",
		prompt: "Diese Regel bezieht sich auf irgendein Fragment oder auf ein spezifisches.",
		any: "Irgendeines",
		specific: "Spezielles"
	}
};
var deTranslations = {
	close: close,
	"filter-by": "Filtern nach...",
	"copied-to-clipboard": "In Zwischenablage kopiert",
	varList: varList,
	schemer: schemer,
	"message-dialog": {
	"default-title": {
		error: "Achtung: Fehler",
		warning: "Achtung: Warnung",
		info: "Hinweis"
	}
},
	"status-label": {
	NO_CODING: "Keine Kodierung vorhanden",
	INVALID: "Ungültiger Antwortwert",
	CODING_INCOMPLETE: "Kodierung unvollständig",
	CODING_ERROR: "Kodierfehler",
	CODING_COMPLETE: "Ein Code wurde zugewiesen",
	SOURCE_MISSING: "Mindestens eine der Quell Variablen fehlt oder besitzt ungültigen Status",
	DERIVE_ERROR: "Fehler bei der Ableitung",
	VALUE_DERIVED: "Wert erfolgreich ermittelt",
	UNSET: "Neue Variable",
	NOT_REACHED: "Noch keine Interaktion möglich",
	DISPLAYED: "Wurde angezeigt",
	VALUE_CHANGED: "Wert geändert"
},
	coding: coding,
	"dialog-close": "Schließen",
	"dialog-save": "Speichern",
	"dialog-cancel": "Abbrechen",
	"dialog-empty": "Alles löschen",
	"dialog-no-variables": "Keine Variablen vorhanden!",
	"data-error": {
	"invalid-format": "Dieses Datenformat kann nicht verarbeitet werden.",
	"base-variables-missing": "Es sind keine Basis-Variablen definiert. Bitte gehen Sie zum Editor, um Elemente zu definieren, die Antworten erzeugen. Eventuell ist der verwendete Editor veraltet.",
	"variable-id": {
		double: "Diese Variablenkennung existiert bereits. In einem Kodierschema darf eine Variablenkennung nur einmal verwendet werden. Groß- oder Kleinschreibung zählt hierbei nicht.",
		character: "Eine Variablenkennung muss mindestens ein Zeichen enthalten und darf nur ASCII-Buchstaben, Ziffern sowie die Zeichen '_' und '-' verwenden. Umlaute, Leerzeichen und weitere Sonderzeichen sind nicht zulässig."
	}
},
	"coding-status": {
	WARNING: "Warnungen (können ignoriert werden)",
	ERROR: "Probleme, die das Kodieren verhindern",
	OK: "Keine Probleme"
},
	"show-coding": {
	"simple-mode-label": "Verkürzter Text-Modus"
},
	id: id,
	"description-position": "Position/Zuordnung",
	page: page,
	"page.tooltip": "Seitenzahl der Variable im Test",
	"code-model": {
	prompt: "Anzeige Code",
	NONE: "Regeln und Instruktionen",
	MANUAL_AND_RULES: "Regeln und Instruktionen",
	RULES_ONLY: "Nur Regeln",
	MANUAL_ONLY: "Nur Instruktionen"
},
	click: click,
	"code-model-parameter": {
	"max-score": "Maximale Bewertung"
},
	"derive-sources": {
	label: "Quell-Variable(n)",
	prompt: "Quell-Variable(n)",
	error: "Keine Quelle definiert."
},
	"derive-method": {
	label: "Ableitungsmethode",
	prompt: "Ableitungsmethode",
	BASE: "Basisvariable",
	COPY_VALUE: "Wert kopieren",
	CONCAT_CODE: "Codes aneinanderhängen",
	SUM_CODE: "Codes summieren",
	SUM_SCORE: "Bewertung summieren",
	UNIQUE_VALUES: "Auf Einzigartigkeit prüfen",
	SOLVER: "Mathematischer Ausdruck (Solver)",
	MANUAL: "Manuell"
},
	"derive-processing": {
	prompt: "Basis-/Ableitungsparameter",
	TO_LOWER_CASE: "In Kleinbuchstaben umwandeln",
	TO_NUMBER: "In Zahl umwandeln",
	REMOVE_ALL_SPACES: "Alle Leerzeichen entfernen",
	REMOVE_DISPENSABLE_SPACES: "Überflüssige Leerzeichen entfernen",
	TAKE_DISPLAYED_AS_VALUE_CHANGED: "Angezeigt = Wert geändert",
	TAKE_NOT_REACHED_AS_VALUE_CHANGED: "Nicht erreicht = Wert geändert",
	TAKE_EMPTY_AS_VALID: "Leerer Antwortwert ist gültig",
	SORT: "Sortiere Werte",
	SOLVER_EXPRESSION: "Ausdruck für Solver",
	"solver-source-warning": {
		"unselected-sources": "Warnung: Im Solver-Ausdruck referenzierte Variable(n) sind nicht als Quell-Variable(n) ausgewählt"
	},
	"solver-insert-source": {
		label: "Quellvariable einfügen"
	},
	"solver-test": {
		title: "Solver-Test",
		action: "Testen",
		result: "Ergebnis",
		"no-sources": "Keine Quellvariable ausgewählt.",
		"error-expression-missing": "Bitte einen Solver-Ausdruck eingeben.",
		"error-sources-missing": "Bitte mindestens eine Quellvariable auswählen.",
		"error-unselected-source": "Der Ausdruck verweist auf nicht ausgewählte Quelle(n)",
		"error-invalid-value": "Bitte numerischen Testwert prüfen",
		"error-evaluation": "Der Ausdruck konnte nicht ausgewertet werden. Bitte Syntax, Variablennamen und numerische Testwerte prüfen."
	},
	"solver-help": {
		title: "Syntaxhilfe für Solver-Ausdrücke",
		description: "Solver-Ausdrücke werden mit math.js ausgewertet. Verwenden Sie Zahlen, Rechenzeichen und math.js-Funktionen; Quellvariablen referenzieren Sie mit ${Variablenname} oder ${VariablenID}.",
		"policy-description": "Optional kann ein Fragmentindex sowie das Verhalten bei leeren und nicht-numerischen Werten angegeben werden. Mögliche Regeln sind INC, ERROR oder ein numerischer Ersatzwert; ohne Angabe gilt ERROR.",
		"examples-title": "Beispiele:",
		examples: {
			arithmetic: "einfache Rechenoperationen",
			variables: "Werte aus zwei Quellvariablen addieren",
			"function": "Prozentwert berechnen und runden",
			condition: "Bedingung: Ergebnis ist 1, wenn Punkte mindestens 5 sind, sonst 0",
			fragment: "Zähler (Fragment 0) eines Bruchs verwenden; bei leerem Wert unvollständig, bei nicht-numerischem Wert Fehler (entspricht ${Bruch[0]:INC:ERROR})",
			policies: "Summand verwenden; leeren Wert durch 0 ersetzen, bei nicht-numerischem Wert unvollständig"
		},
		"docs-link": "math.js-Syntax öffnen"
	}
},
	processing: processing,
	fragmenting: fragmenting,
	"manual-instruction": {
	code: {
		title: "Instruktionen für manuelles Kodieren",
		"prompt-edit": "Instruktionen für manuelles Kodieren ändern",
		wipe: "Instruktionen komplett löschen",
		"error-residual-auto": "Im normalen automatischen Fall für 'Alle anderen Antworten' werden manuelle Instruktionen nicht genutzt.",
		"error-intended-incomplete": "Wenn ein automatischer Code für 'Absichtlich unvollständig' definiert ist, werden manuelle Instruktionen nie genutzt."
	},
	coding: {
		title: "Allgemeine Hinweise",
		"prompt-edit": "Allgemeine Hinweise ändern",
		wipe: "Allgemeine Hinweise komplett löschen",
		source: "Quelle"
	}
},
	code: code,
	"rule-set": {
	prompt: {
		add: "Regelsatz hinzufügen",
		"delete": "Regelsatz löschen",
		operator: "Verknüpfung der Regelsätze"
	},
	"delete-error": "Es muss mindestens ein Regelsatz vorhanden sein",
	reference: {
		label: "Position im Werte-Array",
		title: "Position im Werte-Array ändern",
		prompt: "Die Regeln dieses Regelsatzes beziehen sich auf ein Werte-Array insgesamt (Summe, Länge), auf irgendeinen Wert oder auf einen spezifischen.",
		any: "Irgendeine - Strikt",
		"any-open": "Irgendeine - Offen",
		sum: "Summe",
		length: "Länge",
		specific: "Spezielle"
	}
},
	rule: rule,
	"coding-problem": {
	VACANT: "Ohne Codes und nicht abgeleitet. (Wert kopiert)",
	RULE_PARAMETER_COUNT_MISMATCH: "Anzahl der Code-Parameter ungültig.",
	SOURCE_MISSING: "Quelle nicht gefunden. (Basisvariable nicht in Definition oder Ableitung ohne Quelle)",
	INVALID_SOURCE: "Ungültige Quelle.",
	RULE_REGEX_INVALID: "Ungültiger regulärer Ausdruck in der Regel.",
	RULE_PARAMETER_INVALID: "Ungültiger Parameter in der Regel.",
	RULE_NUMERIC_RANGE_INVALID: "Ungültiger numerischer Bereich in der Regel.",
	RULESET_VALUE_ARRAY_POS_INVALID: "Ungültige Position im Werte-Array im Regelsatz.",
	ONLY_ONE_SOURCE: "Eine Ableitung sollte mehr als eine Quelle haben.",
	VALUE_COPY_NOT_FROM_BASE: "Es wurde ein Wert kopiert, aber nicht von einer Basisvariablen.",
	MORE_THAN_ONE_SOURCE: "Es wurde ein Wert kopiert, aber es gibt mehr als eine Quelle.",
	CYCLIC_DERIVATION: "Zyklische Ableitung: Diese Variable ist Teil eines Ableitungszyklus."
}
};

const NGX_CODING_COMPONENTS_DE_TRANSLATIONS = deTranslations;
class NgxCodingComponentsTranslateLoader {
    // eslint-disable-next-line class-methods-use-this
    getTranslation() {
        return of(NGX_CODING_COMPONENTS_DE_TRANSLATIONS);
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { NGX_CODING_COMPONENTS_DE_TRANSLATIONS, NgxCodingComponentsTranslateLoader };
//# sourceMappingURL=iqb-ngx-coding-components-translations.mjs.map
