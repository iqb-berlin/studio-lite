import * as i0 from '@angular/core';
import { ViewChild, Inject, Component, Input, signal, Injectable, EventEmitter, Output, CUSTOM_ELEMENTS_SCHEMA, Pipe } from '@angular/core';
import * as i2$2 from '@angular/material/button';
import { MatButton, MatIconButton, MatButtonModule, MatFabButton } from '@angular/material/button';
import { MatInput } from '@angular/material/input';
import { MatLabel, MatFormField, MatHint, MatSuffix } from '@angular/material/form-field';
import { CodingSchemeFactory, ToTextFactory, CodingFactory as CodingFactory$1 } from '@iqb/responses';
import * as i4 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, MatDialogModule } from '@angular/material/dialog';
import { MatTableDataSource, MatTable, MatColumnDef, MatHeaderCellDef, MatRowDef, MatRow, MatCell, MatHeaderCell, MatHeaderRowDef, MatHeaderRow, MatCellDef } from '@angular/material/table';
import * as i1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { MatSort, MatSortHeader } from '@angular/material/sort';
import { transformValue } from '@iqb/responses/value-transform';
import { BehaviorSubject, debounceTime, firstValueFrom } from 'rxjs';
import { MatCard, MatCardContent, MatCardSubtitle } from '@angular/material/card';
import * as i3$1 from '@angular/material/tooltip';
import { MatTooltipModule, MatTooltip } from '@angular/material/tooltip';
import * as i3$2 from '@angular/material/icon';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatMenuTrigger, MatMenu, MatMenuItem } from '@angular/material/menu';
import * as i3 from '@angular/forms';
import { ReactiveFormsModule, FormsModule, FormControl } from '@angular/forms';
import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { MatDivider } from '@angular/material/divider';
import { CodingFactory } from '@iqb/responses/coding-factory';
import { moveItemInArray, transferArrayItem, CdkDropList, CdkDrag } from '@angular/cdk/drag-drop';
import { MatRadioGroup, MatRadioButton } from '@angular/material/radio';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { MatOption, MatRipple } from '@angular/material/core';
import { MatSelect, MatSelectTrigger, MatOption as MatOption$1 } from '@angular/material/select';
import { MatChip, MatChipRemove } from '@angular/material/chips';
import { MatSelectionList, MatListOption, MatActionList, MatListItem, MatNavList, MatDivider as MatDivider$1 } from '@angular/material/list';
import { MatCheckbox } from '@angular/material/checkbox';
import * as i2$1 from '@iqbspecs/coding-scheme';
import { RuleMethodParameterCount, DeriveConcatDelimiter, CodingSchemeVersionMajor, CodingSchemeVersionMinor, CodingScheme } from '@iqbspecs/coding-scheme';
import { Mark, mergeAttributes, Extension, Node, Editor } from '@tiptap/core';
import { Underline } from '@tiptap/extension-underline';
import { Superscript } from '@tiptap/extension-superscript';
import { Subscript } from '@tiptap/extension-subscript';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import { Highlight } from '@tiptap/extension-highlight';
import { TextAlign } from '@tiptap/extension-text-align';
import { Heading } from '@tiptap/extension-heading';
import { Blockquote } from '@tiptap/extension-blockquote';
import { Document } from '@tiptap/extension-document';
import { History } from '@tiptap/extension-history';
import { Text } from '@tiptap/extension-text';
import { ListItem } from '@tiptap/extension-list-item';
import { Bold } from '@tiptap/extension-bold';
import { Italic } from '@tiptap/extension-italic';
import { Strike } from '@tiptap/extension-strike';
import { TiptapEditorDirective } from 'ngx-tiptap';
import { TextSelection } from 'prosemirror-state';
import { Paragraph } from '@tiptap/extension-paragraph';
import { BulletList } from '@tiptap/extension-bullet-list';
import { OrderedList } from '@tiptap/extension-ordered-list';
import { Image } from '@tiptap/extension-image';
import { CdkOverlayOrigin, CdkConnectedOverlay } from '@angular/cdk/overlay';
import '@iqb/mathlive';
import katex from 'katex';
import * as i1$1 from '@angular/platform-browser';
import { Plugin } from '@tiptap/pm/state';
import { MatTabGroup } from '@angular/material/tabs';
import { KeyValuePipe, AsyncPipe } from '@angular/common';
import * as i2 from '@angular/cdk/clipboard';
import * as i3$3 from '@angular/material/snack-bar';
export { NGX_CODING_COMPONENTS_DE_TRANSLATIONS, NgxCodingComponentsTranslateLoader } from '@iqb/ngx-coding-components/translations';
import { createCustomElement } from '@angular/elements';

class ShowCodingResultsComponent {
    constructor(data) {
        this.data = data;
        this.dataSource = new MatTableDataSource();
        this.displayedColumns = ['id', 'value', 'status', 'code', 'score'];
        this.isLoading = false;
        this.codedVariablesOnly = true;
        this.rawResponsesView = false;
        this.transformedValueView = false;
        this.JSON = JSON;
    }
    get transformedValuesAvailable() {
        return Array.isArray(this.data.variableCodings) &&
            this.data.variableCodings.length > 0;
    }
    matSort(sort) {
        if (this.dataSource) {
            this.dataSource.sort = sort;
        }
    }
    ngOnInit() {
        if (this.data.responses &&
            this.data.responses.some(r => r.subform !== undefined)) {
            this.displayedColumns.unshift('subform');
        }
        this.rebuildTableData();
    }
    rebuildTableData() {
        const hasSubform = this.data.responses &&
            this.data.responses.some(r => r.subform !== undefined);
        const baseResponses = (this.data.responses || []).filter(r => !this.codedVariablesOnly || this.data.varsWithCodes.includes(r.id));
        this.dataSource.data = baseResponses.map(r => this.mapResponseToRow(r));
        const baseColumns = ['id', 'value', 'status', 'code', 'score'];
        this.displayedColumns = [...baseColumns];
        if (hasSubform) {
            this.displayedColumns.unshift('subform');
        }
        if (this.transformedValueView && this.transformedValuesAvailable) {
            this.displayedColumns.push('transformed');
        }
    }
    mapResponseToRow(r) {
        return {
            id: r.id,
            subform: r.subform,
            value: ShowCodingResultsComponent.stringifyValue(r.value),
            status: r.status,
            code: r.code,
            score: r.score,
            transformed: ShowCodingResultsComponent.stringifyValue(this.getTransformedValue(r))
        };
    }
    static stringifyValue(v) {
        if (typeof v === 'string')
            return v;
        if (v === null)
            return 'null';
        if (typeof v === 'undefined')
            return '';
        try {
            return JSON.stringify(v);
        }
        catch {
            return String(v);
        }
    }
    getTransformedValue(r) {
        const variableCodings = this.data.variableCodings || [];
        const vc = variableCodings.find(c => c.alias === r.id) ||
            variableCodings.find(c => c.id === r.id);
        if (!vc)
            return undefined;
        const sortArray = (vc.processing || []).includes('SORT_ARRAY');
        const fragmenting = vc.fragmenting || '';
        try {
            return this.transformValue(r.value, fragmenting, sortArray);
        }
        catch (e) {
            return {
                error: e instanceof Error ? e.message : String(e)
            };
        }
    }
    // eslint-disable-next-line class-methods-use-this
    transformValue(value, fragmenting, sortArray) {
        return transformValue(value, fragmenting, sortArray);
    }
    applyFilter(event) {
        const { target } = event;
        if (target) {
            const filterValue = target.value;
            this.dataSource.filter = filterValue.trim().toLowerCase();
        }
    }
    toggleChange(event) {
        if (event.source.name === 'rawResponsesView') {
            this.rawResponsesView = !this.rawResponsesView;
        }
        else if (event.source.name === 'codedVariablesOnly') {
            this.codedVariablesOnly = !this.codedVariablesOnly;
            this.rebuildTableData();
        }
        else if (event.source.name === 'transformedValueView') {
            if (!this.transformedValuesAvailable)
                return;
            this.transformedValueView = !this.transformedValueView;
            this.rebuildTableData();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingResultsComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ShowCodingResultsComponent, isStandalone: true, selector: "ng-component", viewQueries: [{ propertyName: "sort", first: true, predicate: MatSort, descendants: true }], ngImport: i0, template: `
    <div mat-dialog-title class="fx-column-start-start title">
      <span>{{ 'coding.result' | translate }}</span>
      <mat-form-field class="filter">
        <mat-label>{{ 'filter-by' | translate }}</mat-label>
        <input matInput (keyup)="applyFilter($event)" #input />
      </mat-form-field>
      <mat-slide-toggle
        class="toggle"
        name="codedVariablesOnly"
        [checked]="codedVariablesOnly"
        (change)="toggleChange($event)"
      >
        {{ 'coding.vars-with-codes-only' | translate }}
      </mat-slide-toggle>
      <mat-slide-toggle
        class="toggle"
        name="rawResponsesView"
        [checked]="rawResponsesView"
        (change)="toggleChange($event)"
      >
        {{ 'coding.raw-responses' | translate }}
      </mat-slide-toggle>
      <mat-slide-toggle
        class="toggle"
        name="transformedValueView"
        [checked]="transformedValueView"
        [disabled]="!transformedValuesAvailable"
        (change)="toggleChange($event)"
      >
        {{ 'coding.transformed-values' | translate }}
      </mat-slide-toggle>
      @if (!transformedValuesAvailable) {
      <span class="transformed-values-hint">
        {{ 'coding.transformed-values-unavailable' | translate }}
      </span>
      }
    </div>
    <mat-dialog-content>
      @if (isLoading) {
      <mat-spinner></mat-spinner>
      } @if (!isLoading) { @if(rawResponsesView){
      <pre style="white-space: wrap;">
            {{ JSON.stringify(this.dataSource.data) }}
          </pre
      >
      } @else {
      <table
        mat-table
        matSort
        matSortActive="id"
        matSortDirection="asc"
        (matSortChange)="matSort(sort)"
        [dataSource]="dataSource"
      >
        @for (column of displayedColumns; track column) {
        <ng-container [matColumnDef]="column">
          <th mat-header-cell *matHeaderCellDef mat-sort-header>
            {{
              column === 'transformed'
                ? ('coding.transformed' | translate)
                : ('coding.' + column | translate)
            }}
          </th>
          <td
            mat-cell
            [innerHTML]="element[column]"
            *matCellDef="let element"
          ></td>
        </ng-container>
        }
        <tr
          mat-header-row
          *matHeaderRowDef="displayedColumns; sticky: true"
        ></tr>
        <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
      </table>
      } }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">
        {{ 'close' | translate }}
      </button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".filter{width:100%;margin-top:10px}\n", ".toggle{margin-left:15px}\n", ".transformed-values-hint{display:block;margin-left:15px;font-size:12px}\n", ".title{display:inline!important}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "component", type: MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "component", type: MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "directive", type: MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: MatSort, selector: "[matSort]", inputs: ["matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear", "matSortDisabled"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "directive", type: MatCellDef, selector: "[matCellDef]" }, { kind: "component", type: MatSortHeader, selector: "[mat-sort-header]", inputs: ["mat-sort-header", "arrowPosition", "start", "disabled", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingResultsComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <div mat-dialog-title class="fx-column-start-start title">
      <span>{{ 'coding.result' | translate }}</span>
      <mat-form-field class="filter">
        <mat-label>{{ 'filter-by' | translate }}</mat-label>
        <input matInput (keyup)="applyFilter($event)" #input />
      </mat-form-field>
      <mat-slide-toggle
        class="toggle"
        name="codedVariablesOnly"
        [checked]="codedVariablesOnly"
        (change)="toggleChange($event)"
      >
        {{ 'coding.vars-with-codes-only' | translate }}
      </mat-slide-toggle>
      <mat-slide-toggle
        class="toggle"
        name="rawResponsesView"
        [checked]="rawResponsesView"
        (change)="toggleChange($event)"
      >
        {{ 'coding.raw-responses' | translate }}
      </mat-slide-toggle>
      <mat-slide-toggle
        class="toggle"
        name="transformedValueView"
        [checked]="transformedValueView"
        [disabled]="!transformedValuesAvailable"
        (change)="toggleChange($event)"
      >
        {{ 'coding.transformed-values' | translate }}
      </mat-slide-toggle>
      @if (!transformedValuesAvailable) {
      <span class="transformed-values-hint">
        {{ 'coding.transformed-values-unavailable' | translate }}
      </span>
      }
    </div>
    <mat-dialog-content>
      @if (isLoading) {
      <mat-spinner></mat-spinner>
      } @if (!isLoading) { @if(rawResponsesView){
      <pre style="white-space: wrap;">
            {{ JSON.stringify(this.dataSource.data) }}
          </pre
      >
      } @else {
      <table
        mat-table
        matSort
        matSortActive="id"
        matSortDirection="asc"
        (matSortChange)="matSort(sort)"
        [dataSource]="dataSource"
      >
        @for (column of displayedColumns; track column) {
        <ng-container [matColumnDef]="column">
          <th mat-header-cell *matHeaderCellDef mat-sort-header>
            {{
              column === 'transformed'
                ? ('coding.transformed' | translate)
                : ('coding.' + column | translate)
            }}
          </th>
          <td
            mat-cell
            [innerHTML]="element[column]"
            *matCellDef="let element"
          ></td>
        </ng-container>
        }
        <tr
          mat-header-row
          *matHeaderRowDef="displayedColumns; sticky: true"
        ></tr>
        <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
      </table>
      } }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">
        {{ 'close' | translate }}
      </button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule,
                        MatProgressSpinner,
                        MatSlideToggle,
                        MatLabel,
                        MatFormField,
                        MatTable,
                        MatColumnDef,
                        MatHeaderCellDef,
                        MatRowDef,
                        MatRow,
                        MatCell,
                        MatHeaderCell,
                        MatHeaderRowDef,
                        MatSort,
                        MatInput,
                        MatHeaderRow,
                        MatCellDef,
                        MatSortHeader
                    ], styles: [".filter{width:100%;margin-top:10px}\n", ".toggle{margin-left:15px}\n", ".transformed-values-hint{display:block;margin-left:15px;font-size:12px}\n", ".title{display:inline!important}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { sort: [{
                type: ViewChild,
                args: [MatSort]
            }] } });

class SchemeCheckerComponent {
    set codingScheme(value) {
        this.values = {};
        this._codingScheme = value;
        if (this._codingScheme) {
            this._codingScheme.variableCodings
                .filter(v => v.sourceType === 'BASE')
                .map(v => v.alias || v.id)
                .sort()
                // eslint-disable-next-line no-return-assign
                .forEach(v => (this.values[v] = ''));
        }
    }
    constructor(showCodingResultsDialog) {
        this.showCodingResultsDialog = showCodingResultsDialog;
        this.values = {};
        this._codingScheme = null;
        this.Object = Object;
        this.JSON = JSON;
    }
    static parseInputValue(raw) {
        const trimmed = (raw || '').trim();
        if (!trimmed)
            return '';
        if (trimmed.startsWith('[')) {
            try {
                const parsed = JSON.parse(trimmed);
                if (Array.isArray(parsed)) {
                    return parsed;
                }
            }
            catch {
                // fall back to string
            }
        }
        return trimmed;
    }
    updateInputValue(sourceElement, targetVariable) {
        if (sourceElement)
            this.values[targetVariable] = sourceElement.value;
    }
    startEvaluation() {
        if (this._codingScheme) {
            const myValues = [];
            this._codingScheme.variableCodings.forEach(cs => {
                if (this.values[cs.alias || cs.id]) {
                    myValues.push({
                        id: cs.id,
                        value: SchemeCheckerComponent.parseInputValue(this.values[cs.alias || cs.id]),
                        status: 'VALUE_CHANGED'
                    });
                }
                else if (cs.sourceType === 'BASE') {
                    myValues.push({
                        id: cs.id,
                        value: '',
                        status: 'DISPLAYED'
                    });
                }
            });
            const varsWithCodes = this._codingScheme.variableCodings
                .filter(v => v.codes && v.codes.length > 0)
                .map(v => v.alias || v.id);
            this.showCodingResultsDialog.open(ShowCodingResultsComponent, {
                width: '800px',
                height: '600px',
                data: {
                    responses: CodingSchemeFactory.code(myValues, this._codingScheme.variableCodings),
                    varsWithCodes: varsWithCodes,
                    variableCodings: this._codingScheme.variableCodings
                }
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemeCheckerComponent, deps: [{ token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SchemeCheckerComponent, isStandalone: true, selector: "scheme-checker", inputs: { codingScheme: "codingScheme" }, ngImport: i0, template: "<div class=\"check-host\">\n  @for (baseVar of Object.keys(values); track baseVar) {\n    <div class=\"check-element\"\n      >\n      <mat-form-field>\n        <mat-label >{{baseVar}}</mat-label>\n        <input matInput (change)=\"updateInputValue($event.target, baseVar)\">\n      </mat-form-field>\n    </div>\n  }\n  <button mat-raised-button (click)=\"startEvaluation()\">Start</button>\n</div>\n", styles: [".check-host{padding:20px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:flex-start;align-items:center}.check-element{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:center}\n"], dependencies: [{ kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemeCheckerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'scheme-checker', standalone: true, imports: [MatFormField, MatLabel, MatInput, MatButton], template: "<div class=\"check-host\">\n  @for (baseVar of Object.keys(values); track baseVar) {\n    <div class=\"check-element\"\n      >\n      <mat-form-field>\n        <mat-label >{{baseVar}}</mat-label>\n        <input matInput (change)=\"updateInputValue($event.target, baseVar)\">\n      </mat-form-field>\n    </div>\n  }\n  <button mat-raised-button (click)=\"startEvaluation()\">Start</button>\n</div>\n", styles: [".check-host{padding:20px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:flex-start;align-items:center}.check-element{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i4.MatDialog }], propDecorators: { codingScheme: [{
                type: Input
            }] } });

class ConfirmDialogComponent {
    constructor(confirmData) {
        this.confirmData = confirmData;
        this.showCancel = true;
    }
    ngOnInit() {
        if ((typeof this.confirmData.title === 'undefined') || (this.confirmData.title.length === 0)) {
            this.confirmData.title = 'Bitte bestätigen!';
        }
        if ((typeof this.confirmData.confirmButtonLabel === 'undefined') ||
            (this.confirmData.confirmButtonLabel.length === 0)) {
            this.confirmData.confirmButtonLabel = 'Bestätigen';
        }
        if (!this.confirmData.showCancel) {
            this.showCancel = false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ConfirmDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ConfirmDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>{{ confirmData.title }}</h1>

    <mat-dialog-content>
      <p>
        {{ confirmData.content }}
      </p>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="true">{{ confirmData.confirmButtonLabel }}</button>
      @if (showCancel) {
        <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
      }
    </mat-dialog-actions>
    `, isInline: true, dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{
                    template: `
    <h1 mat-dialog-title>{{ confirmData.title }}</h1>

    <mat-dialog-content>
      <p>
        {{ confirmData.content }}
      </p>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="true">{{ confirmData.confirmButtonLabel }}</button>
      @if (showCancel) {
        <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
      }
    </mat-dialog-actions>
    `,
                    standalone: true,
                    imports: [MatDialogTitle, MatDialogContent, MatDialogActions, MatButton, MatDialogClose, TranslateModule]
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

const deepClone = (value) => JSON.parse(JSON.stringify(value));
const residualTypes = [
    'RESIDUAL',
    'RESIDUAL_AUTO',
    'INTENDED_INCOMPLETE'
];
const numericRuleMethods = [
    'NUMERIC_MATCH',
    'NUMERIC_RANGE',
    'NUMERIC_FULL_RANGE',
    'NUMERIC_MIN',
    'NUMERIC_MORE_THAN',
    'NUMERIC_LESS_THAN',
    'NUMERIC_MAX'
];
const booleanRuleMethods = ['IS_TRUE', 'IS_FALSE'];
const DEFAULT_RESIDUAL_MANUAL_INSTRUCTION = '<p style="padding-left: 0; text-indent: 0; margin-bottom: 0; margin-top: 0">Alle anderen Antworten</p>';
const ensureResidualAutoManualInstruction = (code) => {
    if (code.type !== 'RESIDUAL_AUTO' || code.manualInstruction)
        return false;
    code.manualInstruction = DEFAULT_RESIDUAL_MANUAL_INSTRUCTION;
    return true;
};
const canEdit = (userRole) => ['RW_MINIMAL', 'RW_MAXIMAL'].includes(userRole);
const copySingleCode = (code) => {
    if (!code)
        return null;
    return deepClone(code);
};
const canPasteSingleCodeInto = (copiedCode, codeList, userRole) => {
    if (!copiedCode)
        return false;
    if (!canEdit(userRole))
        return false;
    const typeToPaste = copiedCode.type;
    if (typeToPaste && residualTypes.includes(typeToPaste)) {
        const firstResidualOrIntendedIncomplete = codeList.find(c => c.type && residualTypes.includes(c.type));
        if (firstResidualOrIntendedIncomplete)
            return false;
    }
    return true;
};
const getPasteSingleCodeWarningKeys = (copiedCode, targetCoding, targetVarInfo) => {
    if (!copiedCode)
        return [];
    const warningKeys = new Set();
    const ruleSets = copiedCode.ruleSets || [];
    const rules = ruleSets.flatMap(ruleSet => ruleSet.rules || []);
    const hasArrayReference = ruleSets.some(ruleSet => typeof ruleSet.valueArrayPos !== 'undefined');
    if (hasArrayReference && targetVarInfo && !targetVarInfo.multiple) {
        warningKeys.add('code.paste-warning.array-reference');
    }
    const hasFragmentReference = rules.some(rule => typeof rule.fragment !== 'undefined');
    if (hasFragmentReference && targetCoding && !targetCoding.fragmenting) {
        warningKeys.add('code.paste-warning.fragment-reference');
    }
    const hasNumericRule = rules.some(rule => numericRuleMethods.includes(rule.method));
    if (hasNumericRule &&
        targetVarInfo &&
        !['integer', 'number'].includes(targetVarInfo.type)) {
        warningKeys.add('code.paste-warning.numeric-rule');
    }
    const hasBooleanRule = rules.some(rule => booleanRuleMethods.includes(rule.method));
    if (hasBooleanRule && targetVarInfo && targetVarInfo.type !== 'boolean') {
        warningKeys.add('code.paste-warning.boolean-rule');
    }
    return Array.from(warningKeys);
};
const addCode = (codeList, codeType, userRole, orderOfCodeTypes) => {
    if (!canEdit(userRole))
        return 'code.error-message.no-access';
    const maxCode = codeList.length > 0 ?
        Math.max(...codeList
            .filter(c => typeof c.id === 'number')
            .map(c => Number(c.id) || 0)) :
        0;
    const hasNullCode = codeList.length > 0 ? !!codeList.find(c => c.id === 0) : false;
    if (['RESIDUAL', 'RESIDUAL_AUTO'].includes(codeType)) {
        const firstResidualOrIntendedIncomplete = codeList.find(c => c.type && residualTypes.includes(c.type));
        if (firstResidualOrIntendedIncomplete)
            return 'code.error-message.residual-exists';
        const newCode = {
            id: hasNullCode ? maxCode + 1 : 0,
            type: codeType,
            label: '',
            score: 0,
            ruleSetOperatorAnd: true,
            ruleSets: [],
            manualInstruction: DEFAULT_RESIDUAL_MANUAL_INSTRUCTION
        };
        codeList.push(newCode);
        return newCode;
    }
    if (codeType === 'INTENDED_INCOMPLETE') {
        const firstResidualOrIntendedIncomplete = codeList.find(c => c.type && residualTypes.includes(c.type));
        if (firstResidualOrIntendedIncomplete)
            return 'code.error-message.residual-exists';
        const newCode = {
            id: 0,
            type: codeType,
            label: '',
            score: 0,
            ruleSetOperatorAnd: true,
            ruleSets: [],
            manualInstruction: ''
        };
        codeList.push(newCode);
        return newCode;
    }
    if ([
        'FULL_CREDIT',
        'PARTIAL_CREDIT',
        'NO_CREDIT',
        'UNSET',
        'TO_CHECK'
    ].includes(codeType)) {
        let newCodeId = -1;
        codeList
            .filter(c => typeof c.id === 'number')
            .forEach(c => {
            if (c.type === codeType && c.id && Number(c.id) > newCodeId)
                newCodeId = Number(c.id);
        });
        if (newCodeId < 0) {
            newCodeId = orderOfCodeTypes.indexOf(codeType) + 1;
            const alreadyUsed = codeList.find(c => c.id === newCodeId);
            if (alreadyUsed)
                newCodeId = maxCode + 1;
        }
        else {
            const newCodeFound = codeList.find(c => c.id === newCodeId + 1);
            newCodeId = newCodeFound ? maxCode + 1 : newCodeId + 1;
        }
        const newCode = {
            id: newCodeId,
            type: codeType,
            label: '',
            score: codeType === 'FULL_CREDIT' ? 1 : 0,
            ruleSetOperatorAnd: true,
            ruleSets: [
                {
                    ruleOperatorAnd: false,
                    rules: [
                        {
                            method: 'MATCH',
                            parameters: ['']
                        }
                    ]
                }
            ],
            manualInstruction: ''
        };
        const firstFollowerCode = codeList.length > 0 ?
            codeList.findIndex(c => orderOfCodeTypes.indexOf(c.type) > orderOfCodeTypes.indexOf(codeType)) :
            -1;
        if (firstFollowerCode < 0) {
            codeList.push(newCode);
        }
        else {
            codeList.splice(firstFollowerCode, 0, newCode);
        }
        return newCode;
    }
    return 'code.error-message.type-not-supported';
};
const pasteSingleCode = (copiedCode, codeList, userRole, orderOfCodeTypes) => {
    if (!copiedCode)
        return 'code.error-message.nothing-to-paste';
    if (!canEdit(userRole))
        return 'code.error-message.no-access';
    if (!codeList)
        return 'code.error-message.fatal-error';
    const typeToPaste = copiedCode.type;
    if (typeToPaste && residualTypes.includes(typeToPaste)) {
        const firstResidualOrIntendedIncomplete = codeList.find(c => c.type && residualTypes.includes(c.type));
        if (firstResidualOrIntendedIncomplete)
            return 'code.error-message.residual-exists';
    }
    const addResult = typeToPaste ?
        addCode(codeList, typeToPaste, userRole, orderOfCodeTypes) :
        'code.error-message.fatal-error';
    if (typeof addResult === 'string')
        return addResult;
    const created = addResult;
    const payload = deepClone(copiedCode);
    const { id, type } = created;
    Object.assign(created, payload);
    created.id = id;
    created.type = type;
    return created;
};
const deleteCode = (codeList, codeIndex, userRole) => {
    if (!canEdit(userRole))
        return false;
    if (codeIndex < codeList.length) {
        codeList.splice(codeIndex, 1);
        return true;
    }
    return false;
};
const duplicateCode = (codeList, codeIndex, userRole) => {
    if (!canEdit(userRole))
        return 'code.error-message.no-access';
    if (codeIndex < 0 || codeIndex >= codeList.length)
        return 'code.error-message.invalid-index';
    const sourceCode = codeList[codeIndex];
    if (residualTypes.includes(sourceCode.type)) {
        return 'code.error-message.type-not-supported';
    }
    const maxCode = codeList.length > 0 ?
        Math.max(...codeList
            .filter(c => typeof c.id === 'number')
            .map(c => Number(c.id) || 0)) :
        0;
    const duplicated = deepClone(sourceCode);
    duplicated.id = maxCode + 1;
    codeList.splice(codeIndex + 1, 0, duplicated);
    return duplicated;
};
const sortCodes = (codeList, orderOfCodeTypes, normaliseCodeIds = false) => {
    if (codeList.length <= 1)
        return;
    if (normaliseCodeIds) {
        orderOfCodeTypes.forEach((type, typeIndex) => {
            const allCodesOfType = codeList.filter(code => code.type === type);
            if (allCodesOfType.length > 1) {
                const startValueBase = (typeIndex + 1) * (allCodesOfType.length > 9 ? 100 : 10);
                const startValue = startValueBase + 1;
                allCodesOfType.forEach((code, index) => {
                    if (code.id !== null) {
                        code.id = startValue + index;
                    }
                });
            }
        });
        orderOfCodeTypes.forEach(t => {
            if (!residualTypes.includes(t)) {
                const allCodesOfType = codeList.filter(c => c.type === t);
                if (allCodesOfType.length === 1)
                    allCodesOfType[0].id = orderOfCodeTypes.indexOf(t) + 1;
            }
            else {
                const allResidualCodes = codeList.filter(c => ['RESIDUAL', 'RESIDUAL_AUTO'].includes(c.type));
                if (allResidualCodes.length === 1)
                    allResidualCodes[0].id = 0;
            }
        });
    }
    codeList.sort((a, b) => {
        const getTypeOrder = (type) => orderOfCodeTypes.indexOf(type);
        if (a.type === b.type) {
            if (a.id === b.id)
                return 0;
            if (a.id === null)
                return -1;
            if (b.id === null)
                return 1;
            return a.id < b.id ? -1 : 1;
        }
        return getTypeOrder(a.type) - getTypeOrder(b.type);
    });
};

const MATH_TABLE_GENERAL_MANUAL_INSTRUCTION = '<p>Bitte Ergebniszeile, Rechenweg, Hilfszeilen und ggf. Durchstreichungen pr&uuml;fen.</p>';
const MATH_TABLE_MANUAL_CODE_INSTRUCTIONS = {
    FULL_CREDIT: '<p>Ergebnis und Rechenweg sind richtig.</p>',
    PARTIAL_CREDIT: '<p>Antwort teilweise richtig, z. B. nachvollziehbarer Rechenweg mit Fehlern.</p>',
    NO_CREDIT: '<p>Antwort falsch oder nicht nachvollziehbar.</p>',
    TO_CHECK: '<p>Antwort muss manuell gepr&uuml;ft werden.</p>'
};
const isMathTableVariableInfo = (varInfo) => (varInfo?.type === 'json' && varInfo.format === 'math-table');
const normaliseMathTableExpectedResult = (value) => ((value || '')
    .replace(/\s+/g, '')
    .replace(/-/g, '\u2212')
    .replace(/\*/g, '\u2022')
    .replace(/\//g, ':'));
const escapeRegExp = (value) => (value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
const escapeJsonStringValueForRegExp = (value) => (escapeRegExp(JSON.stringify(value).slice(1, -1)));
const createCellWithValuePattern = (valuePattern) => (`\\{[^{}]*"value"\\s*:\\s*"${valuePattern}"[^{}]*\\}`);
const createMathTableResultRulePattern = (expectedResult) => {
    const normalisedResult = normaliseMathTableExpectedResult(expectedResult);
    if (!normalisedResult) {
        return '(?!)';
    }
    const emptyCellPattern = createCellWithValuePattern('(?:|\\s)');
    const expectedCellPatterns = normalisedResult
        .split('')
        .map(char => createCellWithValuePattern(escapeJsonStringValueForRegExp(char)))
        .join('\\s*,\\s*');
    return [
        '"rowType"\\s*:\\s*"result"',
        '\\s*,\\s*"cells"\\s*:\\s*\\[',
        `\\s*(?:${emptyCellPattern}\\s*,\\s*)*`,
        expectedCellPatterns,
        `(?:\\s*,\\s*${emptyCellPattern})*\\s*\\]`
    ].join('');
};
const createMathTableResultRule = (expectedResult) => ({
    method: 'MATCH_REGEX',
    parameters: [createMathTableResultRulePattern(expectedResult)]
});

const isGeoGebraVariableInfo = (varInfo) => varInfo?.format === 'ggb-variable';
const geoGebraNumberPattern = '([-+]?\\d+(?:[.,]\\d+)?)';
// GeoGebra uses a decimal point and commas between Cartesian coordinates.
// Allowing decimal commas here would make compact 3D points look like 2D points.
const geoGebraPointCoordinatePattern = '([-+]?\\d+(?:\\.\\d+)?)';
const createGeoGebraValueFragmenting = (mode = 'text') => {
    const variablePattern = '[^=]+';
    const valuePatternByMode = {
        numeric: geoGebraNumberPattern,
        angle: `${geoGebraNumberPattern}\\s*°?`,
        point: `\\(\\s*${geoGebraPointCoordinatePattern}\\s*,\\s*${geoGebraPointCoordinatePattern}\\s*\\)`,
        boolean: '(true|false)',
        text: '(.*?)'
    };
    return `^\\s*${variablePattern}\\s*=\\s*${valuePatternByMode[mode]}\\s*$`;
};

const COPIED_CODE_STORAGE_KEY = 'iqb-schemer-copied-code';
const COPIED_CODE_STORAGE_TYPE = 'iqb-schemer-code-clipboard';
const COPIED_CODE_STORAGE_VERSION = 1;
const getSessionStorage = () => {
    try {
        if (typeof globalThis === 'undefined' || !globalThis.sessionStorage) {
            return null;
        }
        return globalThis.sessionStorage;
    }
    catch {
        return null;
    }
};
const readCopiedCodeFromStorage = () => {
    const storage = getSessionStorage();
    if (!storage)
        return null;
    try {
        const serialized = storage.getItem(COPIED_CODE_STORAGE_KEY);
        if (!serialized)
            return null;
        const stored = JSON.parse(serialized);
        if (stored?.type !== COPIED_CODE_STORAGE_TYPE ||
            stored?.version !== COPIED_CODE_STORAGE_VERSION ||
            !stored?.code) {
            return null;
        }
        return stored.code;
    }
    catch {
        return null;
    }
};
const writeCopiedCodeToStorage = (code) => {
    const storage = getSessionStorage();
    if (!storage)
        return;
    try {
        if (!code) {
            storage.removeItem(COPIED_CODE_STORAGE_KEY);
            return;
        }
        storage.setItem(COPIED_CODE_STORAGE_KEY, JSON.stringify({
            type: COPIED_CODE_STORAGE_TYPE,
            version: COPIED_CODE_STORAGE_VERSION,
            code
        }));
    }
    catch {
        // Ignore quota and privacy-mode failures; the in-memory clipboard still works.
    }
};
class SchemerService {
    constructor() {
        this._codingScheme = signal(null, ...(ngDevMode ? [{ debugName: "_codingScheme" }] : /* istanbul ignore next */ []));
        this._varList = signal([], ...(ngDevMode ? [{ debugName: "_varList" }] : /* istanbul ignore next */ []));
        this.allVariableIds = [];
        this.ruleMethodParameterCount = RuleMethodParameterCount;
        this._userRole = signal('RW_MAXIMAL', ...(ngDevMode ? [{ debugName: "_userRole" }] : /* istanbul ignore next */ []));
        this._copiedCode = signal(null, ...(ngDevMode ? [{ debugName: "_copiedCode" }] : /* istanbul ignore next */ []));
        this._codingToTextMode = signal('EXTENDED', ...(ngDevMode ? [{ debugName: "_codingToTextMode" }] : /* istanbul ignore next */ []));
        this.orderOfCodeTypes = [
            'FULL_CREDIT',
            'PARTIAL_CREDIT',
            'TO_CHECK',
            'NO_CREDIT',
            'UNSET',
            'INTENDED_INCOMPLETE',
            'RESIDUAL',
            'RESIDUAL_AUTO'
        ];
    }
    get codingScheme() {
        return this._codingScheme();
    }
    setCodingScheme(value) {
        this._codingScheme.set(value);
    }
    get varList() {
        return this._varList();
    }
    setVarList(value) {
        this._varList.set(value || []);
    }
    get userRole() {
        return this._userRole();
    }
    setUserRole(value) {
        this._userRole.set(value);
    }
    get copiedCode() {
        return this.getCopiedCode();
    }
    setCopiedCode(value) {
        this._copiedCode.set(value);
        writeCopiedCodeToStorage(value);
    }
    get codingToTextMode() {
        return this._codingToTextMode();
    }
    setCodingToTextMode(value) {
        this._codingToTextMode.set(value);
    }
    getVarInfoByCoding(varCoding) {
        if (varCoding.sourceType === 'BASE') {
            return this.varList.find(v => v.id === varCoding.id);
        }
        if (varCoding.sourceType === 'COPY_VALUE') {
            if (varCoding.deriveSources && varCoding.deriveSources.length > 0) {
                return this.varList.find(v => v.id === (varCoding.deriveSources || [])[0]);
            }
        }
        else if (varCoding.sourceType === 'CONCAT_CODE') {
            if (varCoding.deriveSources && varCoding.deriveSources.length > 0) {
                const codes = [];
                let totalCodesCount = 0;
                varCoding.deriveSources.forEach((s) => {
                    if (this.codingScheme) {
                        const coding = this.codingScheme.variableCodings.find(v => v.id === s);
                        codes.push(coding ? (coding.codes || []).map(c => c.id) : []);
                        totalCodesCount += coding ? (coding.codes || []).length : 0;
                    }
                });
                let resultArray = [];
                if (totalCodesCount < 10) {
                    codes.forEach((c) => {
                        if (resultArray.length > 0) {
                            resultArray = resultArray.flatMap(oldEntry => c
                                .filter(cEntry => cEntry !== null)
                                .map(cEntry => `${oldEntry}${DeriveConcatDelimiter}${cEntry}`));
                        }
                        else {
                            resultArray = c
                                .filter(cEntry => cEntry !== null)
                                .map(cEntry => cEntry.toString(10));
                        }
                    });
                }
                return {
                    id: varCoding.id,
                    alias: varCoding.alias,
                    type: 'string',
                    format: '',
                    multiple: false,
                    nullable: false,
                    values: resultArray.map(r => ({
                        value: r,
                        label: ''
                    })),
                    valuePositionLabels: [],
                    valuesComplete: true,
                    page: ''
                };
            }
        }
        else if (varCoding.deriveSources && varCoding.deriveSources.length > 0) {
            return {
                id: varCoding.id,
                alias: varCoding.alias,
                type: 'integer',
                format: '',
                multiple: false,
                nullable: false,
                values: [],
                valuePositionLabels: [],
                valuesComplete: false,
                page: ''
            };
        }
        return undefined;
    }
    copySingleCode(code) {
        const copied = copySingleCode(code);
        if (!copied)
            return false;
        this.setCopiedCode(copied);
        return true;
    }
    canPasteSingleCodeInto(codeList) {
        return canPasteSingleCodeInto(this.getCopiedCode(), codeList, this.userRole);
    }
    getPasteSingleCodeWarningKeys(targetCoding, targetVarInfo) {
        return getPasteSingleCodeWarningKeys(this.getCopiedCode(), targetCoding, targetVarInfo);
    }
    pasteSingleCode(codeList) {
        return pasteSingleCode(this.getCopiedCode(), codeList, this.userRole, this.orderOfCodeTypes);
    }
    getCodingProblemsForVarCoding(varCoding) {
        if (!varCoding || !this.codingScheme?.variableCodings)
            return [];
        try {
            const targetNames = [varCoding.id, varCoding.alias].filter(Boolean);
            return CodingSchemeFactory.validate(this.varList, this.codingScheme.variableCodings).filter(problem => targetNames.includes(problem.variableId));
        }
        catch {
            return [];
        }
    }
    addCode(codeList, codeType) {
        return addCode(codeList, codeType, this.userRole, this.orderOfCodeTypes);
    }
    deleteCode(codeList, codeIndex) {
        return deleteCode(codeList, codeIndex, this.userRole);
    }
    duplicateCode(codeList, codeIndex) {
        return duplicateCode(codeList, codeIndex, this.userRole);
    }
    sortCodes(codeList, normaliseCodeIds = false) {
        sortCodes(codeList, this.orderOfCodeTypes, normaliseCodeIds);
    }
    getVariableAliasById(varId) {
        if (!varId || !this.codingScheme || !this.codingScheme.variableCodings)
            return '?';
        const findVar = this.codingScheme.variableCodings.find((v) => v.id === varId);
        if (findVar)
            return findVar.alias || findVar.id;
        return '?';
    }
    getVariableAliasByIdListString(varIds, maxEntries) {
        if (!this.codingScheme || !this.codingScheme.variableCodings)
            return '';
        const varIdsToTake = maxEntries > 0 && maxEntries <= varIds.length ?
            varIds.slice(0, maxEntries) :
            varIds;
        const returnValues = varIdsToTake.map(vId => this.getVariableAliasById(vId));
        if (maxEntries > 0 && maxEntries < varIds.length)
            returnValues.push('...');
        return returnValues.join(', ');
    }
    getCopiedCode() {
        const copiedCode = this._copiedCode();
        if (copiedCode)
            return copiedCode;
        const storedCode = readCopiedCodeFromStorage();
        if (storedCode)
            this._copiedCode.set(storedCode);
        return storedCode;
    }
    getBaseVarsList() {
        if (this.codingScheme) {
            return this.codingScheme.variableCodings.filter((c) => c.sourceType === 'BASE');
        }
        return [];
    }
    isProtectedBaseVariable(varCoding) {
        if (!varCoding || varCoding.sourceType !== 'BASE')
            return false;
        return this.varList.some(v => v.id === varCoding.id && v.type !== 'no-value');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class GenerateCodingDialogComponent {
    constructor(varInfo, translateService, schemerService, dialogRef) {
        this.varInfo = varInfo;
        this.translateService = translateService;
        this.schemerService = schemerService;
        this.dialogRef = dialogRef;
        this.ToTextFactory = ToTextFactory;
        this.selectedOption = '';
        this.selectedOptions = [];
        this.positionLabels = [];
        this.selectedArrayPos = 'ANY_OPEN';
        this.booleanMultiSelections = [];
        this.multiChoiceOrderMatters = false;
        this.singleChoiceLongVersion = false;
        this._options = [];
        this.options = [];
        this.selectedDragOptions = [];
        this.textAsNumeric = false;
        this.numericMoreThen = '';
        this.numericLessThen = '';
        this.numericMax = '';
        this.numericMin = '';
        this.numericMatch = '';
        this.numericRuleText = '';
        this.numericRuleError = false;
        this.elseMethod = 'none';
        this.mathTableMode = 'result-auto';
        this.mathTableExpectedResult = '';
        this.isGeoGebraVariable = false;
        this.geogebraExtractValue = false;
        this.geogebraCodingMode = 'numeric';
        this.geogebraPointX = '';
        this.geogebraPointXMoreThen = '';
        this.geogebraPointXMin = '';
        this.geogebraPointXLessThen = '';
        this.geogebraPointXMax = '';
        this.geogebraPointY = '';
        this.geogebraPointYMoreThen = '';
        this.geogebraPointYMin = '';
        this.geogebraPointYLessThen = '';
        this.geogebraPointYMax = '';
        this.geogebraBooleanValue = 'true';
        this.generationModel = 'none';
        if (!varInfo) {
            return;
        }
        if (isMathTableVariableInfo(varInfo)) {
            this.generationModel = 'math-table';
            this.elseMethod = 'auto';
            return;
        }
        this.isGeoGebraVariable = isGeoGebraVariableInfo(varInfo);
        this.geogebraExtractValue = this.isGeoGebraVariable;
        if (varInfo.values?.length > 0) {
            this.elseMethod = varInfo.valuesComplete ? 'auto' : 'instruction';
            if (varInfo.multiple) {
                this.generationModel = 'multi-choice';
                this.positionLabels = varInfo.valuePositionLabels;
            }
            else {
                this.generationModel =
                    varInfo.values.length > 20 ?
                        'single-choice-many' :
                        'single-choice-some';
            }
            this._options = varInfo.values.map((v, i) => ({
                value: typeof v.value === 'string' ? v.value : v.value.toString(),
                oldIndex: i,
                label: v.label
            }));
            this.resetOptions();
            return;
        }
        if (varInfo.multiple && varInfo.type === 'boolean') {
            this.elseMethod = 'auto';
            this.generationModel = 'boolean-multi';
            this.positionLabels = varInfo.valuePositionLabels;
            this.booleanMultiSelections = (this.positionLabels || []).map(() => false);
            return;
        }
        if (varInfo.multiple && varInfo.type === 'string') {
            this.elseMethod = 'instruction';
            this.generationModel = 'simple-input';
            this.positionLabels = varInfo.valuePositionLabels;
            this.selectedArrayPos = this.positionLabels.length > 0 ? 0 : 'ANY_OPEN';
            return;
        }
        if (!varInfo.multiple) {
            this.elseMethod = 'auto';
            switch (varInfo.type) {
                case 'integer':
                    this.generationModel = 'integer';
                    break;
                case 'number':
                    if (this.isGeoGebraVariable) {
                        this.generationModel = 'integer';
                    }
                    break;
                case 'string':
                    if (this.isGeoGebraVariable) {
                        this.textAsNumeric = true;
                    }
                    this.generationModel = 'simple-input';
                    break;
                case 'boolean':
                    if (this.isGeoGebraVariable) {
                        this.generationModel = 'geogebra-boolean';
                    }
                    break;
                default:
                    break;
            }
        }
        this.updateNumericRuleText();
    }
    setGeoGebraCodingMode(mode) {
        this.geogebraCodingMode = mode;
        this.textAsNumeric = ['numeric', 'angle', 'point'].includes(mode);
        if (mode === 'point') {
            this.geogebraExtractValue = true;
        }
        if (this.textAsNumeric) {
            this.updateNumericRuleText();
        }
    }
    isGeoGebraBooleanMode() {
        return this.generationModel === 'geogebra-boolean' ||
            (this.isGeoGebraVariable &&
                this.generationModel === 'simple-input' &&
                this.geogebraCodingMode === 'boolean');
    }
    isGeoGebraPointMode() {
        return this.isGeoGebraVariable &&
            this.generationModel === 'simple-input' &&
            this.geogebraCodingMode === 'point';
    }
    isNumericCodingMode() {
        return this.generationModel === 'integer' ||
            (this.generationModel === 'simple-input' &&
                this.textAsNumeric &&
                !this.isGeoGebraBooleanMode() &&
                !this.isGeoGebraPointMode());
    }
    isTextInputCodingMode() {
        return this.generationModel === 'simple-input' &&
            !this.textAsNumeric &&
            !this.isGeoGebraBooleanMode();
    }
    resetOptions() {
        const maxLength = 30;
        const truncate = (text) => {
            if (!text)
                return text;
            return text.length > maxLength ?
                `${text.slice(0, maxLength - 1)}…` :
                text;
        };
        this.options = this._options.map(o => ({
            value: truncate(o.value),
            oldIndex: o.oldIndex,
            label: truncate(o.label)
        }));
        this.selectedOptions = [];
        this.selectedDragOptions = [];
    }
    updateNumericRuleText() {
        const { rules, errorKeys } = this.getNumericCodingDefinition();
        this.numericRuleError = errorKeys.length > 0;
        this.numericRuleText = this.numericRuleError ?
            errorKeys.map(key => this.translateService.instant(key)).join(' ') :
            rules.map(rule => {
                const label = this.translateService.instant(`rule.${rule.method}`);
                const separator = rule.method === 'NUMERIC_MATCH' ? ': ' : ' ';
                return `${label}${separator}${rule.parameters?.join(' / ')}`;
            }).join('; ');
    }
    getNumericCodingDefinition() {
        const parseValue = (value) => {
            // The response converter returns 0 for an empty string, so check presence first.
            if (value.trim() === '')
                return null;
            const numericValue = CodingFactory.getValueAsNumber(value);
            return numericValue !== null && Number.isFinite(numericValue) ? numericValue : null;
        };
        const invalid = (errorKeys) => ({ rules: [], errorKeys });
        if (this.numericMatch.trim() !== '') {
            const matchValue = parseValue(this.numericMatch);
            return matchValue === null ?
                invalid(['coding.generate.invalid-number']) :
                { rules: [{ method: 'NUMERIC_MATCH', parameters: [matchValue.toString(10)] }], errorKeys: [] };
        }
        const inputs = [
            ['NUMERIC_MORE_THAN', this.numericMoreThen],
            ['NUMERIC_MIN', this.numericMin],
            ['NUMERIC_LESS_THAN', this.numericLessThen],
            ['NUMERIC_MAX', this.numericMax]
        ];
        const values = inputs.map(([, value]) => parseValue(value));
        if (inputs.some(([, value], index) => value.trim() !== '' && values[index] === null)) {
            return invalid(['coding.generate.invalid-number']);
        }
        const [moreThan, min, lessThan, max] = values;
        const errorKeys = [];
        if (moreThan !== null && min !== null)
            errorKeys.push('coding.generate.only-one-lower-limit');
        if (lessThan !== null && max !== null)
            errorKeys.push('coding.generate.only-one-upper-limit');
        if (errorKeys.length > 0)
            return invalid(errorKeys);
        if (values.every(value => value === null))
            return invalid(['coding.generate.empty-value']);
        const lower = moreThan ?? min;
        const upper = lessThan ?? max;
        if (lower !== null && upper !== null &&
            (lower > upper || (lower === upper && (moreThan !== null || lessThan !== null)))) {
            return invalid(['coding.generate.invalid-range']);
        }
        if (min !== null && max !== null) {
            return {
                rules: [{ method: 'NUMERIC_FULL_RANGE', parameters: [min.toString(10), max.toString(10)] }],
                errorKeys: []
            };
        }
        const rules = [];
        inputs.forEach(([method], index) => {
            const value = values[index];
            if (value !== null)
                rules.push({ method, parameters: [value.toString(10)] });
        });
        return { rules, errorKeys: [] };
    }
    // eslint-disable-next-line class-methods-use-this
    drop(event) {
        GenerateCodingDialogComponent.drop(event);
    }
    static drop(event) {
        if (!event) {
            return;
        }
        const { previousContainer, container, previousIndex, currentIndex } = event;
        if (previousContainer === container) {
            moveItemInArray(container.data, previousIndex, currentIndex);
        }
        else {
            transferArrayItem(previousContainer.data, container.data, previousIndex, currentIndex);
        }
    }
    returnOption(optionToReturn) {
        const removeIndex = this.selectedDragOptions.findIndex(o => o.value === optionToReturn.value);
        if (removeIndex === -1) {
            return;
        }
        this.selectedDragOptions.splice(removeIndex, 1);
        const insertIndex = this.options.findIndex(o => o.oldIndex > optionToReturn.oldIndex);
        if (insertIndex === -1) {
            this.options.push(optionToReturn);
        }
        else {
            this.options.splice(insertIndex, 0, optionToReturn);
        }
    }
    requiresMathTableExpectedResult() {
        return this.generationModel === 'math-table' &&
            this.mathTableMode === 'result-auto';
    }
    canGenerate() {
        if (this.generationModel === 'none') {
            return false;
        }
        if (this.requiresMathTableExpectedResult()) {
            return normaliseMathTableExpectedResult(this.mathTableExpectedResult).length > 0;
        }
        if (this.isGeoGebraPointMode()) {
            return this.createGeoGebraPointRules() !== null;
        }
        if (this.isNumericCodingMode()) {
            return this.getNumericCodingDefinition().errorKeys.length === 0;
        }
        return true;
    }
    getSelectedArrayPos() {
        return typeof this.selectedArrayPos === 'number' && this.selectedArrayPos < 0 ?
            'ANY_OPEN' :
            this.selectedArrayPos;
    }
    addCodeToVariable(newVardata, codeType) {
        const newCode = this.schemerService.addCode(newVardata.codes || [], codeType);
        return typeof newCode === 'string' ? null : newCode;
    }
    addMathTableResultAutoCode(newVardata) {
        const newCode = this.addCodeToVariable(newVardata, 'FULL_CREDIT');
        if (!newCode)
            return false;
        newCode.ruleSetOperatorAnd = true;
        newCode.ruleSets = [
            {
                ruleOperatorAnd: false,
                rules: [
                    createMathTableResultRule(this.mathTableExpectedResult)
                ]
            }
        ];
        return true;
    }
    addMathTableResidualCode(newVardata) {
        if (!['auto', 'instruction'].includes(this.elseMethod))
            return true;
        const newResidualCode = this.addCodeToVariable(newVardata, this.elseMethod === 'instruction' ? 'RESIDUAL' : 'RESIDUAL_AUTO');
        return !!newResidualCode;
    }
    addMathTableManualCodes(newVardata) {
        return [
            'FULL_CREDIT',
            'PARTIAL_CREDIT',
            'NO_CREDIT',
            'TO_CHECK'
        ].every(codeType => {
            const newCode = this.addCodeToVariable(newVardata, codeType);
            if (!newCode)
                return false;
            newCode.ruleSetOperatorAnd = true;
            newCode.ruleSets = [];
            newCode.manualInstruction =
                MATH_TABLE_MANUAL_CODE_INSTRUCTIONS[codeType] || '';
            return true;
        });
    }
    static createGeoGebraCoordinateRules(fragment, match, moreThan, min, lessThan, max) {
        const hasValue = (value) => value.trim() !== '';
        const createRule = (method, value) => {
            const numericValue = CodingFactory.getValueAsNumber(value);
            return numericValue === null ?
                null :
                {
                    method,
                    parameters: [numericValue.toString(10)],
                    fragment
                };
        };
        if (hasValue(match)) {
            const matchRule = createRule('NUMERIC_MATCH', match);
            return matchRule ? [matchRule] : null;
        }
        const hasMoreThan = hasValue(moreThan);
        const hasMin = hasValue(min);
        const hasLessThan = hasValue(lessThan);
        const hasMax = hasValue(max);
        if ((hasMoreThan && hasMin) || (hasLessThan && hasMax)) {
            return null;
        }
        let lowerValue = null;
        if (hasMoreThan) {
            lowerValue = CodingFactory.getValueAsNumber(moreThan);
        }
        else if (hasMin) {
            lowerValue = CodingFactory.getValueAsNumber(min);
        }
        let upperValue = null;
        if (hasLessThan) {
            upperValue = CodingFactory.getValueAsNumber(lessThan);
        }
        else if (hasMax) {
            upperValue = CodingFactory.getValueAsNumber(max);
        }
        if (((hasMoreThan || hasMin) && lowerValue === null) ||
            ((hasLessThan || hasMax) && upperValue === null)) {
            return null;
        }
        if (lowerValue !== null &&
            upperValue !== null &&
            (lowerValue > upperValue ||
                (lowerValue === upperValue && (hasMoreThan || hasLessThan)))) {
            return null;
        }
        if (hasMin && hasMax && lowerValue !== null && upperValue !== null) {
            return [{
                    method: 'NUMERIC_FULL_RANGE',
                    parameters: [
                        lowerValue.toString(10),
                        upperValue.toString(10)
                    ],
                    fragment
                }];
        }
        const ruleInputs = [
            ['NUMERIC_MORE_THAN', moreThan, hasMoreThan],
            ['NUMERIC_MIN', min, hasMin],
            ['NUMERIC_LESS_THAN', lessThan, hasLessThan],
            ['NUMERIC_MAX', max, hasMax]
        ];
        const rules = ruleInputs
            .filter(([, , isPresent]) => isPresent)
            .map(([method, value]) => createRule(method, value));
        if (rules.some(rule => rule === null)) {
            return null;
        }
        return rules.filter((rule) => rule !== null);
    }
    createGeoGebraPointRules() {
        const xRules = GenerateCodingDialogComponent.createGeoGebraCoordinateRules(0, this.geogebraPointX, this.geogebraPointXMoreThen, this.geogebraPointXMin, this.geogebraPointXLessThen, this.geogebraPointXMax);
        const yRules = GenerateCodingDialogComponent.createGeoGebraCoordinateRules(1, this.geogebraPointY, this.geogebraPointYMoreThen, this.geogebraPointYMin, this.geogebraPointYLessThen, this.geogebraPointYMax);
        if (xRules === null || yRules === null) {
            return null;
        }
        const pointRules = [...xRules, ...yRules];
        return pointRules.length > 0 ? pointRules : null;
    }
    generateMathTableCoding(newVardata) {
        if (this.mathTableMode === 'manual') {
            newVardata.codeModel = 'MANUAL_ONLY';
            newVardata.manualInstruction = MATH_TABLE_GENERAL_MANUAL_INSTRUCTION;
            if (!this.addMathTableManualCodes(newVardata)) {
                this.dialogRef.close(null);
                return;
            }
            this.dialogRef.close(newVardata);
            return;
        }
        newVardata.codeModel = this.elseMethod === 'instruction' ?
            'MANUAL_AND_RULES' :
            'RULES_ONLY';
        newVardata.manualInstruction = '';
        if (!this.addMathTableResultAutoCode(newVardata) ||
            !this.addMathTableResidualCode(newVardata)) {
            this.dialogRef.close(null);
            return;
        }
        this.dialogRef.close(newVardata);
    }
    generateButtonClick() {
        if (!this.canGenerate()) {
            this.dialogRef.close(null);
        }
        else {
            const newVardata = {
                id: this.varInfo.id,
                alias: this.varInfo.alias || this.varInfo.id,
                label: '',
                sourceType: 'BASE',
                sourceParameters: {
                    solverExpression: '',
                    processing: []
                },
                deriveSources: [],
                processing: [],
                fragmenting: '',
                manualInstruction: '',
                codeModel: 'MANUAL_AND_RULES',
                codes: []
            };
            if (this.isGeoGebraVariable && (this.geogebraExtractValue || this.isGeoGebraPointMode())) {
                newVardata.fragmenting = createGeoGebraValueFragmenting(this.generationModel === 'geogebra-boolean' ?
                    'boolean' :
                    this.geogebraCodingMode);
            }
            if (this.generationModel === 'math-table') {
                this.generateMathTableCoding(newVardata);
                return;
            }
            if (['auto', 'instruction'].includes(this.elseMethod)) {
                const newResidualCode = this.schemerService.addCode(newVardata.codes || [], this.elseMethod === 'instruction' ? 'RESIDUAL' : 'RESIDUAL_AUTO');
                if (typeof newResidualCode !== 'string' &&
                    this.singleChoiceLongVersion) {
                    // todo: seems to fail - why?
                    newResidualCode.id = 'INVALID';
                }
            }
            if (this.isGeoGebraPointMode()) {
                const pointRules = this.createGeoGebraPointRules();
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string' && pointRules) {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = [
                        {
                            ruleOperatorAnd: true,
                            rules: pointRules
                        }
                    ];
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else if (this.isGeoGebraBooleanMode()) {
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = [
                        {
                            ruleOperatorAnd: false,
                            rules: [
                                {
                                    method: this.geogebraBooleanValue === 'true' ? 'IS_TRUE' : 'IS_FALSE',
                                    parameters: []
                                }
                            ]
                        }
                    ];
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else if (this.isNumericCodingMode()) {
                const numericRules = this.getNumericCodingDefinition().rules;
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = [
                        {
                            ruleOperatorAnd: true,
                            ...(this.varInfo.multiple ? { valueArrayPos: this.getSelectedArrayPos() } : {}),
                            rules: numericRules
                        }
                    ];
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else if (this.generationModel === 'simple-input') {
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = [
                        {
                            ruleOperatorAnd: false,
                            ...(this.varInfo.multiple ? { valueArrayPos: this.getSelectedArrayPos() } : {}),
                            rules: [
                                {
                                    method: 'MATCH',
                                    parameters: [this.selectedOption || '']
                                }
                            ]
                        }
                    ];
                    this.dialogRef.close(newVardata);
                }
            }
            else if (this.generationModel === 'single-choice-some' &&
                this.singleChoiceLongVersion) {
                // eslint-disable-next-line eqeqeq
                this.options
                    .filter(o => this.selectedOptions[0] && o.value === this.selectedOptions[0])
                    .forEach(o => {
                    const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                    if (typeof newCode !== 'string') {
                        newCode.ruleSetOperatorAnd = true;
                        newCode.ruleSets = [
                            {
                                ruleOperatorAnd: false,
                                rules: [
                                    {
                                        method: 'MATCH',
                                        parameters: [o.value || '']
                                    }
                                ]
                            }
                        ];
                    }
                });
                // eslint-disable-next-line eqeqeq
                this.options
                    .filter(o => !(this.selectedOptions[0] && o.value === this.selectedOptions[0]))
                    .forEach(o => {
                    const newCode = this.schemerService.addCode(newVardata.codes || [], 'NO_CREDIT');
                    if (typeof newCode !== 'string') {
                        newCode.ruleSetOperatorAnd = true;
                        newCode.ruleSets = [
                            {
                                ruleOperatorAnd: false,
                                rules: [
                                    {
                                        method: 'MATCH',
                                        parameters: [o.value || '']
                                    }
                                ]
                            }
                        ];
                    }
                });
                // newVardata.codeModel = 'RULES_ONLY';
                if (newVardata.codes) {
                    this.schemerService.sortCodes(newVardata.codes, true);
                }
                this.dialogRef.close(newVardata);
            }
            else if (this.generationModel === 'multi-choice' &&
                this.multiChoiceOrderMatters) {
                const fullCreditRuleSets = [];
                this.selectedDragOptions.forEach((o, i) => {
                    fullCreditRuleSets.push({
                        ruleOperatorAnd: false,
                        valueArrayPos: i,
                        rules: [
                            {
                                method: 'MATCH',
                                parameters: [o.value || '']
                            }
                        ]
                    });
                });
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = fullCreditRuleSets;
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else if (this.generationModel === 'boolean-multi') {
                const fullCreditRuleSets = [];
                (this.booleanMultiSelections || []).forEach((isSelected, i) => {
                    fullCreditRuleSets.push({
                        ruleOperatorAnd: false,
                        valueArrayPos: i,
                        rules: [
                            {
                                method: isSelected ? 'IS_TRUE' : 'IS_FALSE',
                                parameters: []
                            }
                        ]
                    });
                });
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = fullCreditRuleSets;
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else if (['multi-choice', 'single-choice-many', 'single-choice-some'].includes(this.generationModel)) {
                const fullCreditRules = [];
                if (this.generationModel === 'single-choice-many') {
                    fullCreditRules.push({
                        method: 'MATCH',
                        parameters: [this.selectedOption || '']
                    });
                }
                else if (this.selectedOptions.length > 0) {
                    if (this.varInfo.type === 'boolean') {
                        this.selectedOptions.forEach(s => {
                            fullCreditRules.push({
                                method: s === 'true' ? 'IS_TRUE' : 'IS_FALSE',
                                parameters: []
                            });
                        });
                    }
                    else {
                        this.selectedOptions.forEach(s => {
                            fullCreditRules.push({
                                method: 'MATCH',
                                parameters: [s]
                            });
                        });
                    }
                }
                else if (this.varInfo.type === 'boolean') {
                    fullCreditRules.push({
                        method: 'IS_TRUE',
                        parameters: []
                    });
                }
                else {
                    fullCreditRules.push({
                        method: 'MATCH',
                        parameters: ['']
                    });
                }
                const newCode = this.schemerService.addCode(newVardata.codes || [], 'FULL_CREDIT');
                if (typeof newCode !== 'string') {
                    newCode.ruleSetOperatorAnd = true;
                    newCode.ruleSets = [
                        {
                            ruleOperatorAnd: false,
                            rules: fullCreditRules
                        }
                    ];
                    this.dialogRef.close(newVardata);
                }
                else {
                    this.dialogRef.close(null);
                }
            }
            else {
                this.dialogRef.close(null);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: GenerateCodingDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1.TranslateService }, { token: SchemerService }, { token: i4.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: GenerateCodingDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "@if (varInfo) {\n<h1 mat-dialog-title>\n  {{ \"coding.generate.dialog-title\" | translate }} '{{\n    schemerService.getVariableAliasById(varInfo.id || \"?\")\n  }}'\n</h1>\n}\n<mat-dialog-content>\n  @if (varInfo) {\n  <div>\n    @for (info of ToTextFactory.varInfoAsText(varInfo); track info) {\n    <p>{{ info }}</p>\n    }\n  </div>\n  } @if (!varInfo) {\n  <div>\n    <p>{{ \"coding.generate.no-var-info\" | translate }}</p>\n  </div>\n  } @if (generationModel === 'none') {\n  <div [style.font-style]=\"'italic'\">\n    {{ \"coding.generate.model.none\" | translate }}\n  </div>\n  } @if (generationModel !== 'none') {\n  <div class=\"coding-action\">\n    <p [style.font-weight]=\"'bold'\">\n      {{ \"coding.generate.title\" | translate }}\n    </p>\n    <p>{{ \"coding.generate.model.\" + generationModel | translate }}</p>\n    @if (generationModel === 'multi-choice') {\n\n    <div class=\"fx-row-end-center\">\n      <mat-label [style.margin-right.px]=\"8\">{{\n        \"coding.generate.model.multi-choice-order-prompt\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"multiChoiceOrderMatters\"\n        (click)=\"resetOptions()\"\n      ></mat-checkbox>\n    </div>\n    @if (!multiChoiceOrderMatters) {\n    <mat-selection-list [(ngModel)]=\"selectedOptions\" multiple=\"true\">\n      @for (c of options; track c) {\n      <mat-list-option [value]=\"c.value\">\n        '{{ c.value }}'{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n      </mat-list-option>\n      }\n    </mat-selection-list>\n    } @if (multiChoiceOrderMatters) {\n    <div class=\"fx-column-start-stretch\">\n      <div>\n        {{ \"coding.generate.model.multi-choice-drag-prompt\" | translate }}\n      </div>\n      <div class=\"fx-row-start-stretch fx-gap-10\">\n        <mat-chip-list\n          class=\"dragOptionBox chip-list-column\"\n          cdkDropList\n          [style.width.%]=\"50\"\n          [style.max-height.px]=\"800\"\n          #optionSource=\"cdkDropList\"\n          [cdkDropListConnectedTo]=\"selectedOptions\"\n          [cdkDropListData]=\"options\"\n        >\n          @for (c of options; track c) {\n          <mat-chip cdkDrag\n            >{{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}</mat-chip\n          >\n          }\n        </mat-chip-list>\n        @if (positionLabels.length > 0) {\n        <div class=\"fx-column-start-stretch\" [style.width.px]=\"50\">\n          @for (pl of positionLabels; track pl) {\n          <p>{{ pl }}</p>\n          }\n        </div>\n        }\n        <mat-chip-list\n          cdkDropList\n          class=\"dragOptionBox chip-list-column fx-flex-fill\"\n          #selectedOptions=\"cdkDropList\"\n          [cdkDropListConnectedTo]=\"[optionSource]\"\n          [cdkDropListData]=\"selectedDragOptions\"\n          (cdkDropListDropped)=\"drop($event)\"\n        >\n          @for (c of selectedDragOptions; track c) {\n          <mat-chip\n            class=\"no-wrap\"\n            cdkDrag\n            removable=\"true\"\n            (removed)=\"returnOption(c)\"\n          >\n            {{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n            <mat-icon matChipRemove>cancel</mat-icon>\n          </mat-chip>\n          }\n        </mat-chip-list>\n      </div>\n    </div>\n    } } @if (generationModel === 'boolean-multi') {\n    <div class=\"fx-column-start-stretch\">\n      @for (pl of positionLabels; track pl; let i = $index) {\n      <mat-checkbox [(ngModel)]=\"booleanMultiSelections[i]\">{{\n        pl\n      }}</mat-checkbox>\n      }\n    </div>\n    } @if (generationModel === 'math-table') {\n    <div class=\"fx-column-start-stretch fx-gap-10\">\n      <mat-label>{{\n        \"coding.generate.math-table.mode-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"mathTableMode\" class=\"fx-column-start-start\">\n        <mat-radio-button [value]=\"'result-auto'\">{{\n          \"coding.generate.math-table.mode-result-auto\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'manual'\">{{\n          \"coding.generate.math-table.mode-manual\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n\n      @if (requiresMathTableExpectedResult()) {\n      <div class=\"fx-row-start-start fx-gap-10\">\n        <mat-form-field>\n          <mat-label>{{\n            \"coding.generate.math-table.expected-result\" | translate\n          }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"mathTableExpectedResult\"\n          />\n        </mat-form-field>\n        <div>\n          {{ \"coding.generate.math-table.expected-result-hint\" | translate }}\n        </div>\n      </div>\n\n      <div class=\"fx-column-start-stretch\">\n        <mat-label>{{\n          \"coding.generate.else-method.prompt\" | translate\n        }}</mat-label>\n        <mat-radio-group [(ngModel)]=\"elseMethod\" class=\"fx-gap-20\">\n          <mat-radio-button [value]=\"'auto'\">{{\n            \"coding.generate.else-method.auto\" | translate\n          }}</mat-radio-button>\n          <mat-radio-button [value]=\"'instruction'\">{{\n            \"coding.generate.else-method.instruction\" | translate\n          }}</mat-radio-button>\n          <mat-radio-button [value]=\"'none'\">{{\n            \"coding.generate.else-method.none\" | translate\n          }}</mat-radio-button>\n        </mat-radio-group>\n      </div>\n      }\n    </div>\n    } @if (generationModel === 'single-choice-some') {\n    <mat-selection-list [(ngModel)]=\"selectedOptions\" multiple=\"false\">\n      @for (c of options; track c) {\n      <mat-list-option [value]=\"c.value\">\n        '{{ c.value }}'{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n      </mat-list-option>\n      }\n      <div class=\"fx-row-end-center\">\n        <mat-label>{{\n          \"coding.generate.model.single-choice-long-version\" | translate\n        }}</mat-label>\n        <mat-checkbox\n          [(ngModel)]=\"singleChoiceLongVersion\"\n          [style.margin.px]=\"8\"\n        ></mat-checkbox>\n      </div>\n      <div>\n        {{\n          \"coding.generate.model.single-choice-\" +\n            (singleChoiceLongVersion\n              ? \"long-version-text\"\n              : \"short-version-text\") | translate\n        }}\n      </div>\n    </mat-selection-list>\n    } @if (generationModel === 'single-choice-many') {\n    <mat-form-field>\n      <mat-select [(value)]=\"selectedOption\">\n        @for (c of options; track c) {\n        <mat-option [value]=\"c.value\">\n          {{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n        </mat-option>\n        }\n      </mat-select>\n    </mat-form-field>\n    } @if (generationModel === 'simple-input') { @if (varInfo.multiple &&\n    positionLabels.length > 0) {\n    <mat-form-field>\n      <mat-label>Position</mat-label>\n      <mat-select [(value)]=\"selectedArrayPos\">\n        @for (pl of positionLabels; track pl; let i = $index) {\n        <mat-option [value]=\"i\">{{ pl }}</mat-option>\n        }\n      </mat-select>\n    </mat-form-field>\n    }\n    @if (isGeoGebraVariable) {\n    <div class=\"fx-column-start-stretch fx-gap-10\">\n      <div class=\"fx-row-start-center\">\n        <mat-label>{{\n          \"coding.generate.geogebra.extract-value\" | translate\n        }}</mat-label>\n        <mat-checkbox\n          [(ngModel)]=\"geogebraExtractValue\"\n          [disabled]=\"isGeoGebraPointMode()\"\n          [style.margin.px]=\"8\"\n        ></mat-checkbox>\n      </div>\n      <mat-label>{{\n        \"coding.generate.geogebra.mode-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group\n        [(ngModel)]=\"geogebraCodingMode\"\n        (ngModelChange)=\"setGeoGebraCodingMode($event)\"\n        class=\"fx-gap-20\"\n      >\n        <mat-radio-button [value]=\"'numeric'\">{{\n          \"coding.generate.geogebra.mode-numeric\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'angle'\">{{\n          \"coding.generate.geogebra.mode-angle\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'point'\">{{\n          \"coding.generate.geogebra.mode-point\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'boolean'\">{{\n          \"coding.generate.geogebra.mode-boolean\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'text'\">{{\n          \"coding.generate.geogebra.mode-text\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    } @else {\n    <div class=\"fx-row-start-center\">\n      <mat-label>{{\n        \"coding.generate.model.simple-input-numeric\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"textAsNumeric\"\n        [style.margin.px]=\"8\"\n      ></mat-checkbox>\n    </div>\n    }\n    } @if (isGeoGebraVariable && generationModel !== 'simple-input') {\n    <div class=\"fx-row-start-center\">\n      <mat-label>{{\n        \"coding.generate.geogebra.extract-value\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"geogebraExtractValue\"\n        [style.margin.px]=\"8\"\n      ></mat-checkbox>\n    </div>\n    } @if (isGeoGebraBooleanMode()) {\n    <div class=\"fx-column-start-stretch\">\n      <mat-label>{{\n        \"coding.generate.geogebra.boolean-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"geogebraBooleanValue\" class=\"fx-gap-20\">\n        <mat-radio-button [value]=\"'true'\">{{\n          \"rule.IS_TRUE\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'false'\">{{\n          \"rule.IS_FALSE\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    } @if (isGeoGebraPointMode()) {\n    <div class=\"fx-column-start-start\">\n      <div [style.font-weight]=\"'bold'\">\n        {{ \"coding.generate.geogebra.point-x\" | translate }}\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointX\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMoreThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMin\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXLessThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMax\" />\n        </mat-form-field>\n      </div>\n\n      <div [style.font-weight]=\"'bold'\">\n        {{ \"coding.generate.geogebra.point-y\" | translate }}\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointY\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMoreThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMin\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYLessThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMax\" />\n        </mat-form-field>\n      </div>\n    </div>\n    } @if (isNumericCodingMode()) {\n    <div class=\"fx-column-start-start\">\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMatch\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMoreThen\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMin\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericLessThen\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMax\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.true-code\" | translate }}:\n        </div>\n        <div [class]=\"numericRuleError ? 'rule-text-error' : 'rule-text-ok'\">\n          {{ numericRuleText }}\n        </div>\n      </div>\n    </div>\n    } @if (isTextInputCodingMode()) {\n    <div class=\"fx-row-start-start fx-gap-10\">\n      <mat-form-field>\n        <textarea\n          matInput\n          [(ngModel)]=\"selectedOption\"\n          cdkTextareaAutosize\n          cdkAutosizeMinRows=\"2\"\n          cdkAutosizeMaxRows=\"8\"\n        ></textarea>\n      </mat-form-field>\n      <div>\n        {{ \"coding.generate.model.simple-input-not-numeric\" | translate }}\n      </div>\n    </div>\n    } @if (generationModel === 'simple-input' || generationModel === 'integer'\n    || generationModel === 'geogebra-boolean') {\n    <div class=\"fx-column-start-stretch\">\n      <mat-label>{{\n        \"coding.generate.else-method.prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"elseMethod\" class=\"fx-gap-20\">\n        <mat-radio-button [value]=\"'auto'\">{{\n          \"coding.generate.else-method.auto\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'instruction'\">{{\n          \"coding.generate.else-method.instruction\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'none'\">{{\n          \"coding.generate.else-method.none\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    }\n    <p [style.font-style]=\"'italic'\">\n      {{ \"coding.generate.warning\" | translate }}\n    </p>\n  </div>\n  }\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button\n    mat-raised-button\n    color=\"primary\"\n    [disabled]=\"!canGenerate()\"\n    (click)=\"generateButtonClick()\"\n  >\n    {{ \"coding.generate.action\" | translate }}\n  </button>\n  <button mat-raised-button [mat-dialog-close]=\"false\">\n    {{ \"dialog-close\" | translate }}\n  </button>\n</mat-dialog-actions>\n", styles: [".chip-list-column{display:flex;flex-direction:column;gap:5px}.coding-action{background:#ccc;color:#000;padding:4px 10px}.dragOptionBox{border:darkgray 1px solid}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "component", type: MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "directive", type: CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "component", type: MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "component", type: MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "directive", type: MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: GenerateCodingDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatLabel,
                        MatCheckbox,
                        ReactiveFormsModule,
                        FormsModule,
                        MatSelectionList,
                        MatListOption,
                        CdkDropList,
                        MatChip,
                        CdkDrag,
                        MatIcon,
                        MatChipRemove,
                        MatFormField,
                        MatSelect,
                        MatOption,
                        MatInput,
                        CdkTextareaAutosize,
                        MatRadioGroup,
                        MatRadioButton,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule
                    ], template: "@if (varInfo) {\n<h1 mat-dialog-title>\n  {{ \"coding.generate.dialog-title\" | translate }} '{{\n    schemerService.getVariableAliasById(varInfo.id || \"?\")\n  }}'\n</h1>\n}\n<mat-dialog-content>\n  @if (varInfo) {\n  <div>\n    @for (info of ToTextFactory.varInfoAsText(varInfo); track info) {\n    <p>{{ info }}</p>\n    }\n  </div>\n  } @if (!varInfo) {\n  <div>\n    <p>{{ \"coding.generate.no-var-info\" | translate }}</p>\n  </div>\n  } @if (generationModel === 'none') {\n  <div [style.font-style]=\"'italic'\">\n    {{ \"coding.generate.model.none\" | translate }}\n  </div>\n  } @if (generationModel !== 'none') {\n  <div class=\"coding-action\">\n    <p [style.font-weight]=\"'bold'\">\n      {{ \"coding.generate.title\" | translate }}\n    </p>\n    <p>{{ \"coding.generate.model.\" + generationModel | translate }}</p>\n    @if (generationModel === 'multi-choice') {\n\n    <div class=\"fx-row-end-center\">\n      <mat-label [style.margin-right.px]=\"8\">{{\n        \"coding.generate.model.multi-choice-order-prompt\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"multiChoiceOrderMatters\"\n        (click)=\"resetOptions()\"\n      ></mat-checkbox>\n    </div>\n    @if (!multiChoiceOrderMatters) {\n    <mat-selection-list [(ngModel)]=\"selectedOptions\" multiple=\"true\">\n      @for (c of options; track c) {\n      <mat-list-option [value]=\"c.value\">\n        '{{ c.value }}'{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n      </mat-list-option>\n      }\n    </mat-selection-list>\n    } @if (multiChoiceOrderMatters) {\n    <div class=\"fx-column-start-stretch\">\n      <div>\n        {{ \"coding.generate.model.multi-choice-drag-prompt\" | translate }}\n      </div>\n      <div class=\"fx-row-start-stretch fx-gap-10\">\n        <mat-chip-list\n          class=\"dragOptionBox chip-list-column\"\n          cdkDropList\n          [style.width.%]=\"50\"\n          [style.max-height.px]=\"800\"\n          #optionSource=\"cdkDropList\"\n          [cdkDropListConnectedTo]=\"selectedOptions\"\n          [cdkDropListData]=\"options\"\n        >\n          @for (c of options; track c) {\n          <mat-chip cdkDrag\n            >{{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}</mat-chip\n          >\n          }\n        </mat-chip-list>\n        @if (positionLabels.length > 0) {\n        <div class=\"fx-column-start-stretch\" [style.width.px]=\"50\">\n          @for (pl of positionLabels; track pl) {\n          <p>{{ pl }}</p>\n          }\n        </div>\n        }\n        <mat-chip-list\n          cdkDropList\n          class=\"dragOptionBox chip-list-column fx-flex-fill\"\n          #selectedOptions=\"cdkDropList\"\n          [cdkDropListConnectedTo]=\"[optionSource]\"\n          [cdkDropListData]=\"selectedDragOptions\"\n          (cdkDropListDropped)=\"drop($event)\"\n        >\n          @for (c of selectedDragOptions; track c) {\n          <mat-chip\n            class=\"no-wrap\"\n            cdkDrag\n            removable=\"true\"\n            (removed)=\"returnOption(c)\"\n          >\n            {{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n            <mat-icon matChipRemove>cancel</mat-icon>\n          </mat-chip>\n          }\n        </mat-chip-list>\n      </div>\n    </div>\n    } } @if (generationModel === 'boolean-multi') {\n    <div class=\"fx-column-start-stretch\">\n      @for (pl of positionLabels; track pl; let i = $index) {\n      <mat-checkbox [(ngModel)]=\"booleanMultiSelections[i]\">{{\n        pl\n      }}</mat-checkbox>\n      }\n    </div>\n    } @if (generationModel === 'math-table') {\n    <div class=\"fx-column-start-stretch fx-gap-10\">\n      <mat-label>{{\n        \"coding.generate.math-table.mode-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"mathTableMode\" class=\"fx-column-start-start\">\n        <mat-radio-button [value]=\"'result-auto'\">{{\n          \"coding.generate.math-table.mode-result-auto\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'manual'\">{{\n          \"coding.generate.math-table.mode-manual\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n\n      @if (requiresMathTableExpectedResult()) {\n      <div class=\"fx-row-start-start fx-gap-10\">\n        <mat-form-field>\n          <mat-label>{{\n            \"coding.generate.math-table.expected-result\" | translate\n          }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"mathTableExpectedResult\"\n          />\n        </mat-form-field>\n        <div>\n          {{ \"coding.generate.math-table.expected-result-hint\" | translate }}\n        </div>\n      </div>\n\n      <div class=\"fx-column-start-stretch\">\n        <mat-label>{{\n          \"coding.generate.else-method.prompt\" | translate\n        }}</mat-label>\n        <mat-radio-group [(ngModel)]=\"elseMethod\" class=\"fx-gap-20\">\n          <mat-radio-button [value]=\"'auto'\">{{\n            \"coding.generate.else-method.auto\" | translate\n          }}</mat-radio-button>\n          <mat-radio-button [value]=\"'instruction'\">{{\n            \"coding.generate.else-method.instruction\" | translate\n          }}</mat-radio-button>\n          <mat-radio-button [value]=\"'none'\">{{\n            \"coding.generate.else-method.none\" | translate\n          }}</mat-radio-button>\n        </mat-radio-group>\n      </div>\n      }\n    </div>\n    } @if (generationModel === 'single-choice-some') {\n    <mat-selection-list [(ngModel)]=\"selectedOptions\" multiple=\"false\">\n      @for (c of options; track c) {\n      <mat-list-option [value]=\"c.value\">\n        '{{ c.value }}'{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n      </mat-list-option>\n      }\n      <div class=\"fx-row-end-center\">\n        <mat-label>{{\n          \"coding.generate.model.single-choice-long-version\" | translate\n        }}</mat-label>\n        <mat-checkbox\n          [(ngModel)]=\"singleChoiceLongVersion\"\n          [style.margin.px]=\"8\"\n        ></mat-checkbox>\n      </div>\n      <div>\n        {{\n          \"coding.generate.model.single-choice-\" +\n            (singleChoiceLongVersion\n              ? \"long-version-text\"\n              : \"short-version-text\") | translate\n        }}\n      </div>\n    </mat-selection-list>\n    } @if (generationModel === 'single-choice-many') {\n    <mat-form-field>\n      <mat-select [(value)]=\"selectedOption\">\n        @for (c of options; track c) {\n        <mat-option [value]=\"c.value\">\n          {{ c.value }}{{ c.label ? \" - \" : \"\" }}{{ c.label }}\n        </mat-option>\n        }\n      </mat-select>\n    </mat-form-field>\n    } @if (generationModel === 'simple-input') { @if (varInfo.multiple &&\n    positionLabels.length > 0) {\n    <mat-form-field>\n      <mat-label>Position</mat-label>\n      <mat-select [(value)]=\"selectedArrayPos\">\n        @for (pl of positionLabels; track pl; let i = $index) {\n        <mat-option [value]=\"i\">{{ pl }}</mat-option>\n        }\n      </mat-select>\n    </mat-form-field>\n    }\n    @if (isGeoGebraVariable) {\n    <div class=\"fx-column-start-stretch fx-gap-10\">\n      <div class=\"fx-row-start-center\">\n        <mat-label>{{\n          \"coding.generate.geogebra.extract-value\" | translate\n        }}</mat-label>\n        <mat-checkbox\n          [(ngModel)]=\"geogebraExtractValue\"\n          [disabled]=\"isGeoGebraPointMode()\"\n          [style.margin.px]=\"8\"\n        ></mat-checkbox>\n      </div>\n      <mat-label>{{\n        \"coding.generate.geogebra.mode-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group\n        [(ngModel)]=\"geogebraCodingMode\"\n        (ngModelChange)=\"setGeoGebraCodingMode($event)\"\n        class=\"fx-gap-20\"\n      >\n        <mat-radio-button [value]=\"'numeric'\">{{\n          \"coding.generate.geogebra.mode-numeric\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'angle'\">{{\n          \"coding.generate.geogebra.mode-angle\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'point'\">{{\n          \"coding.generate.geogebra.mode-point\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'boolean'\">{{\n          \"coding.generate.geogebra.mode-boolean\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'text'\">{{\n          \"coding.generate.geogebra.mode-text\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    } @else {\n    <div class=\"fx-row-start-center\">\n      <mat-label>{{\n        \"coding.generate.model.simple-input-numeric\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"textAsNumeric\"\n        [style.margin.px]=\"8\"\n      ></mat-checkbox>\n    </div>\n    }\n    } @if (isGeoGebraVariable && generationModel !== 'simple-input') {\n    <div class=\"fx-row-start-center\">\n      <mat-label>{{\n        \"coding.generate.geogebra.extract-value\" | translate\n      }}</mat-label>\n      <mat-checkbox\n        [(ngModel)]=\"geogebraExtractValue\"\n        [style.margin.px]=\"8\"\n      ></mat-checkbox>\n    </div>\n    } @if (isGeoGebraBooleanMode()) {\n    <div class=\"fx-column-start-stretch\">\n      <mat-label>{{\n        \"coding.generate.geogebra.boolean-prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"geogebraBooleanValue\" class=\"fx-gap-20\">\n        <mat-radio-button [value]=\"'true'\">{{\n          \"rule.IS_TRUE\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'false'\">{{\n          \"rule.IS_FALSE\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    } @if (isGeoGebraPointMode()) {\n    <div class=\"fx-column-start-start\">\n      <div [style.font-weight]=\"'bold'\">\n        {{ \"coding.generate.geogebra.point-x\" | translate }}\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointX\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMoreThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMin\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXLessThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointXMax\" />\n        </mat-form-field>\n      </div>\n\n      <div [style.font-weight]=\"'bold'\">\n        {{ \"coding.generate.geogebra.point-y\" | translate }}\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointY\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMoreThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMin\" />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYLessThen\" />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input matInput [(ngModel)]=\"geogebraPointYMax\" />\n        </mat-form-field>\n      </div>\n    </div>\n    } @if (isNumericCodingMode()) {\n    <div class=\"fx-column-start-start\">\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">{{ \"rule.NUMERIC_MATCH\" | translate }}</div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MATCH\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMatch\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.lower-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_MORE_THAN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMoreThen\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MIN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMin\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.upper-limit\" | translate }}\n        </div>\n        <mat-form-field>\n          <mat-label>{{ \"rule.NUMERIC_LESS_THAN\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericLessThen\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n        <mat-form-field [style.margin.px]=\"8\">\n          <mat-label>{{ \"rule.NUMERIC_MAX\" | translate }}</mat-label>\n          <input\n            matInput\n            [(ngModel)]=\"numericMax\"\n            (ngModelChange)=\"updateNumericRuleText()\"\n          />\n        </mat-form-field>\n      </div>\n      <div class=\"fx-row-start-center\">\n        <div [style.width.px]=\"200\">\n          {{ \"coding.generate.true-code\" | translate }}:\n        </div>\n        <div [class]=\"numericRuleError ? 'rule-text-error' : 'rule-text-ok'\">\n          {{ numericRuleText }}\n        </div>\n      </div>\n    </div>\n    } @if (isTextInputCodingMode()) {\n    <div class=\"fx-row-start-start fx-gap-10\">\n      <mat-form-field>\n        <textarea\n          matInput\n          [(ngModel)]=\"selectedOption\"\n          cdkTextareaAutosize\n          cdkAutosizeMinRows=\"2\"\n          cdkAutosizeMaxRows=\"8\"\n        ></textarea>\n      </mat-form-field>\n      <div>\n        {{ \"coding.generate.model.simple-input-not-numeric\" | translate }}\n      </div>\n    </div>\n    } @if (generationModel === 'simple-input' || generationModel === 'integer'\n    || generationModel === 'geogebra-boolean') {\n    <div class=\"fx-column-start-stretch\">\n      <mat-label>{{\n        \"coding.generate.else-method.prompt\" | translate\n      }}</mat-label>\n      <mat-radio-group [(ngModel)]=\"elseMethod\" class=\"fx-gap-20\">\n        <mat-radio-button [value]=\"'auto'\">{{\n          \"coding.generate.else-method.auto\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'instruction'\">{{\n          \"coding.generate.else-method.instruction\" | translate\n        }}</mat-radio-button>\n        <mat-radio-button [value]=\"'none'\">{{\n          \"coding.generate.else-method.none\" | translate\n        }}</mat-radio-button>\n      </mat-radio-group>\n    </div>\n    }\n    <p [style.font-style]=\"'italic'\">\n      {{ \"coding.generate.warning\" | translate }}\n    </p>\n  </div>\n  }\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button\n    mat-raised-button\n    color=\"primary\"\n    [disabled]=\"!canGenerate()\"\n    (click)=\"generateButtonClick()\"\n  >\n    {{ \"coding.generate.action\" | translate }}\n  </button>\n  <button mat-raised-button [mat-dialog-close]=\"false\">\n    {{ \"dialog-close\" | translate }}\n  </button>\n</mat-dialog-actions>\n", styles: [".chip-list-column{display:flex;flex-direction:column;gap:5px}.coding-action{background:#ccc;color:#000;padding:4px 10px}.dragOptionBox{border:darkgray 1px solid}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1.TranslateService }, { type: SchemerService }, { type: i4.MatDialogRef }] });

class ShowCodingDialogComponent {
    constructor(showCodingData) {
        this.showCodingData = showCodingData;
        this.varCoding = showCodingData.varCoding;
        this.isSimpleMode = showCodingData.mode === 'SIMPLE';
        this.updateText(this.isSimpleMode);
    }
    updateText(newValue) {
        const booleanValue = typeof newValue === 'boolean' ? newValue : newValue.checked;
        this.mode = booleanValue ? 'SIMPLE' : 'EXTENDED';
        this.varCodingText = {
            id: this.varCoding.alias || this.varCoding.id,
            label: this.varCoding.label || '',
            source: ToTextFactory.sourceAsText(this.varCoding.alias || this.varCoding.id, this.varCoding.sourceType, this.varCoding.deriveSources || []),
            processing: ToTextFactory.processingAsText(this.varCoding.processing || [], this.varCoding.fragmenting),
            hasManualInstruction: !!this.varCoding.manualInstruction,
            codes: (this.varCoding.codes || []).map(code => ToTextFactory.codeAsText(code, this.mode))
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ShowCodingDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>
      {{ varCoding.alias || varCoding.id
      }}{{ varCoding.label ? ' - ' + varCoding.label : '' }}
    </h1>

    <mat-dialog-content>
      <div class="fx-row-end-center">
        <mat-slide-toggle
          [(ngModel)]="isSimpleMode"
          (change)="updateText($event)"
        >
          {{ 'show-coding.simple-mode-label' | translate }}</mat-slide-toggle
        >
      </div>
      <div class="info">
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'manual-instruction.coding.source' | translate }}:
          </div>
          <div class="fx-flex-fill">{{ varCodingText?.source }}</div>
        </div>
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'processing.prompt' | translate }}:
          </div>
          <div class="fx-flex-fill">
            {{ varCodingText?.processing || 'keine' }}
          </div>
        </div>
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'manual-instruction.coding.title' | translate }}:
          </div>
          <div class="fx-flex-fill">
            {{ varCodingText?.hasManualInstruction ? 'ja' : 'keine' }}
          </div>
        </div>
      </div>
      <h3>Codes</h3>
      @if (varCodingText && varCodingText.codes && varCodingText.codes.length >
      0) {
      <div class="fx-row-start-center" [style.font-weight]="'bold'">
        <div class="fx-flex-row-10" [style.text-align]="'center'">Code</div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">Score</div>
        <div class="fx-flex-row-20">Titel</div>
        <div class="fx-flex-fill">Bedingung(en)</div>
        <div class="fx-flex-row-15" [style.text-align]="'center'">
          Instruktion
        </div>
      </div>
      @for (codeText of varCodingText.codes; track codeText) {
      <div class="fx-row-start-center code-row">
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.id }}
        </div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.score }}
        </div>
        <div class="fx-flex-row-20">{{ codeText.label }}</div>
        <div class="fx-flex-fill">
          @if (codeText.ruleSetDescriptions.length > 1) {
          <ul>
            @for (d of codeText.ruleSetDescriptions; track d) {
            <li>{{ d }}</li>
            }
          </ul>
          } @if (codeText.ruleSetDescriptions.length > 1) {
          <p>
            Verknüpfung der Regelsätze:
            {{ codeText.ruleSetOperatorAnd ? 'UND' : 'ODER' }}
          </p>
          } @if (codeText.ruleSetDescriptions.length === 1) {
          <p>{{ codeText.ruleSetDescriptions[0] }}</p>
          } @if (codeText.ruleSetDescriptions.length < 1) {
          <p>keine</p>
          }
        </div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.hasManualInstruction ? 'ja' : '-' }}
        </div>
      </div>
      } } @if (varCodingText && varCodingText.codes &&
      varCodingText.codes.length === 0) {
      <div>keine</div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="mode">
        {{ 'dialog-close' | translate }}
      </button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".code-row:nth-child(2n){background-color:#f1f1f1}\n", ".info{margin-top:20px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>
      {{ varCoding.alias || varCoding.id
      }}{{ varCoding.label ? ' - ' + varCoding.label : '' }}
    </h1>

    <mat-dialog-content>
      <div class="fx-row-end-center">
        <mat-slide-toggle
          [(ngModel)]="isSimpleMode"
          (change)="updateText($event)"
        >
          {{ 'show-coding.simple-mode-label' | translate }}</mat-slide-toggle
        >
      </div>
      <div class="info">
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'manual-instruction.coding.source' | translate }}:
          </div>
          <div class="fx-flex-fill">{{ varCodingText?.source }}</div>
        </div>
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'processing.prompt' | translate }}:
          </div>
          <div class="fx-flex-fill">
            {{ varCodingText?.processing || 'keine' }}
          </div>
        </div>
        <div class="fx-row-start-center">
          <div class="fx-flex-row-20">
            {{ 'manual-instruction.coding.title' | translate }}:
          </div>
          <div class="fx-flex-fill">
            {{ varCodingText?.hasManualInstruction ? 'ja' : 'keine' }}
          </div>
        </div>
      </div>
      <h3>Codes</h3>
      @if (varCodingText && varCodingText.codes && varCodingText.codes.length >
      0) {
      <div class="fx-row-start-center" [style.font-weight]="'bold'">
        <div class="fx-flex-row-10" [style.text-align]="'center'">Code</div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">Score</div>
        <div class="fx-flex-row-20">Titel</div>
        <div class="fx-flex-fill">Bedingung(en)</div>
        <div class="fx-flex-row-15" [style.text-align]="'center'">
          Instruktion
        </div>
      </div>
      @for (codeText of varCodingText.codes; track codeText) {
      <div class="fx-row-start-center code-row">
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.id }}
        </div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.score }}
        </div>
        <div class="fx-flex-row-20">{{ codeText.label }}</div>
        <div class="fx-flex-fill">
          @if (codeText.ruleSetDescriptions.length > 1) {
          <ul>
            @for (d of codeText.ruleSetDescriptions; track d) {
            <li>{{ d }}</li>
            }
          </ul>
          } @if (codeText.ruleSetDescriptions.length > 1) {
          <p>
            Verknüpfung der Regelsätze:
            {{ codeText.ruleSetOperatorAnd ? 'UND' : 'ODER' }}
          </p>
          } @if (codeText.ruleSetDescriptions.length === 1) {
          <p>{{ codeText.ruleSetDescriptions[0] }}</p>
          } @if (codeText.ruleSetDescriptions.length < 1) {
          <p>keine</p>
          }
        </div>
        <div class="fx-flex-row-10" [style.text-align]="'center'">
          {{ codeText.hasManualInstruction ? 'ja' : '-' }}
        </div>
      </div>
      } } @if (varCodingText && varCodingText.codes &&
      varCodingText.codes.length === 0) {
      <div>keine</div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="mode">
        {{ 'dialog-close' | translate }}
      </button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule,
                        MatSlideToggle,
                        FormsModule
                    ], styles: [".code-row:nth-child(2n){background-color:#f1f1f1}\n", ".info{margin-top:20px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

const AnchorId = Mark.create({
    name: 'anchorId',
    addAttributes() {
        return {
            anchorId: {
                default: '',
                parseHTML: element => element.getAttribute('data-anchor-id'),
                renderHTML: attributes => {
                    if (!attributes['anchorId']) {
                        return {};
                    }
                    return {
                        'data-anchor-id': attributes['anchorId']
                    };
                }
            },
            parentAnchorId: {
                default: '',
                parseHTML: element => element.getAttribute('data-parent-anchor-id'),
                renderHTML: attributes => {
                    if (!attributes['parentAnchorId']) {
                        return {};
                    }
                    return {
                        'data-parent-anchor-id': attributes['parentAnchorId']
                    };
                }
            },
            anchorColor: {
                default: '',
                parseHTML: element => element.getAttribute('data-anchor-color') || element.style.backgroundColor,
                renderHTML: attributes => {
                    if (!attributes['anchorColor']) {
                        return {};
                    }
                    return {
                        'data-anchor-color': attributes['anchorColor'],
                        style: `background-color: ${attributes['anchorColor']};`
                    };
                }
            },
            parentAnchorColor: {
                default: '',
                parseHTML: element => element.getAttribute('data-parent-anchor-color'),
                renderHTML: attributes => {
                    if (!attributes['parentAnchorColor']) {
                        return {};
                    }
                    return {
                        'data-parent-anchor-color': attributes['parentAnchorColor']
                    };
                }
            }
        };
    },
    parseHTML() {
        return [
            {
                tag: 'aspect-anchor'
            }
        ];
    },
    renderHTML({ HTMLAttributes }) {
        return ['aspect-anchor', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0];
    },
    addCommands() {
        return {
            toggleAnchorId: attributes => ({ commands }) => commands.toggleMark(this.name, attributes),
            setAnchorId: attributes => ({ commands }) => commands.setMark(this.name, attributes)
        };
    }
});

const Indent = Extension.create({
    name: 'indent',
    addOptions() {
        return {
            types: ['listItem', 'paragraph'],
            minLevel: 0,
            maxLevel: 8
        };
    },
    addGlobalAttributes() {
        return [
            {
                types: this.options.types,
                attributes: {
                    indent: {
                        renderHTML: attributes => ({
                            style: `padding-left: ${attributes['indent'] * attributes['indentSize']}px`,
                            indent: attributes['indent'],
                            indentSize: attributes['indentSize']
                        }),
                        parseHTML: element => Number(element.getAttribute('indent'))
                    },
                    indentSize: {
                        default: 20,
                        parseHTML: element => Number(element.getAttribute('indentSize'))
                    }
                }
            }
        ];
    },
    addCommands() {
        const setNodeIndentMarkup = (tr, pos, delta, indentSize) => {
            const node = tr?.doc?.nodeAt(pos);
            if (node) {
                const nextLevel = (node.attrs['indent'] || 0) + delta;
                const { minLevel, maxLevel } = this.options;
                let indent;
                if (nextLevel < minLevel) {
                    indent = minLevel;
                }
                else {
                    indent = nextLevel > maxLevel ? maxLevel : nextLevel;
                }
                if (indent !== node.attrs['indent']) {
                    const nodeAttrs = { ...node.attrs, indent, indentSize };
                    return tr.setNodeMarkup(pos, node.type, nodeAttrs, node.marks);
                }
            }
            return tr;
        };
        const updateIndentLevel = (tr, delta, indentSize) => {
            const { doc, selection } = tr;
            let transaction = tr;
            if (doc && selection && (selection instanceof TextSelection)) {
                const { from, to } = selection;
                doc.nodesBetween(from, to, (node, pos) => {
                    if (this.options.types.includes(node.type.name)) {
                        transaction = setNodeIndentMarkup(tr, pos, delta, indentSize);
                        return false;
                    }
                    return true;
                });
            }
            return transaction;
        };
        const applyIndent = (direction, indentSize) => () => ({ tr, state, dispatch }) => {
            const { selection } = state;
            let transaction;
            transaction = tr.setSelection(selection);
            transaction = updateIndentLevel(transaction, direction, indentSize);
            if (transaction.docChanged) {
                dispatch?.(transaction);
                return true;
            }
            return false;
        };
        return {
            indent: indentSize => applyIndent(1, indentSize)(),
            outdent: indentSize => applyIndent(-1, indentSize)()
        };
    },
    addKeyboardShortcuts() {
        return {
            Tab: () => this.editor.commands.indent(20),
            'Shift-Tab': () => this.editor.commands.outdent(20)
        };
    }
});

const HangingIndent = Extension.create({
    name: 'hangingIndent',
    addOptions() {
        return {
            types: ['paragraph']
        };
    },
    addGlobalAttributes() {
        return [
            {
                types: this.options.types,
                attributes: {
                    hangingIndent: {
                        default: false,
                        renderHTML: attributes => (attributes['hangingIndent'] ?
                            { style: `text-indent: -${attributes['indentSize']}px` } :
                            { style: 'text-indent: 0px' }),
                        parseHTML: element => element.style.textIndent !== '0px'
                    },
                    indentSize: {
                        default: 20,
                        parseHTML: element => Number(element.getAttribute('indentSize'))
                    }
                }
            }
        ];
    },
    addCommands() {
        const setNodeIndentMarkup = (tr, pos, hangingIndent, indentSize) => {
            const node = tr?.doc?.nodeAt(pos);
            if (node) {
                if (hangingIndent !== node.attrs['indent']) {
                    const nodeAttrs = { ...node.attrs, hangingIndent, indentSize };
                    return tr.setNodeMarkup(pos, node.type, nodeAttrs, node.marks);
                }
            }
            return tr;
        };
        const updateIndentLevel = (tr, hangingIndent, indentSize) => {
            const { doc, selection } = tr;
            if (doc && selection && (selection instanceof TextSelection)) {
                const { from, to } = selection;
                doc.nodesBetween(from, to, (node, pos) => {
                    setNodeIndentMarkup(tr, pos, hangingIndent, indentSize);
                    return false;
                });
            }
            return tr;
        };
        const applyIndent = (hangingIndent, indentSize) => () => ({ tr, state, dispatch }) => {
            const { selection } = state;
            let transaction;
            transaction = tr.setSelection(selection);
            transaction = updateIndentLevel(transaction, hangingIndent, indentSize);
            if (transaction.docChanged) {
                dispatch?.(transaction);
                return true;
            }
            return false;
        };
        return {
            hangIndent: indentSize => applyIndent(true, indentSize)(),
            unhangIndent: indentSize => applyIndent(false, indentSize)()
        };
    }
});

const ParagraphExtension = Paragraph.extend({
    addAttributes() {
        return {
            margin: {
                default: 0,
                parseHTML: element => Number(element.style.marginBottom.slice(0, -2)),
                renderHTML: attributes => ({
                    style: `margin-bottom: ${attributes['margin']}px; margin-top: 0;min-height: 1em;`
                })
            }
        };
    },
    addCommands() {
        const setNodeIndentMarkup = (tr, pos, newMargin) => {
            const node = tr?.doc?.nodeAt(pos);
            if (node) {
                const nodeAttrs = { ...node.attrs, margin: newMargin };
                return tr.setNodeMarkup(pos, node.type, nodeAttrs, node.marks);
            }
            return tr;
        };
        const applyMargin = newMargin => () => ({ tr, state, dispatch }) => {
            const { selection } = state;
            let transaction;
            tr.doc.nodesBetween(selection.from, selection.to, (node, pos) => {
                transaction = setNodeIndentMarkup(tr, pos, newMargin);
            });
            dispatch?.(transaction);
            return true;
        };
        return {
            setMargin: (newMargin) => applyMargin(newMargin)()
        };
    }
});

const FontSize = Extension.create({
    name: 'fontSize',
    addOptions() {
        return {
            types: ['textStyle']
        };
    },
    addGlobalAttributes() {
        return [{
                types: this.options.types,
                attributes: {
                    fontSize: {
                        default: '20px',
                        parseHTML: element => element.style.fontSize,
                        renderHTML: attributes => ({ style: `font-size: ${attributes['fontSize']}` })
                    }
                }
            }];
    },
    addCommands() {
        return {
            setFontSize: fontSize => ({ chain }) => chain().setMark('textStyle', { fontSize }).run()
        };
    }
});

const BulletListExtension = BulletList.extend({
    addAttributes() {
        return {
            listStyle: {
                default: 'disc',
                parseHTML: element => element.style.listStyleType,
                renderHTML: attributes => ({ style: `list-style: ${attributes['listStyle']};` })
            }
        };
    },
    addCommands() {
        return {
            ...this.parent?.(),
            setBulletListStyle: (newStyle) => ({ commands }) => commands.updateAttributes(this.name, { listStyle: newStyle })
        };
    },
    addInputRules() {
        return [];
    }
});

const OrderedListExtension = OrderedList.extend({
    addAttributes() {
        return {
            listStyle: {
                default: 'upper-roman',
                parseHTML: element => element.style.listStyleType,
                renderHTML: attributes => ({ style: `list-style: ${attributes['listStyle']}` })
            },
            fontSize: {
                default: '20px',
                parseHTML: element => element.style.fontSize,
                renderHTML: attributes => ({ style: `font-size: ${attributes['fontSize']}` })
            }
        };
    },
    addCommands() {
        return {
            ...this.parent?.(),
            setOrderedListStyle: (newStyle) => ({ commands }) => (commands.updateAttributes(this.name, { listStyle: newStyle })),
            setOrderedListFontSize: (fontSize) => ({ commands }) => (commands.updateAttributes(this.name, { fontSize: fontSize }))
        };
    },
    addInputRules() {
        return [];
    }
});

const BlockImage = Image.extend({
    name: 'blockImage',
    addOptions() {
        return {
            ...this.parent?.(),
            allowBase64: true
        };
    },
    addAttributes() {
        return {
            ...this.parent?.(),
            style: {
                default: null,
                renderHTML: attributes => {
                    if (attributes['style'] && !this.options.inline) {
                        return {
                            'data-style': attributes['style'],
                            style: attributes['style']
                        };
                    }
                    return {};
                }
            }
        };
    },
    parseHTML() {
        return [
            {
                tag: 'img',
                getAttrs: () => !this.options.inline && null
            }
        ];
    },
    addCommands() {
        return {
            insertBlockImage: (options) => ({ commands }) => commands.insertContent({ type: this.name, attrs: options })
        };
    }
});

class FileService {
    static saveToFile(fileContent, filename) {
        const anchor = document.createElement('a');
        anchor.download = filename;
        anchor.href = window.URL.createObjectURL(new File([fileContent], filename));
        anchor.click();
    }
    static async loadFile(fileTypes = [], asBase64 = false) {
        return new Promise((resolve, reject) => {
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = fileTypes.join(','); // Set allowable file types
            // eslint-disable-next-line consistent-return
            fileInput.addEventListener('change', event => {
                const inputElement = event.target;
                const uploadedFile = inputElement.files?.[0]; // Get the selected file
                if (!uploadedFile) {
                    return reject(new Error('No file selected or file is invalid.'));
                }
                const reader = new FileReader();
                // Resolves when file is successfully read
                reader.onload = () => resolve(reader.result);
                // Rejects if reading encounters an error
                reader.onerror = () => reject(new Error('Error reading file.'));
                // Read file content as Base64 or plain text
                asBase64 ? reader.readAsDataURL(uploadedFile) : reader.readAsText(uploadedFile);
            });
            // Trigger the file picker
            fileInput.click();
        });
    }
    static loadImage() {
        return FileService.loadFile(['image/*'], true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: FileService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: FileService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: FileService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ComboButtonComponent {
    constructor() {
        this.isActive = false;
        this.applySelection = new EventEmitter();
        this.selectionChanged = new EventEmitter();
        this.isOpen = false;
    }
    selectValue(value) {
        this.selectionChanged.emit(value);
        this.isOpen = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ComboButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ComboButtonComponent, isStandalone: true, selector: "aspect-combo-button", inputs: { inputType: "inputType", selectedValue: "selectedValue", availableValues: "availableValues", tooltip: "tooltip", icon: "icon", isActive: "isActive" }, outputs: { applySelection: "applySelection", selectionChanged: "selectionChanged" }, ngImport: i0, template: `
    <div class="root-panel"
      [style.background-color]="inputType === 'color' ? selectedValue : isActive ? 'lightgrey' : 'unset'">
      <button class="apply-button" mat-icon-button [matTooltip]="tooltip"
        (click)="applySelection.emit()">
        <mat-icon>{{icon}}</mat-icon>
      </button>

      @if (inputType == 'color') {
        <button class="select-trigger-button" type="button" (click)="input.click()">
          <svg viewBox="0 0 24 24" width="24px" height="24px" focusable="false" aria-hidden="true">
            <path d="M7 10l5 5 5-5z"></path>
          </svg>
        </button>
        <input matInput type="color" #input hidden
          (input)="selectionChanged.emit($any($event.target).value); applySelection.emit()">
      }

      @if (inputType == 'list') {
        <button class="select-trigger-button" type="button" cdkOverlayOrigin #trigger="cdkOverlayOrigin"
          (click)="isOpen = !isOpen">
          <svg viewBox="0 0 24 24" width="24px" height="24px" focusable="false" aria-hidden="true">
            <path d="M7 10l5 5 5-5z"></path>
          </svg>
        </button>
        <ng-template cdkConnectedOverlay
          [cdkConnectedOverlayOrigin]="trigger"
          [cdkConnectedOverlayOpen]="isOpen"
          (overlayOutsideClick)="isOpen = false">
          <mat-action-list class="list-box">
            @for (value of availableValues; track value) {
              <button
              mat-list-item (click)="selectValue(value)">{{value}}</button>
            }
          </mat-action-list>
        </ng-template>
      }
    </div>
    `, isInline: true, styles: [".root-panel{display:flex;flex-direction:row;border:1px solid;border-radius:5px}mat-select{margin-top:20%}.list-box{background-color:#fff}.select-trigger-button{width:24px;border:unset;background-color:unset;padding:unset}.apply-button{height:42px;padding-top:9px}\n"], dependencies: [{ kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation", "cdkConnectedOverlayUsePopover", "cdkConnectedOverlayMatchWidth", "cdkConnectedOverlay"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "component", type: MatActionList, selector: "mat-action-list", exportAs: ["matActionList"] }, { kind: "component", type: MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ComboButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'aspect-combo-button', template: `
    <div class="root-panel"
      [style.background-color]="inputType === 'color' ? selectedValue : isActive ? 'lightgrey' : 'unset'">
      <button class="apply-button" mat-icon-button [matTooltip]="tooltip"
        (click)="applySelection.emit()">
        <mat-icon>{{icon}}</mat-icon>
      </button>

      @if (inputType == 'color') {
        <button class="select-trigger-button" type="button" (click)="input.click()">
          <svg viewBox="0 0 24 24" width="24px" height="24px" focusable="false" aria-hidden="true">
            <path d="M7 10l5 5 5-5z"></path>
          </svg>
        </button>
        <input matInput type="color" #input hidden
          (input)="selectionChanged.emit($any($event.target).value); applySelection.emit()">
      }

      @if (inputType == 'list') {
        <button class="select-trigger-button" type="button" cdkOverlayOrigin #trigger="cdkOverlayOrigin"
          (click)="isOpen = !isOpen">
          <svg viewBox="0 0 24 24" width="24px" height="24px" focusable="false" aria-hidden="true">
            <path d="M7 10l5 5 5-5z"></path>
          </svg>
        </button>
        <ng-template cdkConnectedOverlay
          [cdkConnectedOverlayOrigin]="trigger"
          [cdkConnectedOverlayOpen]="isOpen"
          (overlayOutsideClick)="isOpen = false">
          <mat-action-list class="list-box">
            @for (value of availableValues; track value) {
              <button
              mat-list-item (click)="selectValue(value)">{{value}}</button>
            }
          </mat-action-list>
        </ng-template>
      }
    </div>
    `, standalone: true, imports: [
                        MatIconButton, MatTooltipModule, MatIcon, MatInput,
                        CdkOverlayOrigin, CdkConnectedOverlay, MatActionList, MatListItem
                    ], styles: [".root-panel{display:flex;flex-direction:row;border:1px solid;border-radius:5px}mat-select{margin-top:20%}.list-box{background-color:#fff}.select-trigger-button{width:24px;border:unset;background-color:unset;padding:unset}.apply-button{height:42px;padding-top:9px}\n"] }]
        }], propDecorators: { inputType: [{
                type: Input
            }], selectedValue: [{
                type: Input
            }], availableValues: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], icon: [{
                type: Input
            }], isActive: [{
                type: Input
            }], applySelection: [{
                type: Output
            }], selectionChanged: [{
                type: Output
            }] } });

const PLACEHOLDER_REGEX = /\\placeholder(?:\[[^\]]*])?\{([^{}]*)}/g;
const EMPTY_SCRIPT_REGEX = /([_^])\{\s*}/g;
const EXPONENTIAL_E_REGEX = /\\exponentialE\b/g;
const normalizeFormulaLatex = (latex) => latex
    .trim()
    .replace(PLACEHOLDER_REGEX, '$1')
    .replace(EMPTY_SCRIPT_REGEX, '')
    .replace(EXPONENTIAL_E_REGEX, '\\mathrm{e}');

class FormulaEditDialogComponent {
    constructor(data, sanitizer) {
        this.data = data;
        this.sanitizer = sanitizer;
        this.latex = '';
        this.renderedFormula = null;
        this.latex = normalizeFormulaLatex(data.latex || '');
        this.updatePreview();
    }
    ngAfterViewInit() {
        if (this.mathFieldRef) {
            this.mathFieldRef.nativeElement.value = this.latex;
            this.mathFieldRef.nativeElement.focus();
        }
    }
    onMathInput(event) {
        const source = event.target;
        const rawLatex = source.getValue?.('latex') ?? source.value ?? '';
        this.latex = normalizeFormulaLatex(rawLatex);
        this.updatePreview();
    }
    updatePreview() {
        const normalizedLatex = normalizeFormulaLatex(this.latex);
        if (!normalizedLatex) {
            this.renderedFormula = null;
            return;
        }
        this.renderedFormula = this.sanitizer.bypassSecurityTrustHtml(katex.renderToString(normalizedLatex, {
            output: 'mathml',
            throwOnError: false,
            strict: 'ignore'
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: FormulaEditDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: FormulaEditDialogComponent, isStandalone: true, selector: "ng-component", viewQueries: [{ propertyName: "mathFieldRef", first: true, predicate: ["mathField"], descendants: true }], ngImport: i0, template: `
    <h1 mat-dialog-title>{{ data.title }}</h1>
    <mat-dialog-content class="dialog-content">
      <!--suppress HtmlUnknownTag -->
      <math-field #mathField (input)="onMathInput($event)"></math-field>
      @if (renderedFormula) {
      <div class="preview" [innerHTML]="renderedFormula"></div>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button [mat-dialog-close]="false">
        {{ 'dialog-cancel' | translate }}
      </button>
      <button
        mat-raised-button
        color="primary"
        [disabled]="!latex.trim()"
        [mat-dialog-close]="latex.trim()"
      >
        {{ 'dialog-save' | translate }}
      </button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".dialog-content{display:flex;flex-direction:column;gap:12px}math-field{min-height:48px;width:100%}.preview{border:1px solid #ccc;border-radius:4px;min-height:48px;padding:8px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: FormulaEditDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>{{ data.title }}</h1>
    <mat-dialog-content class="dialog-content">
      <!--suppress HtmlUnknownTag -->
      <math-field #mathField (input)="onMathInput($event)"></math-field>
      @if (renderedFormula) {
      <div class="preview" [innerHTML]="renderedFormula"></div>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button [mat-dialog-close]="false">
        {{ 'dialog-cancel' | translate }}
      </button>
      <button
        mat-raised-button
        color="primary"
        [disabled]="!latex.trim()"
        [mat-dialog-close]="latex.trim()"
      >
        {{ 'dialog-save' | translate }}
      </button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatDialogClose,
                        MatButton,
                        TranslateModule
                    ], schemas: [CUSTOM_ELEMENTS_SCHEMA], styles: [".dialog-content{display:flex;flex-direction:column;gap:12px}math-field{min-height:48px;width:100%}.preview{border:1px solid #ccc;border-radius:4px;min-height:48px;padding:8px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.DomSanitizer }], propDecorators: { mathFieldRef: [{
                type: ViewChild,
                args: ['mathField']
            }] } });

const renderFormula$1 = (latex) => katex.renderToString(latex, {
    output: 'mathml',
    throwOnError: false,
    strict: 'ignore'
});
const IqbMathFormula = Node.create({
    name: 'iqbMathFormula',
    group: 'inline',
    inline: true,
    atom: true,
    selectable: true,
    addOptions() {
        return {
            onFormulaClick: () => { }
        };
    },
    addAttributes() {
        return {
            latex: {
                default: '',
                parseHTML: element => element.getAttribute('data-latex') || ''
            }
        };
    },
    parseHTML() {
        return [{ tag: 'span.iqb-math-formula[data-latex]' }];
    },
    renderHTML({ HTMLAttributes }) {
        const latex = normalizeFormulaLatex((HTMLAttributes['latex'] || '').toString());
        const attributesWithoutLatex = { ...HTMLAttributes };
        delete attributesWithoutLatex['latex'];
        const content = document.createElement('span');
        content.innerHTML = renderFormula$1(latex);
        return ['span',
            mergeAttributes(attributesWithoutLatex, {
                class: 'iqb-math-formula',
                'data-latex': latex
            }),
            content
        ];
    },
    addCommands() {
        return {
            insertIqbMathFormula: latex => ({ commands }) => commands.insertContent({
                type: this.name,
                attrs: {
                    latex: normalizeFormulaLatex(latex)
                }
            })
        };
    },
    addProseMirrorPlugins() {
        return [
            new Plugin({
                props: {
                    handleClickOn: (_view, _pos, node, nodePos) => {
                        if (node.type.name !== this.name) {
                            return false;
                        }
                        this.options.onFormulaClick(node.attrs['latex'] || '', nodePos);
                        return true;
                    }
                }
            })
        ];
    }
});

const FORMULA_TOKEN_REGEX = /\[\[iqb-math:([\s\S]*?)]]/g;
const renderFormula = (latex) => {
    const formula = normalizeFormulaLatex(latex);
    if (!formula)
        return '';
    return katex.renderToString(formula, {
        output: 'mathml',
        throwOnError: false,
        strict: 'ignore'
    });
};
const decodeTokenFormula = (encodedFormula) => {
    try {
        return decodeURIComponent(encodedFormula);
    }
    catch {
        return encodedFormula;
    }
};
const renderManualInstructionMath = (html) => {
    if (!html)
        return html;
    const withTokensRendered = html.replace(FORMULA_TOKEN_REGEX, (_, encodedFormula) => {
        const latex = normalizeFormulaLatex(decodeTokenFormula(encodedFormula));
        const escapedLatex = latex.replace(/"/g, '&quot;');
        return `<span class="iqb-math-formula" data-latex="${escapedLatex}">${renderFormula(latex)}</span>`;
    });
    const container = document.createElement('div');
    container.innerHTML = withTokensRendered;
    container.querySelectorAll('span.iqb-math-formula[data-latex]').forEach(node => {
        const latex = node.getAttribute('data-latex') || '';
        node.innerHTML = renderFormula(latex);
    });
    return container.innerHTML;
};

class RichTextEditorComponent {
    constructor(editFormulaDialog) {
        this.editFormulaDialog = editFormulaDialog;
        this.clozeMode = false;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.contentChange = new EventEmitter();
        this.selectedFontColor = 'lightgrey';
        this.selectedHighlightColor = 'lightgrey';
        this.selectedFontSize = '20px';
        this.selectedIndentSize = 20;
        this.bulletListStyle = 'disc';
        this.orderedListStyle = 'decimal';
        this.defaultExtensions = [
            Document, Text, ListItem,
            Underline, Superscript, Subscript,
            TextStyle, Color,
            Bold, Italic, Strike, History,
            Highlight.configure({
                multicolor: true
            }),
            AnchorId,
            TextAlign.configure({
                types: ['paragraph', 'heading']
            }),
            Indent.configure({
                types: ['listItem', 'paragraph'],
                minLevel: 0,
                maxLevel: 4
            }),
            Heading.configure({
                levels: [1, 2, 3, 4]
            }),
            ParagraphExtension,
            FontSize,
            BulletListExtension,
            OrderedListExtension,
            HangingIndent,
            BlockImage,
            Blockquote,
            IqbMathFormula.configure({
                onFormulaClick: (latex, position) => this.editFormulaAtPosition(latex, position)
            })
        ];
        this.editor = new Editor({
            extensions: this.defaultExtensions
        });
    }
    ngAfterViewInit() {
        this.editor.commands.focus();
    }
    ngOnChanges(changes) {
        if (changes['content']) {
            if (typeof this.content === 'string') {
                this.editorContent = renderManualInstructionMath(this.content);
            }
            else {
                this.editorContent = this.content;
            }
        }
    }
    toggleBold() {
        this.editor.chain().toggleBold().focus().run();
    }
    toggleItalic() {
        this.editor.chain().toggleItalic().focus().run();
    }
    toggleUnderline() {
        this.editor.chain().toggleUnderline().focus().run();
    }
    toggleStrike() {
        this.editor.commands.toggleStrike();
    }
    toggleSuperscript() {
        this.editor.chain().toggleSuperscript().focus().run();
    }
    toggleSubscript() {
        this.editor.chain().toggleSubscript().focus().run();
    }
    applyFontSize(size) {
        this.selectedFontSize = size;
        this.editor.commands.setFontSize(size);
    }
    applyFontColor() {
        this.editor.chain().focus().setColor(this.selectedFontColor).run();
    }
    applyHighlightColor() {
        this.editor.chain().focus().toggleHighlight({ color: this.selectedHighlightColor }).run();
    }
    alignText(direction) {
        this.editor.chain().focus().setTextAlign(direction).run();
    }
    indent() {
        this.editor.commands.indent(this.selectedIndentSize);
    }
    outdent() {
        this.editor.commands.outdent(this.selectedIndentSize);
    }
    toggleBulletList() {
        this.editor.chain().toggleBulletList().focus().run();
        this.editor.commands.setBulletListStyle(this.bulletListStyle);
    }
    toggleOrderedList() {
        this.editor.chain().toggleOrderedList().focus().run();
        this.editor.commands.setOrderedListStyle(this.orderedListStyle);
        this.editor.commands.setOrderedListFontSize(this.selectedFontSize);
    }
    applyListStyle(listType, style) {
        if (listType === 'bulletList') {
            this.bulletListStyle = style;
            this.editor.commands.setBulletListStyle(style);
            if (!this.editor.isActive('bulletList')) {
                this.toggleBulletList();
            }
        }
        else {
            this.orderedListStyle = style;
            this.editor.commands.setOrderedListStyle(style);
            this.editor.commands.setOrderedListFontSize(this.selectedFontSize);
            if (!this.editor.isActive('orderedList')) {
                this.toggleOrderedList();
            }
        }
    }
    toggleHeading(level) {
        if (!level) {
            this.editor.commands.toggleNode('heading', 'paragraph');
        }
        else {
            this.editor.commands.toggleHeading({ level: Number(level) });
        }
    }
    applyParagraphStyle(margin) {
        this.editor.commands.setMargin(margin);
    }
    insertSpecialChar(char) {
        this.editor.chain().insertContent(char).focus().run();
    }
    hangIndent() {
        this.editor.commands.indent(this.selectedIndentSize);
        this.editor.commands.hangIndent(this.selectedIndentSize);
    }
    unhangIndent() {
        this.editor.commands.outdent(this.selectedIndentSize);
        this.editor.commands.unhangIndent(this.selectedIndentSize);
    }
    async insertBlockImage(alignment) {
        const mediaSrc = await FileService.loadImage();
        switch (alignment) {
            case 'left': {
                this.editor.commands.insertBlockImage({ src: mediaSrc, style: 'float: left; margin-right: 10px;' });
                break;
            }
            case 'right': {
                this.editor.commands.insertBlockImage({ src: mediaSrc, style: 'float: right; margin-left: 10px' });
                break;
            }
            default: {
                this.editor.commands.insertBlockImage({ src: mediaSrc });
            }
        }
    }
    toggleBlockquote() {
        this.editor.commands.toggleBlockquote();
    }
    insertFormula() {
        const dialogRef = this.editFormulaDialog.open(FormulaEditDialogComponent, {
            width: '700px',
            data: {
                title: 'Formel einfügen',
                latex: ''
            },
            autoFocus: false
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
            if (typeof dialogResult === 'string' && normalizeFormulaLatex(dialogResult)) {
                this.editor.chain()
                    .insertIqbMathFormula(normalizeFormulaLatex(dialogResult))
                    .focus()
                    .run();
            }
        });
    }
    onContentChanged(value) {
        this.editorContent = value;
        this.contentChange.emit(value);
    }
    editFormulaAtPosition(latex, position) {
        const dialogRef = this.editFormulaDialog.open(FormulaEditDialogComponent, {
            width: '700px',
            data: {
                title: 'Formel bearbeiten',
                latex
            },
            autoFocus: false
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
            if (typeof dialogResult === 'string' && normalizeFormulaLatex(dialogResult)) {
                const transaction = this.editor.state.tr.setNodeMarkup(position, null, {
                    latex: normalizeFormulaLatex(dialogResult)
                });
                this.editor.view.dispatch(transaction);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RichTextEditorComponent, deps: [{ token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.24", type: RichTextEditorComponent, isStandalone: true, selector: "aspect-rich-text-editor", inputs: { content: "content", defaultFontSize: "defaultFontSize", editorHeightPx: "editorHeightPx", clozeMode: "clozeMode" }, outputs: { contentChange: "contentChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"editor-control-panel fx-column-start-stretch\">\n  <div class=\"fx-row-space-between-stretch\">\n    <fieldset class=\"fx-row-start-stretch\" [style.background-color]=\"'transparent'\">\n      <legend>Schriftauszeichnung</legend>\n      <button mat-icon-button matTooltip=\"Fett\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('bold')\"\n              (click)=\"toggleBold()\">\n        <mat-icon>format_bold</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Kursiv\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('italic')\"\n              (click)=\"toggleItalic()\">\n        <mat-icon>format_italic</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Unterstrichen\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('underline')\"\n              (click)=\"toggleUnderline()\" style=\"text-decoration: underline\">\n        <mat-icon>format_underlined</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Hochgestellt\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('superscript')\"\n              (click)=\"toggleSuperscript()\">\n        <mat-icon>superscript</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Tiefgestellt\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('subscript')\"\n              (click)=\"toggleSubscript()\">\n        <mat-icon>subscript</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Durchgestrichen\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('strike')\"\n              (click)=\"toggleStrike()\">\n        <mat-icon>strikethrough_s</mat-icon>\n      </button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\" [style.gap.px]=\"5\">\n      <legend>Schrift</legend>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Gr\u00F6\u00DFe</mat-label>\n        <mat-select [value]=\"editor.getAttributes('textStyle')['fontSize']?.toString() || selectedFontSize\">\n          <mat-option (click)=\"applyFontSize('8px')\" value=\"8px\">8px</mat-option>\n          <mat-option (click)=\"applyFontSize('10px')\" value=\"10px\">10px</mat-option>\n          <mat-option (click)=\"applyFontSize('12px')\" value=\"12px\">12px</mat-option>\n          <mat-option (click)=\"applyFontSize('14px')\" value=\"14px\">14px</mat-option>\n          <mat-option (click)=\"applyFontSize('16px')\" value=\"16px\">16px</mat-option>\n          <mat-option (click)=\"applyFontSize('18px')\" value=\"18px\">18px</mat-option>\n          <mat-option (click)=\"applyFontSize('20px')\" value=\"20px\">20px</mat-option>\n          <mat-option (click)=\"applyFontSize('22px')\" value=\"22px\">22px</mat-option>\n          <mat-option (click)=\"applyFontSize('24px')\" value=\"24px\">24px</mat-option>\n          <mat-option (click)=\"applyFontSize('26px')\" value=\"26px\">26px</mat-option>\n          <mat-option (click)=\"applyFontSize('28px')\" value=\"28px\">28px</mat-option>\n          <mat-option (click)=\"applyFontSize('30px')\" value=\"30px\">30px</mat-option>\n          <mat-option (click)=\"applyFontSize('36px')\" value=\"36px\">36px</mat-option>\n        </mat-select>\n      </mat-form-field>\n      <aspect-combo-button [inputType]=\"'color'\" [selectedValue]=\"selectedFontColor\"\n                           [tooltip]=\"'Textfarbe'\" [icon]=\"'format_color_text'\"\n                           (applySelection)=\"applyFontColor()\"\n                           (selectionChanged)=\"selectedFontColor = $event\">\n      </aspect-combo-button>\n      <aspect-combo-button [inputType]=\"'color'\" [selectedValue]=\"selectedHighlightColor\"\n                           [tooltip]=\"'Texthintergrund'\" [icon]=\"'format_color_fill'\"\n                           (applySelection)=\"applyHighlightColor()\"\n                           (selectionChanged)=\"selectedHighlightColor = $event\">\n      </aspect-combo-button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\" [style.gap.px]=\"5\" >\n      <legend>Absatz</legend>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"135\">\n        <mat-label>Typ</mat-label>\n        <mat-select [value]=\"editor.getAttributes('heading')['level']?.toString() || ''\"\n                    (valueChange)=\"toggleHeading($event)\">\n          <mat-option value=\"1\">H1</mat-option>\n          <mat-option value=\"2\">H2</mat-option>\n          <mat-option value=\"3\">H3</mat-option>\n          <mat-option value=\"4\">H4</mat-option>\n          <mat-option value=\"\">Paragraph</mat-option>\n        </mat-select>\n      </mat-form-field>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Abstand</mat-label>\n        <mat-select matTooltip=\"Achtung: Gilt nur f\u00FCr zuk\u00FCnftig angelegte Abs\u00E4tze\" [matTooltipShowDelay]=\"300\"\n                    [value]=\"editor.getAttributes('paragraph')['margin']?.toString() || '0'\"\n                    (click)=\"$any($event).stopPropagation()\" (valueChange)=\"applyParagraphStyle($event)\">\n          <mat-option value=\"0\">0px</mat-option>\n          <mat-option value=\"10\">10px</mat-option>\n          <mat-option value=\"20\">20px</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\" [style.gap.px]=\"5\">\n      <legend>Listen</legend>\n      <aspect-combo-button [inputType]=\"'list'\"\n                           [selectedValue]=\"editor.getAttributes('bulletList')['listStyle']\"\n                           [availableValues]=\"['disc', 'circle', 'square']\"\n                           [tooltip]=\"'Aufz\u00E4hlung'\" [icon]=\"'format_list_bulleted'\"\n                           [isActive]=\"editor.isActive('bulletList')\"\n                           (applySelection)=\"toggleBulletList()\"\n                           (selectionChanged)=\"applyListStyle('bulletList', $event)\">\n      </aspect-combo-button>\n      <aspect-combo-button [inputType]=\"'list'\"\n                           [selectedValue]=\"editor.getAttributes('orderedList')['listStyle']\"\n                           [availableValues]=\"['decimal', 'lower-latin', 'upper-latin',\n                                               'lower-roman', 'upper-roman', 'lower-greek']\"\n                           [tooltip]=\"'Aufz\u00E4hlung (nummeriert)'\" [icon]=\"'format_list_numbered'\"\n                           [isActive]=\"editor.isActive('orderedList')\"\n                           (applySelection)=\"toggleOrderedList()\"\n                           (selectionChanged)=\"applyListStyle('orderedList', $event)\">\n      </aspect-combo-button>\n    </fieldset>\n  </div>\n\n  <div class=\"fx-row-space-between-stretch\">\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Textausrichtung</legend>\n      <button mat-icon-button matTooltip=\"Linksb\u00FCndig\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'left' })\"\n              (click)=\"alignText('left')\">\n        <mat-icon>format_align_left</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Rechtsb\u00FCndig\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'right' })\"\n              (click)=\"alignText('right')\">\n        <mat-icon>format_align_right</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Zentriert\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'center' })\"\n              (click)=\"alignText('center')\">\n        <mat-icon>format_align_center</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Blocksatz\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'justify' })\"\n              (click)=\"alignText('justify')\">\n        <mat-icon>format_align_justify</mat-icon>\n      </button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\">\n      <legend>Einr\u00FCckung</legend>\n      <button mat-icon-button matTooltip=\"Einr\u00FCcken\" [matTooltipShowDelay]=\"300\"\n              (click)=\"indent()\">\n        <mat-icon>format_indent_increase</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Einr\u00FCckung verringern\" [matTooltipShowDelay]=\"300\"\n              (click)=\"outdent()\">\n        <mat-icon>format_indent_decrease</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"H\u00E4ngende Einr\u00FCckung\" [matTooltipShowDelay]=\"300\"\n              (click)=\"hangIndent()\">\n        <mat-icon>segment</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"H\u00E4ngende Einr\u00FCckung entfernen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"unhangIndent()\">\n        <mat-icon>view_headline</mat-icon>\n      </button>\n      <mat-form-field class=\"indent-size-input\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Tiefe</mat-label>\n        <input matInput type=\"text\" [(ngModel)]=\"selectedIndentSize\">\n      </mat-form-field>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Bild</legend>\n      <button mat-icon-button matTooltip=\"Bild in eigenem Absatz einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('none')\">\n        <mat-icon style=\"transform: scale(0.9);\">image</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Bild rechts einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('right')\">\n        <mat-icon style=\"transform: scale(-1.5, 1.5);\">art_track</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Bild links einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('left')\">\n        <mat-icon style=\"transform: scale(1.5);\">art_track</mat-icon>\n      </button>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Sonderzeichen</legend>\n      <button mat-icon-button class=\"special-chars-button\" matTooltip=\"Sonderzeichen\" [matTooltipShowDelay]=\"300\"\n              [matMenuTriggerFor]=\"specialCharsMenu\">\n        <mat-icon>emoji_symbols</mat-icon>\n      </button>\n      <mat-menu #specialCharsMenu=\"matMenu\" yPosition=\"above\">\n        <button mat-button (click)=\"insertSpecialChar('&nbsp;')\"\n                [matTooltip]=\"'Nicht umbrechendes Leerzeichen'\">&blank;</button>\n        <button mat-button (click)=\"insertSpecialChar('&#8239;')\"\n                [matTooltip]=\"'Schmales nicht umbrechendes Leerzeichen'\">&blank;<sub>2</sub></button>\n        <button mat-button (click)=\"insertSpecialChar('&ndash;')\"\n                [matTooltip]=\"'Halbgeviertstrich'\">&ndash;</button>\n        <button mat-button (click)=\"insertSpecialChar('&#8209;')\"\n                [matTooltip]=\"'Nicht umbrechender Viertelgeviertstrich'\">\u2014</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&lsquo;')\"\n                [matTooltip]=\"'Einfaches Anf\u00FChrungszeichen links'\">&lsquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rsquo;')\"\n                [matTooltip]=\"'Einfaches Anf\u00FChrungszeichen rechts'\">&rsquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&sbquo;')\"\n                [matTooltip]=\"'Niedriges Komma-Anf\u00FChrungszeichen'\">&sbquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&bdquo;')\"\n                [matTooltip]=\"'Doppeltes Anf\u00FChrungszeichen unten'\">&bdquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ldquo;')\"\n                [matTooltip]=\"'Doppeltes Anf\u00FChrungszeichen oben'\">&ldquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rdquo;')\"\n                [matTooltip]=\"'Rechtes doppeltes Anf\u00FChrungszeichen'\">&rdquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&lsaquo;')\"\n                [matTooltip]=\"'Einfaches spitzes Anf\u00FChrungszeichen links'\">&lsaquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rsaquo;')\"\n                [matTooltip]=\"'Einfaches spitzes Anf\u00FChrungszeichen rechts'\">&rsaquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&laquo;')\"\n                [matTooltip]=\"'Doppeltes spitzes Anf\u00FChrungszeichen links'\">&laquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&raquo;')\"\n                [matTooltip]=\"'Doppeltes spitzes Anf\u00FChrungszeichen rechts'\">&raquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&micro;')\">&micro;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ccedil;')\">&ccedil;</button>\n        <button mat-button (click)=\"insertSpecialChar('&Ccedil;')\">&Ccedil;</button>\n        <button mat-button (click)=\"insertSpecialChar('&AElig;')\">&AElig;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&female;')\">&female;</button>\n        <button mat-button (click)=\"insertSpecialChar('&male;')\">&male;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&cent;')\">&cent;</button>\n        <button mat-button (click)=\"insertSpecialChar('&pound;')\">&pound;</button>\n        <button mat-button (click)=\"insertSpecialChar('&yen;')\">&yen;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&copy;')\">&copy;</button>\n        <button mat-button (click)=\"insertSpecialChar('&reg;')\">&reg;</button>\n        <button mat-button (click)=\"insertSpecialChar('&trade;')\">&trade;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&le;')\">&le;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ge;')\">&ge;</button>\n        <button mat-button (click)=\"insertSpecialChar('&fpartint;')\">&fpartint;</button>\n        <button mat-button (click)=\"insertSpecialChar('&sum;')\">&sum;</button>\n        <button mat-button (click)=\"insertSpecialChar('&isin;')\">&isin;</button>\n        <button mat-button (click)=\"insertSpecialChar('&notin;')\">&notin;</button>\n        <button mat-button (click)=\"insertSpecialChar('&radic;')\">&radic;</button>\n        <button mat-button (click)=\"insertSpecialChar('&infin;')\">&infin;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&spades;')\">&spades;</button>\n        <button mat-button (click)=\"insertSpecialChar('&clubs;')\">&clubs;</button>\n        <button mat-button (click)=\"insertSpecialChar('&hearts;')\">&hearts;</button>\n        <button mat-button (click)=\"insertSpecialChar('&diams;')\">&diams;</button>\n      </mat-menu>\n      <button mat-icon-button matTooltip=\"Formel einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertFormula()\">\n        <mat-icon>functions</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Zitat\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('blockquote')\"\n              (click)=\"toggleBlockquote()\">\n        <mat-icon>format_quote</mat-icon>\n      </button>\n    </fieldset>\n  </div>\n</div>\n<div class=\"editor-wrapper\"\n     [style.height.px]=\"editorHeightPx\">\n  <tiptap-editor [editor]=\"editor\" [ngModel]=\"editorContent\"\n                 [outputFormat]=\"clozeMode ? 'json' : 'html'\"\n                 [style.font-size.px]=\"defaultFontSize\"\n                 (ngModelChange)=\"onContentChanged($event)\">\n  </tiptap-editor>\n</div>\n", styles: [".editor-wrapper{display:block;border:lightgrey solid 1px;overflow-x:auto}:host ::ng-deep div.ProseMirror{height:99%;outline:none}:host ::ng-deep .ProseMirror p strong{letter-spacing:.02em!important;font-weight:750!important}:host ::ng-deep .ProseMirror span.iqb-math-formula{background-color:#e8f2ff;border-radius:3px;cursor:pointer;display:inline-block;padding:0 4px}:host ::ng-deep .ProseMirror h1{font-weight:700;font-size:20px}:host ::ng-deep .ProseMirror h2{font-weight:700;font-size:18px}:host ::ng-deep .ProseMirror h3{font-weight:700;font-size:16px}:host ::ng-deep .ProseMirror h4{font-weight:400;font-size:16px}::ng-deep mark{color:inherit}:host ::ng-deep .ProseMirror tooltip{background-color:#eee}button.active{background-color:#d3d3d3}.editor-control-panel{margin-bottom:20px;font:unset;max-width:1100px;margin-left:auto;margin-right:auto}:host ::ng-deep .dropdown .mat-mdc-form-field-infix{min-height:unset;padding-top:10px;padding-bottom:10px}:host ::ng-deep .dropdown .mdc-notched-outline__notch{max-width:unset!important}:host ::ng-deep .indent-size-input .mat-mdc-form-field-flex{height:45px}:host ::ng-deep .indent-size-input .mat-mdc-form-field-infix{padding-top:10px;padding-bottom:10px}:host fieldset{height:55px;box-sizing:content-box!important;border-radius:3px;padding:5px 5px 10px}.fx-column-start-stretch{box-sizing:border-box;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.fx-row-start-stretch{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch}.fx-row-start-start{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start}.fx-row-space-between-stretch{box-sizing:border-box;display:flex;flex-direction:row;justify-content:space-between;align-items:stretch}.fx-row-space-around-center{box-sizing:border-box;display:flex;flex-direction:row;justify-content:space-around;align-items:center}\n"], dependencies: [{ kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "component", type: MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: ComboButtonComponent, selector: "aspect-combo-button", inputs: ["inputType", "selectedValue", "availableValues", "tooltip", "icon", "isActive"], outputs: ["applySelection", "selectionChanged"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: TiptapEditorDirective, selector: "tiptap[editor], [tiptap][editor], tiptap-editor[editor], [tiptapEditor][editor]", inputs: ["editor", "outputFormat"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RichTextEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'aspect-rich-text-editor', standalone: true, imports: [
                        MatIconButton, MatTooltip, MatIcon, MatFormField, MatLabel, MatSelect, MatOption,
                        ComboButtonComponent, MatInput, ReactiveFormsModule, FormsModule,
                        MatMenuTrigger, MatMenu, MatButton, TiptapEditorDirective
                    ], template: "<div class=\"editor-control-panel fx-column-start-stretch\">\n  <div class=\"fx-row-space-between-stretch\">\n    <fieldset class=\"fx-row-start-stretch\" [style.background-color]=\"'transparent'\">\n      <legend>Schriftauszeichnung</legend>\n      <button mat-icon-button matTooltip=\"Fett\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('bold')\"\n              (click)=\"toggleBold()\">\n        <mat-icon>format_bold</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Kursiv\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('italic')\"\n              (click)=\"toggleItalic()\">\n        <mat-icon>format_italic</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Unterstrichen\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('underline')\"\n              (click)=\"toggleUnderline()\" style=\"text-decoration: underline\">\n        <mat-icon>format_underlined</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Hochgestellt\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('superscript')\"\n              (click)=\"toggleSuperscript()\">\n        <mat-icon>superscript</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Tiefgestellt\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('subscript')\"\n              (click)=\"toggleSubscript()\">\n        <mat-icon>subscript</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Durchgestrichen\" [matTooltipPosition]=\"'above'\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('strike')\"\n              (click)=\"toggleStrike()\">\n        <mat-icon>strikethrough_s</mat-icon>\n      </button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\" [style.gap.px]=\"5\">\n      <legend>Schrift</legend>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Gr\u00F6\u00DFe</mat-label>\n        <mat-select [value]=\"editor.getAttributes('textStyle')['fontSize']?.toString() || selectedFontSize\">\n          <mat-option (click)=\"applyFontSize('8px')\" value=\"8px\">8px</mat-option>\n          <mat-option (click)=\"applyFontSize('10px')\" value=\"10px\">10px</mat-option>\n          <mat-option (click)=\"applyFontSize('12px')\" value=\"12px\">12px</mat-option>\n          <mat-option (click)=\"applyFontSize('14px')\" value=\"14px\">14px</mat-option>\n          <mat-option (click)=\"applyFontSize('16px')\" value=\"16px\">16px</mat-option>\n          <mat-option (click)=\"applyFontSize('18px')\" value=\"18px\">18px</mat-option>\n          <mat-option (click)=\"applyFontSize('20px')\" value=\"20px\">20px</mat-option>\n          <mat-option (click)=\"applyFontSize('22px')\" value=\"22px\">22px</mat-option>\n          <mat-option (click)=\"applyFontSize('24px')\" value=\"24px\">24px</mat-option>\n          <mat-option (click)=\"applyFontSize('26px')\" value=\"26px\">26px</mat-option>\n          <mat-option (click)=\"applyFontSize('28px')\" value=\"28px\">28px</mat-option>\n          <mat-option (click)=\"applyFontSize('30px')\" value=\"30px\">30px</mat-option>\n          <mat-option (click)=\"applyFontSize('36px')\" value=\"36px\">36px</mat-option>\n        </mat-select>\n      </mat-form-field>\n      <aspect-combo-button [inputType]=\"'color'\" [selectedValue]=\"selectedFontColor\"\n                           [tooltip]=\"'Textfarbe'\" [icon]=\"'format_color_text'\"\n                           (applySelection)=\"applyFontColor()\"\n                           (selectionChanged)=\"selectedFontColor = $event\">\n      </aspect-combo-button>\n      <aspect-combo-button [inputType]=\"'color'\" [selectedValue]=\"selectedHighlightColor\"\n                           [tooltip]=\"'Texthintergrund'\" [icon]=\"'format_color_fill'\"\n                           (applySelection)=\"applyHighlightColor()\"\n                           (selectionChanged)=\"selectedHighlightColor = $event\">\n      </aspect-combo-button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\" [style.gap.px]=\"5\" >\n      <legend>Absatz</legend>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"135\">\n        <mat-label>Typ</mat-label>\n        <mat-select [value]=\"editor.getAttributes('heading')['level']?.toString() || ''\"\n                    (valueChange)=\"toggleHeading($event)\">\n          <mat-option value=\"1\">H1</mat-option>\n          <mat-option value=\"2\">H2</mat-option>\n          <mat-option value=\"3\">H3</mat-option>\n          <mat-option value=\"4\">H4</mat-option>\n          <mat-option value=\"\">Paragraph</mat-option>\n        </mat-select>\n      </mat-form-field>\n      <mat-form-field class=\"dropdown\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Abstand</mat-label>\n        <mat-select matTooltip=\"Achtung: Gilt nur f\u00FCr zuk\u00FCnftig angelegte Abs\u00E4tze\" [matTooltipShowDelay]=\"300\"\n                    [value]=\"editor.getAttributes('paragraph')['margin']?.toString() || '0'\"\n                    (click)=\"$any($event).stopPropagation()\" (valueChange)=\"applyParagraphStyle($event)\">\n          <mat-option value=\"0\">0px</mat-option>\n          <mat-option value=\"10\">10px</mat-option>\n          <mat-option value=\"20\">20px</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\" [style.gap.px]=\"5\">\n      <legend>Listen</legend>\n      <aspect-combo-button [inputType]=\"'list'\"\n                           [selectedValue]=\"editor.getAttributes('bulletList')['listStyle']\"\n                           [availableValues]=\"['disc', 'circle', 'square']\"\n                           [tooltip]=\"'Aufz\u00E4hlung'\" [icon]=\"'format_list_bulleted'\"\n                           [isActive]=\"editor.isActive('bulletList')\"\n                           (applySelection)=\"toggleBulletList()\"\n                           (selectionChanged)=\"applyListStyle('bulletList', $event)\">\n      </aspect-combo-button>\n      <aspect-combo-button [inputType]=\"'list'\"\n                           [selectedValue]=\"editor.getAttributes('orderedList')['listStyle']\"\n                           [availableValues]=\"['decimal', 'lower-latin', 'upper-latin',\n                                               'lower-roman', 'upper-roman', 'lower-greek']\"\n                           [tooltip]=\"'Aufz\u00E4hlung (nummeriert)'\" [icon]=\"'format_list_numbered'\"\n                           [isActive]=\"editor.isActive('orderedList')\"\n                           (applySelection)=\"toggleOrderedList()\"\n                           (selectionChanged)=\"applyListStyle('orderedList', $event)\">\n      </aspect-combo-button>\n    </fieldset>\n  </div>\n\n  <div class=\"fx-row-space-between-stretch\">\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Textausrichtung</legend>\n      <button mat-icon-button matTooltip=\"Linksb\u00FCndig\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'left' })\"\n              (click)=\"alignText('left')\">\n        <mat-icon>format_align_left</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Rechtsb\u00FCndig\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'right' })\"\n              (click)=\"alignText('right')\">\n        <mat-icon>format_align_right</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Zentriert\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'center' })\"\n              (click)=\"alignText('center')\">\n        <mat-icon>format_align_center</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Blocksatz\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive({ textAlign: 'justify' })\"\n              (click)=\"alignText('justify')\">\n        <mat-icon>format_align_justify</mat-icon>\n      </button>\n    </fieldset>\n    <fieldset class=\"fx-row-start-start\">\n      <legend>Einr\u00FCckung</legend>\n      <button mat-icon-button matTooltip=\"Einr\u00FCcken\" [matTooltipShowDelay]=\"300\"\n              (click)=\"indent()\">\n        <mat-icon>format_indent_increase</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Einr\u00FCckung verringern\" [matTooltipShowDelay]=\"300\"\n              (click)=\"outdent()\">\n        <mat-icon>format_indent_decrease</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"H\u00E4ngende Einr\u00FCckung\" [matTooltipShowDelay]=\"300\"\n              (click)=\"hangIndent()\">\n        <mat-icon>segment</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"H\u00E4ngende Einr\u00FCckung entfernen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"unhangIndent()\">\n        <mat-icon>view_headline</mat-icon>\n      </button>\n      <mat-form-field class=\"indent-size-input\" appearance=\"outline\" [style.width.px]=\"90\">\n        <mat-label>Tiefe</mat-label>\n        <input matInput type=\"text\" [(ngModel)]=\"selectedIndentSize\">\n      </mat-form-field>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Bild</legend>\n      <button mat-icon-button matTooltip=\"Bild in eigenem Absatz einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('none')\">\n        <mat-icon style=\"transform: scale(0.9);\">image</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Bild rechts einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('right')\">\n        <mat-icon style=\"transform: scale(-1.5, 1.5);\">art_track</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Bild links einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertBlockImage('left')\">\n        <mat-icon style=\"transform: scale(1.5);\">art_track</mat-icon>\n      </button>\n    </fieldset>\n\n    <fieldset class=\"fx-row-start-stretch\">\n      <legend>Sonderzeichen</legend>\n      <button mat-icon-button class=\"special-chars-button\" matTooltip=\"Sonderzeichen\" [matTooltipShowDelay]=\"300\"\n              [matMenuTriggerFor]=\"specialCharsMenu\">\n        <mat-icon>emoji_symbols</mat-icon>\n      </button>\n      <mat-menu #specialCharsMenu=\"matMenu\" yPosition=\"above\">\n        <button mat-button (click)=\"insertSpecialChar('&nbsp;')\"\n                [matTooltip]=\"'Nicht umbrechendes Leerzeichen'\">&blank;</button>\n        <button mat-button (click)=\"insertSpecialChar('&#8239;')\"\n                [matTooltip]=\"'Schmales nicht umbrechendes Leerzeichen'\">&blank;<sub>2</sub></button>\n        <button mat-button (click)=\"insertSpecialChar('&ndash;')\"\n                [matTooltip]=\"'Halbgeviertstrich'\">&ndash;</button>\n        <button mat-button (click)=\"insertSpecialChar('&#8209;')\"\n                [matTooltip]=\"'Nicht umbrechender Viertelgeviertstrich'\">\u2014</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&lsquo;')\"\n                [matTooltip]=\"'Einfaches Anf\u00FChrungszeichen links'\">&lsquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rsquo;')\"\n                [matTooltip]=\"'Einfaches Anf\u00FChrungszeichen rechts'\">&rsquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&sbquo;')\"\n                [matTooltip]=\"'Niedriges Komma-Anf\u00FChrungszeichen'\">&sbquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&bdquo;')\"\n                [matTooltip]=\"'Doppeltes Anf\u00FChrungszeichen unten'\">&bdquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ldquo;')\"\n                [matTooltip]=\"'Doppeltes Anf\u00FChrungszeichen oben'\">&ldquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rdquo;')\"\n                [matTooltip]=\"'Rechtes doppeltes Anf\u00FChrungszeichen'\">&rdquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&lsaquo;')\"\n                [matTooltip]=\"'Einfaches spitzes Anf\u00FChrungszeichen links'\">&lsaquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&rsaquo;')\"\n                [matTooltip]=\"'Einfaches spitzes Anf\u00FChrungszeichen rechts'\">&rsaquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&laquo;')\"\n                [matTooltip]=\"'Doppeltes spitzes Anf\u00FChrungszeichen links'\">&laquo;</button>\n        <button mat-button (click)=\"insertSpecialChar('&raquo;')\"\n                [matTooltip]=\"'Doppeltes spitzes Anf\u00FChrungszeichen rechts'\">&raquo;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&micro;')\">&micro;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ccedil;')\">&ccedil;</button>\n        <button mat-button (click)=\"insertSpecialChar('&Ccedil;')\">&Ccedil;</button>\n        <button mat-button (click)=\"insertSpecialChar('&AElig;')\">&AElig;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&female;')\">&female;</button>\n        <button mat-button (click)=\"insertSpecialChar('&male;')\">&male;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&cent;')\">&cent;</button>\n        <button mat-button (click)=\"insertSpecialChar('&pound;')\">&pound;</button>\n        <button mat-button (click)=\"insertSpecialChar('&yen;')\">&yen;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&copy;')\">&copy;</button>\n        <button mat-button (click)=\"insertSpecialChar('&reg;')\">&reg;</button>\n        <button mat-button (click)=\"insertSpecialChar('&trade;')\">&trade;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&le;')\">&le;</button>\n        <button mat-button (click)=\"insertSpecialChar('&ge;')\">&ge;</button>\n        <button mat-button (click)=\"insertSpecialChar('&fpartint;')\">&fpartint;</button>\n        <button mat-button (click)=\"insertSpecialChar('&sum;')\">&sum;</button>\n        <button mat-button (click)=\"insertSpecialChar('&isin;')\">&isin;</button>\n        <button mat-button (click)=\"insertSpecialChar('&notin;')\">&notin;</button>\n        <button mat-button (click)=\"insertSpecialChar('&radic;')\">&radic;</button>\n        <button mat-button (click)=\"insertSpecialChar('&infin;')\">&infin;</button>\n        <br>\n        <button mat-button (click)=\"insertSpecialChar('&spades;')\">&spades;</button>\n        <button mat-button (click)=\"insertSpecialChar('&clubs;')\">&clubs;</button>\n        <button mat-button (click)=\"insertSpecialChar('&hearts;')\">&hearts;</button>\n        <button mat-button (click)=\"insertSpecialChar('&diams;')\">&diams;</button>\n      </mat-menu>\n      <button mat-icon-button matTooltip=\"Formel einf\u00FCgen\" [matTooltipShowDelay]=\"300\"\n              (click)=\"insertFormula()\">\n        <mat-icon>functions</mat-icon>\n      </button>\n      <button mat-icon-button matTooltip=\"Zitat\" [matTooltipShowDelay]=\"300\"\n              [class.active]=\"editor.isActive('blockquote')\"\n              (click)=\"toggleBlockquote()\">\n        <mat-icon>format_quote</mat-icon>\n      </button>\n    </fieldset>\n  </div>\n</div>\n<div class=\"editor-wrapper\"\n     [style.height.px]=\"editorHeightPx\">\n  <tiptap-editor [editor]=\"editor\" [ngModel]=\"editorContent\"\n                 [outputFormat]=\"clozeMode ? 'json' : 'html'\"\n                 [style.font-size.px]=\"defaultFontSize\"\n                 (ngModelChange)=\"onContentChanged($event)\">\n  </tiptap-editor>\n</div>\n", styles: [".editor-wrapper{display:block;border:lightgrey solid 1px;overflow-x:auto}:host ::ng-deep div.ProseMirror{height:99%;outline:none}:host ::ng-deep .ProseMirror p strong{letter-spacing:.02em!important;font-weight:750!important}:host ::ng-deep .ProseMirror span.iqb-math-formula{background-color:#e8f2ff;border-radius:3px;cursor:pointer;display:inline-block;padding:0 4px}:host ::ng-deep .ProseMirror h1{font-weight:700;font-size:20px}:host ::ng-deep .ProseMirror h2{font-weight:700;font-size:18px}:host ::ng-deep .ProseMirror h3{font-weight:700;font-size:16px}:host ::ng-deep .ProseMirror h4{font-weight:400;font-size:16px}::ng-deep mark{color:inherit}:host ::ng-deep .ProseMirror tooltip{background-color:#eee}button.active{background-color:#d3d3d3}.editor-control-panel{margin-bottom:20px;font:unset;max-width:1100px;margin-left:auto;margin-right:auto}:host ::ng-deep .dropdown .mat-mdc-form-field-infix{min-height:unset;padding-top:10px;padding-bottom:10px}:host ::ng-deep .dropdown .mdc-notched-outline__notch{max-width:unset!important}:host ::ng-deep .indent-size-input .mat-mdc-form-field-flex{height:45px}:host ::ng-deep .indent-size-input .mat-mdc-form-field-infix{padding-top:10px;padding-bottom:10px}:host fieldset{height:55px;box-sizing:content-box!important;border-radius:3px;padding:5px 5px 10px}.fx-column-start-stretch{box-sizing:border-box;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch}.fx-row-start-stretch{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:stretch}.fx-row-start-start{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-start;align-items:flex-start}.fx-row-space-between-stretch{box-sizing:border-box;display:flex;flex-direction:row;justify-content:space-between;align-items:stretch}.fx-row-space-around-center{box-sizing:border-box;display:flex;flex-direction:row;justify-content:space-around;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i4.MatDialog }], propDecorators: { content: [{
                type: Input
            }], defaultFontSize: [{
                type: Input
            }], editorHeightPx: [{
                type: Input
            }], clozeMode: [{
                type: Input
            }], contentChange: [{
                type: Output
            }] } });

class RichTextEditDialogComponent {
    constructor(data) {
        this.data = data;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RichTextEditDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.24", type: RichTextEditDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
      <h1 mat-dialog-title>{{data.title}}</h1>
      <aspect-rich-text-editor [(content)]="data.content" mat-dialog-content
                               [clozeMode]="false"
                               [editorHeightPx]="data.editorHeightPx"
                               [defaultFontSize]="data.defaultFontSize">
      </aspect-rich-text-editor>
      <div class="fx-row-space-between-center" [style.margin]="'0 26px 18px'">
        <div class="fx-gap-10">
          <button mat-raised-button [mat-dialog-close]="data.content">{{'dialog-save' | translate }}</button>
          <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate }}</button>
        </div>
        <button mat-raised-button [mat-dialog-close]="''">{{'dialog-empty' | translate }}</button>
      </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "component", type: RichTextEditorComponent, selector: "aspect-rich-text-editor", inputs: ["content", "defaultFontSize", "editorHeightPx", "clozeMode"], outputs: ["contentChange"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RichTextEditDialogComponent, decorators: [{
            type: Component,
            args: [{
                    template: `
      <h1 mat-dialog-title>{{data.title}}</h1>
      <aspect-rich-text-editor [(content)]="data.content" mat-dialog-content
                               [clozeMode]="false"
                               [editorHeightPx]="data.editorHeightPx"
                               [defaultFontSize]="data.defaultFontSize">
      </aspect-rich-text-editor>
      <div class="fx-row-space-between-center" [style.margin]="'0 26px 18px'">
        <div class="fx-gap-10">
          <button mat-raised-button [mat-dialog-close]="data.content">{{'dialog-save' | translate }}</button>
          <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate }}</button>
        </div>
        <button mat-raised-button [mat-dialog-close]="''">{{'dialog-empty' | translate }}</button>
      </div>
  `,
                    standalone: true,
                    imports: [MatDialogTitle, RichTextEditorComponent, MatDialogContent, MatButton, MatDialogClose, TranslateModule]
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class EditProcessingDialogComponent {
    constructor(data) {
        this.data = data;
        this.allProcessings = [
            'IGNORE_CASE',
            'IGNORE_ALL_SPACES',
            'IGNORE_DISPENSABLE_SPACES',
            'SORT_ARRAY',
            'REPLAY_REQUIRED',
            'ATTACHMENT',
            'CODER_TRAINING_REQUIRED'
        ];
        this.data.processing = [...this.data.processing];
    }
    alterProcessing(processingId, checked) {
        if (checked) {
            if (!this.data.processing.includes(processingId)) {
                this.data.processing.push(processingId);
            }
        }
        else {
            this.data.processing = this.data.processing.filter(p => p !== processingId);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: EditProcessingDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: EditProcessingDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>{{ 'processing.prompt' | translate }}</h1>

    <mat-dialog-content>
      <div class="fx-column-start-start">
        <div>{{ 'processing.label' | translate }}</div>
        @for (p of allProcessings; track p) {
        <mat-checkbox
          [checked]="data.processing ? data.processing.includes(p) : false"
          (change)="alterProcessing(p, $event.checked)"
        >
          {{ 'processing.' + p | translate }}
        </mat-checkbox>
        }
      </div>
      <mat-form-field [matTooltip]="'fragmenting.tooltip' | translate">
        <mat-label>{{ 'fragmenting.prompt' | translate }}</mat-label>
        <input matInput [(ngModel)]="data.fragmenting" />
      </mat-form-field>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="data">
        {{ 'dialog-save' | translate }}
      </button>
      <button mat-raised-button [mat-dialog-close]="false">
        {{ 'dialog-cancel' | translate }}
      </button>
    </mat-dialog-actions>
  `, isInline: true, dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: EditProcessingDialogComponent, decorators: [{
            type: Component,
            args: [{
                    template: `
    <h1 mat-dialog-title>{{ 'processing.prompt' | translate }}</h1>

    <mat-dialog-content>
      <div class="fx-column-start-start">
        <div>{{ 'processing.label' | translate }}</div>
        @for (p of allProcessings; track p) {
        <mat-checkbox
          [checked]="data.processing ? data.processing.includes(p) : false"
          (change)="alterProcessing(p, $event.checked)"
        >
          {{ 'processing.' + p | translate }}
        </mat-checkbox>
        }
      </div>
      <mat-form-field [matTooltip]="'fragmenting.tooltip' | translate">
        <mat-label>{{ 'fragmenting.prompt' | translate }}</mat-label>
        <input matInput [(ngModel)]="data.fragmenting" />
      </mat-form-field>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="data">
        {{ 'dialog-save' | translate }}
      </button>
      <button mat-raised-button [mat-dialog-close]="false">
        {{ 'dialog-cancel' | translate }}
      </button>
    </mat-dialog-actions>
  `,
                    standalone: true,
                    imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule,
                        FormsModule,
                        MatTooltipModule,
                        MatFormField,
                        MatInput,
                        MatCheckbox,
                        MatLabel
                    ]
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class CodesTitleComponent {
    constructor(schemerService, editProcessingDialog) {
        this.schemerService = schemerService;
        this.editProcessingDialog = editProcessingDialog;
        this.processingChanged = new EventEmitter();
        this.fragmentingChanged = new EventEmitter();
        this.codeListChanged = new EventEmitter();
        this.pasteRequested = new EventEmitter();
        this.fragmenting = '';
        this.canPaste = false;
    }
    sortCodes(event) {
        if (this.codeList && this.schemerService.userRole !== 'RO') {
            this.schemerService.sortCodes(this.codeList, event.ctrlKey);
            this.codeListChanged.emit(this.codeList);
        }
    }
    editProcessingAndFragments() {
        if (this.schemerService.userRole !== 'RO') {
            const dialogRef = this.editProcessingDialog.open(EditProcessingDialogComponent, {
                data: {
                    fragmenting: this.fragmenting,
                    processing: this.processing
                }
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (dialogResult !== false) {
                    const dialogResultTyped = dialogResult;
                    if (this.fragmenting !== dialogResultTyped.fragmenting) {
                        this.fragmenting = dialogResultTyped.fragmenting;
                        this.fragmentingChanged.emit(this.fragmenting);
                    }
                    if (this.processing) {
                        this.processing.splice(0);
                        dialogResultTyped.processing.forEach(p => {
                            if (this.processing)
                                this.processing.push(p);
                        });
                    }
                    this.processingChanged.emit(this.processing);
                }
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodesTitleComponent, deps: [{ token: SchemerService }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: CodesTitleComponent, isStandalone: true, selector: "codes-title", inputs: { codeList: "codeList", fragmenting: "fragmenting", processing: "processing", canPaste: "canPaste" }, outputs: { processingChanged: "processingChanged", fragmentingChanged: "fragmentingChanged", codeListChanged: "codeListChanged", pasteRequested: "pasteRequested" }, ngImport: i0, template: `
    <div class="codes-header fx-row-space-between-start">
      @if (schemerService.userRole !== 'RO') {
      <div class="fx-row-center-center" style="margin-top:10px">
        <h2>{{ 'code.header' | translate }}</h2>
        <div
          (click)="sortCodes($event)"
          [matTooltip]="'code.prompt.sort' | translate"
          [matTooltipShowDelay]="500"
          class="sort"
          matRipple
          [style.cursor]="'pointer'"
        >
          <mat-icon>swap_vert</mat-icon>
        </div>
        <button
          mat-icon-button
          (click)="pasteRequested.emit()"
          [disabled]="!canPaste"
          [matTooltip]="'varList.paste-code' | translate"
          [matTooltipShowDelay]="500"
        >
          <mat-icon>content_paste</mat-icon>
        </button>
      </div>
      } @else {
      <h2>{{ 'code.header' | translate }}</h2>
      }
      <div class="fx-column-start-center">
        <button
          mat-button
          [matTooltip]="'processing.prompt' | translate"
          [disabled]="schemerService.userRole === 'RO'"
          (click)="editProcessingAndFragments()"
        >
          <mat-icon>edit</mat-icon>
          {{ 'processing.prompt' | translate }}
        </button>
        <div class="fx-column-start-start">
          @for (p of processing; track p) {
          <div class="fx-row-center-center" style="font-size: small">
            <mat-icon style="font-size: small; align-content: center;"
              >check</mat-icon
            >
            <div>{{ 'processing.' + p | translate }}</div>
          </div>
          } @if (fragmenting) {
          <div style="font-size: small">
            {{ 'fragmenting.prompt' | translate }}: "{{ fragmenting }}"
          </div>
          }
        </div>
      </div>
    </div>
  `, isInline: true, styles: [".sort{margin-left:20px}.codes-header{flex-wrap:wrap;gap:10px}\n"], dependencies: [{ kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodesTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'codes-title', template: `
    <div class="codes-header fx-row-space-between-start">
      @if (schemerService.userRole !== 'RO') {
      <div class="fx-row-center-center" style="margin-top:10px">
        <h2>{{ 'code.header' | translate }}</h2>
        <div
          (click)="sortCodes($event)"
          [matTooltip]="'code.prompt.sort' | translate"
          [matTooltipShowDelay]="500"
          class="sort"
          matRipple
          [style.cursor]="'pointer'"
        >
          <mat-icon>swap_vert</mat-icon>
        </div>
        <button
          mat-icon-button
          (click)="pasteRequested.emit()"
          [disabled]="!canPaste"
          [matTooltip]="'varList.paste-code' | translate"
          [matTooltipShowDelay]="500"
        >
          <mat-icon>content_paste</mat-icon>
        </button>
      </div>
      } @else {
      <h2>{{ 'code.header' | translate }}</h2>
      }
      <div class="fx-column-start-center">
        <button
          mat-button
          [matTooltip]="'processing.prompt' | translate"
          [disabled]="schemerService.userRole === 'RO'"
          (click)="editProcessingAndFragments()"
        >
          <mat-icon>edit</mat-icon>
          {{ 'processing.prompt' | translate }}
        </button>
        <div class="fx-column-start-start">
          @for (p of processing; track p) {
          <div class="fx-row-center-center" style="font-size: small">
            <mat-icon style="font-size: small; align-content: center;"
              >check</mat-icon
            >
            <div>{{ 'processing.' + p | translate }}</div>
          </div>
          } @if (fragmenting) {
          <div style="font-size: small">
            {{ 'fragmenting.prompt' | translate }}: "{{ fragmenting }}"
          </div>
          }
        </div>
      </div>
    </div>
  `, standalone: true, imports: [
                        MatRipple,
                        MatTooltipModule,
                        MatIcon,
                        TranslateModule,
                        MatButton,
                        MatIconButton
                    ], styles: [".sort{margin-left:20px}.codes-header{flex-wrap:wrap;gap:10px}\n"] }]
        }], ctorParameters: () => [{ type: SchemerService }, { type: i4.MatDialog }], propDecorators: { processingChanged: [{
                type: Output
            }], fragmentingChanged: [{
                type: Output
            }], codeListChanged: [{
                type: Output
            }], pasteRequested: [{
                type: Output
            }], codeList: [{
                type: Input
            }], fragmenting: [{
                type: Input
            }], processing: [{
                type: Input
            }], canPaste: [{
                type: Input
            }] } });

var MessageType;
(function (MessageType) {
    MessageType[MessageType["error"] = 0] = "error";
    MessageType[MessageType["warning"] = 1] = "warning";
    MessageType[MessageType["info"] = 2] = "info";
})(MessageType || (MessageType = {}));
class MessageDialogComponent {
    constructor(messageData, translate) {
        this.messageData = messageData;
        this.translate = translate;
    }
    ngOnInit() {
        this.messageData.title = this.messageData.title?.trim() || this.getDefaultTitle(this.messageData.type);
        this.messageData.closeButtonLabel = this.messageData.closeButtonLabel?.trim() || this.translate.instant('close');
    }
    // eslint-disable-next-line class-methods-use-this
    getDefaultTitle(type) {
        switch (type) {
            case MessageType.error:
                return this.translate.instant('message-dialog.default-title.error');
            case MessageType.warning:
                return this.translate.instant('message-dialog.default-title.warning');
            default:
                return this.translate.instant('message-dialog.default-title.info');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: MessageDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: MessageDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>
      @if (messageData.type === 0) {
        <mat-icon>error</mat-icon>
      }
      @if (messageData.type === 1) {
        <mat-icon>warning</mat-icon>
      }
      @if (messageData.type === 2) {
        <mat-icon>info</mat-icon>
      }
      {{ messageData.title }}
    </h1>
    <mat-dialog-content>
      {{ messageData.content }}
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button [mat-dialog-close]="false">{{ messageData.closeButtonLabel }}</button>
    </mat-dialog-actions>
    `, isInline: true, styles: ["mat-dialog-content{padding-bottom:30px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: MessageDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>
      @if (messageData.type === 0) {
        <mat-icon>error</mat-icon>
      }
      @if (messageData.type === 1) {
        <mat-icon>warning</mat-icon>
      }
      @if (messageData.type === 2) {
        <mat-icon>info</mat-icon>
      }
      {{ messageData.title }}
    </h1>
    <mat-dialog-content>
      {{ messageData.content }}
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button [mat-dialog-close]="false">{{ messageData.closeButtonLabel }}</button>
    </mat-dialog-actions>
    `, standalone: true, imports: [MatDialogTitle, MatIcon, MatDialogContent, MatDialogActions, MatButton, MatDialogClose], styles: ["mat-dialog-content{padding-bottom:30px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1.TranslateService }] });

class SelectCodeRuleReferenceDialogComponent {
    constructor(refData, dialogRef) {
        this.refData = refData;
        this.dialogRef = dialogRef;
        if (typeof this.refData.value === 'number') {
            this.newValue = this.refData.value + 1;
            this.newSelection = ['specific'];
        }
        else {
            this.newValue = 0;
            this.newSelection = [this.refData.value || 'ANY'];
        }
    }
    okButtonClick() {
        const result = this.newSelection[0] === 'specific' ? this.newValue - 1 : this.newSelection[0];
        this.dialogRef.close(result);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SelectCodeRuleReferenceDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i4.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SelectCodeRuleReferenceDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>{{ (refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.title' | translate }}</h1>
    <mat-dialog-content>
      <div>{{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.prompt' | translate}}</div>
      <mat-selection-list [(ngModel)]="newSelection" multiple="false"
        [attr.aria-describedby]="!refData.isFragmentMode &&
          (newSelection[0] === 'ANY' || newSelection[0] === 'ANY_OPEN') ? 'array-reference-help' : null">
        <mat-list-option [value]="'ANY'" class="reference-option">
          <span class="reference-label">
            {{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.any' | translate}}
          </span>
        </mat-list-option>
        @if (!refData.isFragmentMode) {
          <mat-list-option [value]="'ANY_OPEN'" class="reference-option">
            <span class="reference-label">{{'rule-set.reference.any-open' | translate}}</span>
          </mat-list-option>
          <mat-list-option [value]="'SUM'">
            {{'rule-set.reference.sum' | translate}}
          </mat-list-option>
          <mat-list-option [value]="'LENGTH'">
            {{'rule-set.reference.length' | translate}}
          </mat-list-option>
        }
        <mat-list-option [value]="'specific'" class="reference-option">
          <span class="reference-label">
            {{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.specific' | translate}}:
          </span>
        </mat-list-option>
      </mat-selection-list>
      @if (!refData.isFragmentMode && (newSelection[0] === 'ANY' || newSelection[0] === 'ANY_OPEN')) {
        <p id="array-reference-help" aria-live="polite">
          {{(newSelection[0] === 'ANY' ? 'rule-set.reference.any-help' :
            'rule-set.reference.any-open-help') | translate}}
        </p>
      }
      <mat-form-field>
        <input matInput [disabled]="newSelection[0] !== 'specific'"
          [(ngModel)]="newValue"
          type="number">
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [disabled]="newSelection[0] === 'specific' && newValue <= 0"
      (click)="okButtonClick()">{{ 'dialog-save' | translate }}</button>
      <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
    </mat-dialog-actions>
    `, isInline: true, styles: [".reference-option{height:auto;min-height:48px;padding-top:8px;padding-bottom:8px}.reference-label{display:block;white-space:normal;line-height:1.4}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SelectCodeRuleReferenceDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>{{ (refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.title' | translate }}</h1>
    <mat-dialog-content>
      <div>{{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.prompt' | translate}}</div>
      <mat-selection-list [(ngModel)]="newSelection" multiple="false"
        [attr.aria-describedby]="!refData.isFragmentMode &&
          (newSelection[0] === 'ANY' || newSelection[0] === 'ANY_OPEN') ? 'array-reference-help' : null">
        <mat-list-option [value]="'ANY'" class="reference-option">
          <span class="reference-label">
            {{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.any' | translate}}
          </span>
        </mat-list-option>
        @if (!refData.isFragmentMode) {
          <mat-list-option [value]="'ANY_OPEN'" class="reference-option">
            <span class="reference-label">{{'rule-set.reference.any-open' | translate}}</span>
          </mat-list-option>
          <mat-list-option [value]="'SUM'">
            {{'rule-set.reference.sum' | translate}}
          </mat-list-option>
          <mat-list-option [value]="'LENGTH'">
            {{'rule-set.reference.length' | translate}}
          </mat-list-option>
        }
        <mat-list-option [value]="'specific'" class="reference-option">
          <span class="reference-label">
            {{(refData.isFragmentMode ? 'rule' : 'rule-set') + '.reference.specific' | translate}}:
          </span>
        </mat-list-option>
      </mat-selection-list>
      @if (!refData.isFragmentMode && (newSelection[0] === 'ANY' || newSelection[0] === 'ANY_OPEN')) {
        <p id="array-reference-help" aria-live="polite">
          {{(newSelection[0] === 'ANY' ? 'rule-set.reference.any-help' :
            'rule-set.reference.any-open-help') | translate}}
        </p>
      }
      <mat-form-field>
        <input matInput [disabled]="newSelection[0] !== 'specific'"
          [(ngModel)]="newValue"
          type="number">
      </mat-form-field>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [disabled]="newSelection[0] === 'specific' && newValue <= 0"
      (click)="okButtonClick()">{{ 'dialog-save' | translate }}</button>
      <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
    </mat-dialog-actions>
    `, standalone: true, imports: [
                        MatDialogTitle, MatDialogContent, MatSelectionList, ReactiveFormsModule, FormsModule,
                        MatListOption, MatFormField, MatInput, MatDialogActions, MatButton, MatDialogClose, TranslateModule
                    ], styles: [".reference-option{height:auto;min-height:48px;padding-top:8px;padding-bottom:8px}.reference-label{display:block;white-space:normal;line-height:1.4}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i4.MatDialogRef }] });

class RuleReferencePipe {
    // eslint-disable-next-line class-methods-use-this
    transform(value) {
        if (typeof value === 'number') {
            return value < 0 ? '-' : (value + 1).toString();
        }
        switch (value) {
            case 'SUM':
                return 'S';
            case 'LENGTH':
                return 'L';
            case 'ANY_OPEN':
                return 'O';
            default:
                return '-';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RuleReferencePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.24", ngImport: i0, type: RuleReferencePipe, isStandalone: true, name: "ruleReference" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: RuleReferencePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'ruleReference',
                    standalone: true
                }]
        }] });

const MATCH_WORD_SVG = 'M40-199v-200h80v120h720v-120h80v200H40Zm342-161v-34h-3q-13 20-35 31.5T294-351' +
    'q-49 0-77-25.5T189-446q0-42 32.5-68.5T305-541q23 0 42.5 3.5T381-526v-14q0-27' +
    '-18.5-43T312-599q-21 0-39.5 9T241-564l-43-32q19-27 48-41t67-14q62 0 95 29.5' +
    't33 85.5v176h-59Zm-66-134q-32 0-49 12.5T250-446q0 20 15 32.5t39 12.5q32 0 ' +
    '54.5 -22.5T381-478q-14-8-32-12t-33-4Zm185 134v-401h62v113l-3 40h3q3-5 24-25.5' +
    't66-20.5q64 0 101 46t37 106q0 60-36.5 105.5T653-351q-41 0-62.5-18T563-397h-3' +
    'v37h-59Zm143-238q-40 0-62 29.5T560-503q0 37 22 66t62 29q40 0 62.5-29t22.5-66' +
    'q0-37-22.5-66T644-598Z';
const REGULAR_EXPRESSION_SVG = 'M197-199q-56-57-86.5-130T80-482q0-80 30-153t87-130l57 57q-46 45-70 103.5' +
    'T160-482q0 64 24.5 122.5T254-256l-57 57Zm183-41q-25 0-42.5-17.5T320-300q0-25' +
    ' 17.5 -42.5T380-360q25 0 42.5 17.5T440-300q0 25-17.5 42.5T380-240Zm139-200v-71' +
    'l-61 36-40-70 61-35-61-35 40-70 61 36v-71h80v71l61-36 40 70-61 35 61 35-40 70' +
    '-61-36v71h-80Zm244 241-57-57q46-45 70-103.5T800-482q0-64-24.5-122.5T706-708' +
    'l57-57q56 57 86.5 130T880-482q0 80-30 153t-87 130Z';
const ARROW_RANGE_SVG = 'M280-280 80-480l200-200 56 56-103 104h494L624-624l56-56 200 200-200 200-56-56 103-104H233l103 104-56 56Z';
const asSvg = (pathData) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960"><path d="${pathData}"/></svg>`;
class CodeRuleListComponent {
    constructor(schemerService, editRuleReferenceDialog, iconRegistry, sanitizer) {
        this.schemerService = schemerService;
        this.editRuleReferenceDialog = editRuleReferenceDialog;
        this.iconRegistry = iconRegistry;
        this.sanitizer = sanitizer;
        this.codeRulesChanged = new EventEmitter();
        this.deleteRuleSetRequested = new EventEmitter();
        this.fragmentMode = false;
        this.arrayMode = false;
        this.canDeleteRuleSet = false;
        this.showCodeButtonsOf = '';
        this.textRules = ['MATCH', 'MATCH_REGEX'];
        this.numericRules = [
            'NUMERIC_MATCH',
            'NUMERIC_FULL_RANGE',
            'NUMERIC_MIN',
            'NUMERIC_MORE_THAN',
            'NUMERIC_LESS_THAN',
            'NUMERIC_MAX'
        ];
        this.booleanRules = ['IS_TRUE', 'IS_FALSE'];
        this.blankRules = ['IS_EMPTY', 'IS_NULL'];
        const icons = [
            { name: 'match-word', svg: asSvg(MATCH_WORD_SVG) },
            { name: 'regular-expression', svg: asSvg(REGULAR_EXPRESSION_SVG) },
            { name: 'arrow-range', svg: asSvg(ARROW_RANGE_SVG) }
        ];
        icons.forEach(icon => {
            iconRegistry.addSvgIconLiteral(icon.name, sanitizer.bypassSecurityTrustHtml(icon.svg));
        });
    }
    setCodeRulesChanged() {
        this.codeRulesChanged.emit();
    }
    addRule(ruleSet, newRuleMethod) {
        if (ruleSet) {
            const newRule = {
                method: newRuleMethod
            };
            const paramCount = this.schemerService.ruleMethodParameterCount[newRuleMethod];
            if (paramCount !== 0) {
                newRule.parameters = [''];
                if (paramCount > 1)
                    newRule.parameters.push('');
            }
            ruleSet.rules.push(newRule);
            this.setCodeRulesChanged();
        }
    }
    changeRule(ruleSet, ruleToChangeIndex, newRuleMethod) {
        if (ruleSet && ruleToChangeIndex >= 0) {
            const rule = ruleSet.rules[ruleToChangeIndex];
            const paramCount = this.schemerService.ruleMethodParameterCount[newRuleMethod];
            if (paramCount !== 0) {
                if ((this.textRules.includes(rule.method) &&
                    (newRuleMethod === 'NUMERIC_MATCH' || this.textRules.includes(newRuleMethod))) ||
                    (rule.method === 'NUMERIC_MATCH' && this.textRules.includes(newRuleMethod))) {
                    rule.parameters = ruleSet.rules[ruleToChangeIndex].parameters;
                }
                else {
                    rule.parameters = [''];
                }
                if (rule.parameters && paramCount > 1)
                    rule.parameters.push('');
            }
            else {
                rule.parameters = [];
            }
            rule.method = newRuleMethod;
            this.setCodeRulesChanged();
        }
    }
    deleteRule(ruleSet, ruleToDeleteIndex) {
        if (!ruleSet) {
            return;
        }
        if (!ruleSet.rules || ruleToDeleteIndex < 0 || ruleToDeleteIndex >= ruleSet.rules.length) {
            return;
        }
        ruleSet.rules.splice(ruleToDeleteIndex, 1);
        this.setCodeRulesChanged();
    }
    editFragmentReference(rule) {
        if (rule) {
            const dialogRef = this.editRuleReferenceDialog.open(SelectCodeRuleReferenceDialogComponent, {
                width: '400px',
                data: {
                    isFragmentMode: true,
                    value: typeof rule.fragment === 'undefined' ? 'ANY' : rule.fragment
                },
                autoFocus: false
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (dialogResult !== false) {
                    rule.fragment = dialogResult;
                    this.setCodeRulesChanged();
                }
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeRuleListComponent, deps: [{ token: SchemerService }, { token: i4.MatDialog }, { token: i3$2.MatIconRegistry }, { token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: CodeRuleListComponent, isStandalone: true, selector: "code-rule-list", inputs: { ruleSet: "ruleSet", fragmentMode: "fragmentMode", arrayMode: "arrayMode", canDeleteRuleSet: "canDeleteRuleSet" }, outputs: { codeRulesChanged: "codeRulesChanged", deleteRuleSetRequested: "deleteRuleSetRequested" }, ngImport: i0, template: "<mat-card>\n  <mat-card-content>\n    <div class=\"rules-layout fx-row-start-stretch fx-gap-10\">\n      @if (ruleSet) {\n        <div class=\"rules-content fx-column-start-stretch fx-flex-fill\">\n          @for (rule of ruleSet.rules; track ruleIndex; let ruleIndex = $index) {\n            <div class=\"rule-row fx-row-start-center fx-flex-fill fx-gap-10\"\n                 (mouseover)=\"showCodeButtonsOf=rule.method\" (mouseout)=\"showCodeButtonsOf=''\">\n              <div class=\"rule-content fx-column-start-stretch fx-flex-fill\">\n                <div class=\"rule\">\n                  <div class=\"rule-header fx-row-start-center fx-gap-5\"\n                    [matTooltip]=\"('rule.' + rule.method + '.description') | translate\"\n                       matTooltipShowDelay=\"500\">\n                    <button mat-icon-button\n                            [matMenuTriggerFor]=\"selectCodeType\"\n                            [disabled]=\"schemerService.userRole === 'RO'\"\n                            [matTooltip]=\"'rule.prompt.change' | translate\">\n                      @if(rule.method === 'MATCH') {\n                        <mat-icon svgIcon=\"match-word\"></mat-icon>\n                      }\n                      @if(rule.method === 'MATCH_REGEX') {\n                        <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MATCH') {\n                          <mat-icon  class=\"centered-icon\"> = </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_RANGE') {\n                        <mat-icon style=\"color:#006064\"> ? </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_FULL_RANGE') {\n                        <mat-icon svgIcon=\"arrow-range\"></mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MAX') {\n                        <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MORE_THAN') {\n                        <mat-icon style=\"color:#006064\"> > </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_LESS_THAN') {\n                        <mat-icon style=\"color:#006064\"> < </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MIN') {\n                        <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                      }\n                      @if(rule.method === 'IS_TRUE') {\n                        <mat-icon style=\"color:#006064\" >check</mat-icon>\n                      }\n                      @if(rule.method === 'IS_FALSE') {\n                        <mat-icon style=\"color:#006064\" >close</mat-icon>\n                      }\n                      @if(rule.method  === 'IS_EMPTY') {\n                        <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                      }\n                      @if(rule.method  === 'IS_NULL') {\n                        <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                      }\n                    </button>\n                    <mat-menu #selectCodeType=\"matMenu\">\n                      <span class=\"rule-group-menu\">{{ 'rule.group-string' | translate }}</span>\n                      @for (rule of textRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'MATCH') {\n                            <mat-icon svgIcon=\"match-word\"></mat-icon>\n                          }\n                          @if(rule === 'MATCH_REGEX') {\n                            <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                          }\n\n                          {{('rule.' + rule)  | translate}}\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      <span class=\"rule-group-menu\">{{ 'rule.group-numeric' | translate }}</span>\n                      @for (rule of numericRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          <div class=\"fx-row-start-center\">\n                          @if(rule === 'NUMERIC_MATCH') {\n                            <mat-icon style=\"color:#006064\"> = </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_FULL_RANGE') {\n                            <mat-icon svgIcon=\"arrow-range\"></mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MAX') {\n                            <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MORE_THAN') {\n                            <mat-icon style=\"color:#006064\"> > </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_LESS_THAN') {\n                            <mat-icon style=\"color:#006064\"> < </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MIN') {\n                            <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                          }\n                          <span style=\"margin-top: 4px\">{{('rule.' + rule) | translate}}</span>\n                          </div>\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      <span class=\"rule-group-menu\">{{ 'rule.group-logic' | translate }}</span>\n                      @for (rule of booleanRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'IS_TRUE') {\n                            <mat-icon style=\"color:#006064\" >check</mat-icon>\n                          }\n                          @if(rule === 'IS_FALSE') {\n                            <mat-icon style=\"color:#006064\" >close</mat-icon>\n                          }\n                          {{('rule.' + rule) | translate}}\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      @for (rule of blankRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'IS_EMPTY') {\n                            <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                          }\n                          @if(rule === 'IS_NULL') {\n                            <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                          }\n                          {{('rule.' + rule) | translate}}\n                        </button>\n                      }\n                    </mat-menu>\n                    <span class=\"rule-group\">\n                      @if(textRules.includes(rule.method)) {\n                        {{'rule.group-string' | translate}}\n                      } @else if (numericRules.includes(rule.method)) {\n                        {{'rule.group-numeric' | translate}}\n                      } @else if (booleanRules.includes(rule.method)) {\n                        {{'rule.group-logic' | translate}}\n                      }\n                    </span>\n                    <span>{{('rule.' + rule.method) | translate}}</span>\n\n                  </div>\n\n\n                </div>\n                @if (schemerService.ruleMethodParameterCount[rule.method] < 0) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <textarea matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                                [(ngModel)]=\"rule.parameters[0]\"\n                                (ngModelChange)=\"setCodeRulesChanged()\"\n                                cdkTextareaAutosize\n                                cdkAutosizeMinRows=\"2\"\n                                cdkAutosizeMaxRows=\"8\"></textarea>\n                    }\n                  </mat-form-field>\n                }\n                @if (schemerService.ruleMethodParameterCount[rule.method] > 0) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <input matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                             [(ngModel)]=\"rule.parameters[0]\"\n                             (ngModelChange)=\"setCodeRulesChanged()\">\n                    }\n                  </mat-form-field>\n                }\n                @if (schemerService.ruleMethodParameterCount[rule.method] > 1) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <input matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                             [(ngModel)]=\"rule.parameters[1]\"\n                             (ngModelChange)=\"setCodeRulesChanged()\">\n                    }\n                  </mat-form-field>\n                }\n              </div>\n              <div class=\"fx-column-start-center\">\n                <button mat-icon-button [matTooltip]=\"'rule.prompt.delete' | translate\"\n                        [disabled]=\"schemerService.userRole === 'RO'\"\n                        (click)=\"deleteRule(ruleSet, ruleIndex)\"\n                        [class]=\"showCodeButtonsOf === rule.method ? 'buttonDisplay' : 'buttonHide'\">\n                  <mat-icon>delete_outlined</mat-icon>\n                </button>\n                @if (fragmentMode) {\n                  @if (schemerService.userRole !== 'RO') {\n                    <div>\n                      <button mat-flat-button (click)=\"editFragmentReference(rule)\"\n                              [matTooltip]=\"'rule.reference.title' | translate\">\n                        F {{ rule.fragment | ruleReference }}\n                      </button>\n                    </div>\n                  } @else {\n                    <div>F {{ rule.fragment | ruleReference }}</div>\n                  }\n                }\n              </div>\n            </div>\n          }\n          <div class=\"rule-operator-toolbar fx-row-space-between-center\">\n            <button style=\"color:#006064\"  mat-icon-button\n                    [matMenuTriggerFor]=\"addRuleMenu\"\n                    [disabled]=\"schemerService.userRole === 'RO'\"\n                    [matTooltip]=\"'rule.prompt.add' | translate\">\n              <mat-icon>add</mat-icon>\n            </button>\n            <mat-menu #addRuleMenu=\"matMenu\">\n              <span class=\"rule-group-menu\">{{ 'rule.group-string' | translate }}</span>\n              @for (newSource of textRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'MATCH') {\n                    <mat-icon svgIcon=\"match-word\"></mat-icon>\n                  }\n                  @if(newSource === 'MATCH_REGEX') {\n                    <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                  }\n\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n              <mat-divider></mat-divider>\n              <span class=\"rule-group-menu\">{{ 'rule.group-numeric' | translate }}</span>\n              @for (newSource of numericRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  <div class=\"fx-row-start-center\">\n                    @if(newSource === 'NUMERIC_MATCH') {\n                      <mat-icon style=\"color:#006064\" > = </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_FULL_RANGE') {\n                      <mat-icon svgIcon=\"arrow-range\" ></mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MAX') {\n                      <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MORE_THAN') {\n                      <mat-icon style=\"color:#006064\"> > </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_LESS_THAN') {\n                      <mat-icon style=\"color:#006064\"> < </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MIN') {\n                      <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                    }\n                    <span style=\"margin-top: 4px\">{{('rule.' + newSource) | translate}}</span>\n                  </div>\n                </button>\n              }\n              <mat-divider></mat-divider>\n              <span class=\"rule-group-menu\">{{ 'rule.group-logic' | translate }}</span>\n              @for (newSource of booleanRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'IS_TRUE') {\n                    <mat-icon style=\"color:#006064\" >check</mat-icon>\n                  }\n                  @if(newSource === 'IS_FALSE') {\n                    <mat-icon style=\"color:#006064\">close</mat-icon>\n                  }\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n              <mat-divider></mat-divider>\n              @for (newSource of blankRules; track newSource) {\n                <button mat-menu-item\n                        (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'IS_EMPTY') {\n                    <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                  }\n                  @if(newSource === 'IS_NULL') {\n                    <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                  }\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n            </mat-menu>\n            @if (ruleSet && ruleSet.rules.length === 0) {\n              <div class=\"no-rules\">{{'rule.no-rules' | translate}}</div>\n            }\n            @if (ruleSet && ruleSet.rules.length > 1 && schemerService.userRole !== 'RO') {\n              <mat-button-toggle-group appearance=\"legacy\"\n                                       (ngModelChange)=\"setCodeRulesChanged()\"\n                                       [(ngModel)]=\"ruleSet.ruleOperatorAnd\"\n                                       [matTooltip]=\"'rule.prompt.operator' | translate\">\n                <mat-button-toggle [value]=\"false\">{{\"rule.operator.false\" | translate }}</mat-button-toggle>\n                <mat-button-toggle [value]=\"true\">{{\"rule.operator.true\" | translate }}</mat-button-toggle>\n              </mat-button-toggle-group>\n            }\n          </div>\n        </div>\n        @if (arrayMode || canDeleteRuleSet) {\n          <div class=\"fx-column-start-center\" [style.border-left]=\"'4px solid lightgrey'\">\n            @if (schemerService.userRole !== 'RO' && canDeleteRuleSet ) {\n              <button style=\"color:red\" mat-icon-button [matTooltip]=\"'rule-set.prompt.delete' | translate\"\n                      (click)=\"deleteRuleSetRequested.emit()\">\n                <mat-icon>\n                  <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"#EA3323\"><path d=\"m376-300 104-104 104 104 56-56-104-104 104-104-56-56-104 104-104-104-56 56 104 104-104 104 56 56Zm-96 180q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520Zm-400 0v520-520Z\"/></svg>\n                </mat-icon>\n              </button>\n            }\n          </div>\n        }\n      } @else {\n        <div class=\"no-ruleset\">{{'rule.no-ruleset' | translate}}</div>\n      }\n    </div>\n  </mat-card-content>\n</mat-card>\n", styles: [".rule-group-menu{font-size:small;margin-left:10px;color:#006064}.rule-group{margin-left:10px;color:#006064;font-weight:700}.no-rules{font-style:italic}.no-ruleset{font-style:italic;color:#ff8c00}.rules-content,.rule-content{min-width:0}.rule-content mat-form-field{min-width:0;width:100%}.rule-header{flex-wrap:wrap;overflow-wrap:anywhere}@container code-rules (max-width: 500px){.rules-layout,.rule-row{flex-wrap:wrap}.rules-content,.rule-content{flex:1 1 200px}}.rule-operator-toolbar{flex-wrap:wrap;gap:5px}mat-button-toggle-group{flex-shrink:0}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "directive", type: MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: MatCardContent, selector: "mat-card-content" }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: RuleReferencePipe, name: "ruleReference" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeRuleListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'code-rule-list', standalone: true, imports: [MatTooltipModule, MatIcon, TranslateModule, MatIconButton, CdkTextareaAutosize,
                        FormsModule, MatButton, MatFormField, MatInput, RuleReferencePipe, MatButtonToggle, MatButtonToggleGroup,
                        MatMenu, MatMenuItem, MatMenuTrigger, MatCard, MatCardContent, MatDivider], template: "<mat-card>\n  <mat-card-content>\n    <div class=\"rules-layout fx-row-start-stretch fx-gap-10\">\n      @if (ruleSet) {\n        <div class=\"rules-content fx-column-start-stretch fx-flex-fill\">\n          @for (rule of ruleSet.rules; track ruleIndex; let ruleIndex = $index) {\n            <div class=\"rule-row fx-row-start-center fx-flex-fill fx-gap-10\"\n                 (mouseover)=\"showCodeButtonsOf=rule.method\" (mouseout)=\"showCodeButtonsOf=''\">\n              <div class=\"rule-content fx-column-start-stretch fx-flex-fill\">\n                <div class=\"rule\">\n                  <div class=\"rule-header fx-row-start-center fx-gap-5\"\n                    [matTooltip]=\"('rule.' + rule.method + '.description') | translate\"\n                       matTooltipShowDelay=\"500\">\n                    <button mat-icon-button\n                            [matMenuTriggerFor]=\"selectCodeType\"\n                            [disabled]=\"schemerService.userRole === 'RO'\"\n                            [matTooltip]=\"'rule.prompt.change' | translate\">\n                      @if(rule.method === 'MATCH') {\n                        <mat-icon svgIcon=\"match-word\"></mat-icon>\n                      }\n                      @if(rule.method === 'MATCH_REGEX') {\n                        <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MATCH') {\n                          <mat-icon  class=\"centered-icon\"> = </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_RANGE') {\n                        <mat-icon style=\"color:#006064\"> ? </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_FULL_RANGE') {\n                        <mat-icon svgIcon=\"arrow-range\"></mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MAX') {\n                        <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MORE_THAN') {\n                        <mat-icon style=\"color:#006064\"> > </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_LESS_THAN') {\n                        <mat-icon style=\"color:#006064\"> < </mat-icon>\n                      }\n                      @if(rule.method === 'NUMERIC_MIN') {\n                        <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                      }\n                      @if(rule.method === 'IS_TRUE') {\n                        <mat-icon style=\"color:#006064\" >check</mat-icon>\n                      }\n                      @if(rule.method === 'IS_FALSE') {\n                        <mat-icon style=\"color:#006064\" >close</mat-icon>\n                      }\n                      @if(rule.method  === 'IS_EMPTY') {\n                        <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                      }\n                      @if(rule.method  === 'IS_NULL') {\n                        <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                      }\n                    </button>\n                    <mat-menu #selectCodeType=\"matMenu\">\n                      <span class=\"rule-group-menu\">{{ 'rule.group-string' | translate }}</span>\n                      @for (rule of textRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'MATCH') {\n                            <mat-icon svgIcon=\"match-word\"></mat-icon>\n                          }\n                          @if(rule === 'MATCH_REGEX') {\n                            <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                          }\n\n                          {{('rule.' + rule)  | translate}}\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      <span class=\"rule-group-menu\">{{ 'rule.group-numeric' | translate }}</span>\n                      @for (rule of numericRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          <div class=\"fx-row-start-center\">\n                          @if(rule === 'NUMERIC_MATCH') {\n                            <mat-icon style=\"color:#006064\"> = </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_FULL_RANGE') {\n                            <mat-icon svgIcon=\"arrow-range\"></mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MAX') {\n                            <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MORE_THAN') {\n                            <mat-icon style=\"color:#006064\"> > </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_LESS_THAN') {\n                            <mat-icon style=\"color:#006064\"> < </mat-icon>\n                          }\n                          @if(rule === 'NUMERIC_MIN') {\n                            <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                          }\n                          <span style=\"margin-top: 4px\">{{('rule.' + rule) | translate}}</span>\n                          </div>\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      <span class=\"rule-group-menu\">{{ 'rule.group-logic' | translate }}</span>\n                      @for (rule of booleanRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'IS_TRUE') {\n                            <mat-icon style=\"color:#006064\" >check</mat-icon>\n                          }\n                          @if(rule === 'IS_FALSE') {\n                            <mat-icon style=\"color:#006064\" >close</mat-icon>\n                          }\n                          {{('rule.' + rule) | translate}}\n                        </button>\n                      }\n                      <mat-divider></mat-divider>\n                      @for (rule of blankRules; track rule) {\n                        <button mat-menu-item (click)=\"changeRule(ruleSet, ruleIndex, rule)\">\n                          @if(rule === 'IS_EMPTY') {\n                            <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                          }\n                          @if(rule === 'IS_NULL') {\n                            <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                          }\n                          {{('rule.' + rule) | translate}}\n                        </button>\n                      }\n                    </mat-menu>\n                    <span class=\"rule-group\">\n                      @if(textRules.includes(rule.method)) {\n                        {{'rule.group-string' | translate}}\n                      } @else if (numericRules.includes(rule.method)) {\n                        {{'rule.group-numeric' | translate}}\n                      } @else if (booleanRules.includes(rule.method)) {\n                        {{'rule.group-logic' | translate}}\n                      }\n                    </span>\n                    <span>{{('rule.' + rule.method) | translate}}</span>\n\n                  </div>\n\n\n                </div>\n                @if (schemerService.ruleMethodParameterCount[rule.method] < 0) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <textarea matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                                [(ngModel)]=\"rule.parameters[0]\"\n                                (ngModelChange)=\"setCodeRulesChanged()\"\n                                cdkTextareaAutosize\n                                cdkAutosizeMinRows=\"2\"\n                                cdkAutosizeMaxRows=\"8\"></textarea>\n                    }\n                  </mat-form-field>\n                }\n                @if (schemerService.ruleMethodParameterCount[rule.method] > 0) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <input matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                             [(ngModel)]=\"rule.parameters[0]\"\n                             (ngModelChange)=\"setCodeRulesChanged()\">\n                    }\n                  </mat-form-field>\n                }\n                @if (schemerService.ruleMethodParameterCount[rule.method] > 1) {\n                  <mat-form-field>\n                    @if (rule.parameters) {\n                      <input matInput [disabled]=\"schemerService.userRole === 'RO'\"\n                             [(ngModel)]=\"rule.parameters[1]\"\n                             (ngModelChange)=\"setCodeRulesChanged()\">\n                    }\n                  </mat-form-field>\n                }\n              </div>\n              <div class=\"fx-column-start-center\">\n                <button mat-icon-button [matTooltip]=\"'rule.prompt.delete' | translate\"\n                        [disabled]=\"schemerService.userRole === 'RO'\"\n                        (click)=\"deleteRule(ruleSet, ruleIndex)\"\n                        [class]=\"showCodeButtonsOf === rule.method ? 'buttonDisplay' : 'buttonHide'\">\n                  <mat-icon>delete_outlined</mat-icon>\n                </button>\n                @if (fragmentMode) {\n                  @if (schemerService.userRole !== 'RO') {\n                    <div>\n                      <button mat-flat-button (click)=\"editFragmentReference(rule)\"\n                              [matTooltip]=\"'rule.reference.title' | translate\">\n                        F {{ rule.fragment | ruleReference }}\n                      </button>\n                    </div>\n                  } @else {\n                    <div>F {{ rule.fragment | ruleReference }}</div>\n                  }\n                }\n              </div>\n            </div>\n          }\n          <div class=\"rule-operator-toolbar fx-row-space-between-center\">\n            <button style=\"color:#006064\"  mat-icon-button\n                    [matMenuTriggerFor]=\"addRuleMenu\"\n                    [disabled]=\"schemerService.userRole === 'RO'\"\n                    [matTooltip]=\"'rule.prompt.add' | translate\">\n              <mat-icon>add</mat-icon>\n            </button>\n            <mat-menu #addRuleMenu=\"matMenu\">\n              <span class=\"rule-group-menu\">{{ 'rule.group-string' | translate }}</span>\n              @for (newSource of textRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'MATCH') {\n                    <mat-icon svgIcon=\"match-word\"></mat-icon>\n                  }\n                  @if(newSource === 'MATCH_REGEX') {\n                    <mat-icon svgIcon=\"regular-expression\"></mat-icon>\n                  }\n\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n              <mat-divider></mat-divider>\n              <span class=\"rule-group-menu\">{{ 'rule.group-numeric' | translate }}</span>\n              @for (newSource of numericRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  <div class=\"fx-row-start-center\">\n                    @if(newSource === 'NUMERIC_MATCH') {\n                      <mat-icon style=\"color:#006064\" > = </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_FULL_RANGE') {\n                      <mat-icon svgIcon=\"arrow-range\" ></mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MAX') {\n                      <mat-icon style=\"color:#006064\"> \u2264 </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MORE_THAN') {\n                      <mat-icon style=\"color:#006064\"> > </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_LESS_THAN') {\n                      <mat-icon style=\"color:#006064\"> < </mat-icon>\n                    }\n                    @if(newSource === 'NUMERIC_MIN') {\n                      <mat-icon style=\"color:#006064\"> \u2265 </mat-icon>\n                    }\n                    <span style=\"margin-top: 4px\">{{('rule.' + newSource) | translate}}</span>\n                  </div>\n                </button>\n              }\n              <mat-divider></mat-divider>\n              <span class=\"rule-group-menu\">{{ 'rule.group-logic' | translate }}</span>\n              @for (newSource of booleanRules; track newSource) {\n                <button mat-menu-item (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'IS_TRUE') {\n                    <mat-icon style=\"color:#006064\" >check</mat-icon>\n                  }\n                  @if(newSource === 'IS_FALSE') {\n                    <mat-icon style=\"color:#006064\">close</mat-icon>\n                  }\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n              <mat-divider></mat-divider>\n              @for (newSource of blankRules; track newSource) {\n                <button mat-menu-item\n                        (click)=\"addRule(ruleSet, newSource)\">\n                  @if(newSource === 'IS_EMPTY') {\n                    <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                  }\n                  @if(newSource === 'IS_NULL') {\n                    <mat-icon style=\"color:#006064\">check_box_outline_blank</mat-icon>\n                  }\n                  {{('rule.' + newSource) | translate}}\n                </button>\n              }\n            </mat-menu>\n            @if (ruleSet && ruleSet.rules.length === 0) {\n              <div class=\"no-rules\">{{'rule.no-rules' | translate}}</div>\n            }\n            @if (ruleSet && ruleSet.rules.length > 1 && schemerService.userRole !== 'RO') {\n              <mat-button-toggle-group appearance=\"legacy\"\n                                       (ngModelChange)=\"setCodeRulesChanged()\"\n                                       [(ngModel)]=\"ruleSet.ruleOperatorAnd\"\n                                       [matTooltip]=\"'rule.prompt.operator' | translate\">\n                <mat-button-toggle [value]=\"false\">{{\"rule.operator.false\" | translate }}</mat-button-toggle>\n                <mat-button-toggle [value]=\"true\">{{\"rule.operator.true\" | translate }}</mat-button-toggle>\n              </mat-button-toggle-group>\n            }\n          </div>\n        </div>\n        @if (arrayMode || canDeleteRuleSet) {\n          <div class=\"fx-column-start-center\" [style.border-left]=\"'4px solid lightgrey'\">\n            @if (schemerService.userRole !== 'RO' && canDeleteRuleSet ) {\n              <button style=\"color:red\" mat-icon-button [matTooltip]=\"'rule-set.prompt.delete' | translate\"\n                      (click)=\"deleteRuleSetRequested.emit()\">\n                <mat-icon>\n                  <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"#EA3323\"><path d=\"m376-300 104-104 104 104 56-56-104-104 104-104-56-56-104 104-104-104-56 56 104 104-104 104 56 56Zm-96 180q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520Zm-400 0v520-520Z\"/></svg>\n                </mat-icon>\n              </button>\n            }\n          </div>\n        }\n      } @else {\n        <div class=\"no-ruleset\">{{'rule.no-ruleset' | translate}}</div>\n      }\n    </div>\n  </mat-card-content>\n</mat-card>\n", styles: [".rule-group-menu{font-size:small;margin-left:10px;color:#006064}.rule-group{margin-left:10px;color:#006064;font-weight:700}.no-rules{font-style:italic}.no-ruleset{font-style:italic;color:#ff8c00}.rules-content,.rule-content{min-width:0}.rule-content mat-form-field{min-width:0;width:100%}.rule-header{flex-wrap:wrap;overflow-wrap:anywhere}@container code-rules (max-width: 500px){.rules-layout,.rule-row{flex-wrap:wrap}.rules-content,.rule-content{flex:1 1 200px}}.rule-operator-toolbar{flex-wrap:wrap;gap:5px}mat-button-toggle-group{flex-shrink:0}\n"] }]
        }], ctorParameters: () => [{ type: SchemerService }, { type: i4.MatDialog }, { type: i3$2.MatIconRegistry }, { type: i1$1.DomSanitizer }], propDecorators: { codeRulesChanged: [{
                type: Output
            }], deleteRuleSetRequested: [{
                type: Output
            }], ruleSet: [{
                type: Input
            }], fragmentMode: [{
                type: Input
            }], arrayMode: [{
                type: Input
            }], canDeleteRuleSet: [{
                type: Input
            }] } });

class CodeRulesComponent {
    constructor(schemerService, editRuleReferenceDialog) {
        this.schemerService = schemerService;
        this.editRuleReferenceDialog = editRuleReferenceDialog;
        this.codeRulesChanged = new EventEmitter();
    }
    setCodeRulesChanged() {
        this.codeRulesChanged.emit(this.code);
    }
    addRuleSet() {
        if (!this.code) {
            return;
        }
        const newRuleSet = {
            ruleOperatorAnd: false,
            rules: [
                {
                    method: 'MATCH',
                    parameters: ['']
                }
            ]
        };
        this.code.ruleSets = [...(this.code.ruleSets || []), newRuleSet];
        if (this.ruleSetElement) {
            this.ruleSetElement.selectedIndex = this.code.ruleSets.length - 1;
        }
        this.setCodeRulesChanged();
    }
    editArrayReference(ruleSet) {
        if (ruleSet) {
            const dialogRef = this.editRuleReferenceDialog.open(SelectCodeRuleReferenceDialogComponent, {
                width: '400px',
                data: {
                    isFragmentMode: false,
                    value: ruleSet.valueArrayPos
                },
                autoFocus: false
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (dialogResult !== false) {
                    ruleSet.valueArrayPos = dialogResult;
                    this.setCodeRulesChanged();
                }
            });
        }
    }
    deleteRuleSet(ruleSetToDeleteIndex) {
        if (!this.code || !this.code.ruleSets) {
            return;
        }
        this.code.ruleSets.splice(ruleSetToDeleteIndex, 1);
        this.setCodeRulesChanged();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeRulesComponent, deps: [{ token: SchemerService }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: CodeRulesComponent, isStandalone: true, selector: "code-rules", inputs: { code: "code", varInfo: "varInfo", fragmentMode: "fragmentMode" }, outputs: { codeRulesChanged: "codeRulesChanged" }, viewQueries: [{ propertyName: "ruleSetElement", first: true, predicate: MatTabGroup, descendants: true }], ngImport: i0, template: "<mat-card [style.height.%]=\"100\">\n  <mat-card-content>\n    @if (code ) { @if(code.ruleSets && code.ruleSets.length > 1 || varInfo &&\n    varInfo.multiple) {\n    <div class=\"rule-sets-toolbar fx-row-space-between-start\">\n      <h4>Regels\u00E4tze</h4>\n      <div class=\"fx-row-end-center\">\n        @if (code.ruleSets && code.ruleSets.length > 1 &&\n        schemerService.userRole !== 'RO') {\n        <mat-button-toggle-group\n          appearance=\"legacy\"\n          (ngModelChange)=\"setCodeRulesChanged()\"\n          [(ngModel)]=\"code.ruleSetOperatorAnd\"\n          [matTooltip]=\"'rule-set.prompt.operator' | translate\"\n        >\n          <mat-button-toggle [value]=\"false\">{{\n            \"rule.operator.false\" | translate\n          }}</mat-button-toggle>\n          <mat-button-toggle [value]=\"true\">{{\n            \"rule.operator.true\" | translate\n          }}</mat-button-toggle>\n        </mat-button-toggle-group>\n        }\n      </div>\n    </div>\n    } @for (ruleSet of code.ruleSets; track ruleSet; let ruleSetIndex = $index)\n    {\n    <div class=\"rule-set fx-row-start-start\">\n      <div class=\"rule-set-index fx-column-center-center\">\n        @if(code.ruleSets && code.ruleSets.length > 1 || varInfo &&\n        varInfo.multiple) {\n        <h4>{{ ruleSetIndex + 1 }}</h4>\n        } @if ((varInfo && varInfo.multiple || false) && ruleSet.rules.length >\n        0 && schemerService.userRole !== 'RO') {\n        <button\n          mat-flat-button\n          (click)=\"editArrayReference(ruleSet)\"\n          [matTooltip]=\"'rule-set.reference.title' | translate\"\n        >\n          A {{ ruleSet.valueArrayPos | ruleReference }}\n        </button>\n        }\n      </div>\n      <code-rule-list\n        [fragmentMode]=\"fragmentMode || false\"\n        [ruleSet]=\"ruleSet\"\n        class=\"fx-flex-fill code-rule-list\"\n        [arrayMode]=\"(varInfo && varInfo.multiple) || false\"\n        (deleteRuleSetRequested)=\"deleteRuleSet(ruleSetIndex)\"\n        [canDeleteRuleSet]=\"\n          !!(\n            (code.ruleSets && code.ruleSets.length > 1) ||\n            (varInfo && varInfo.multiple)\n          )\n        \"\n        (codeRulesChanged)=\"setCodeRulesChanged()\"\n      >\n      </code-rule-list>\n    </div>\n\n    } } @if (varInfo?.multiple && schemerService.userRole !== 'RO') {\n    <button\n      mat-icon-button\n      [matTooltip]=\"'rule-set.prompt.add' | translate\"\n      (click)=\"addRuleSet()\"\n    >\n      <mat-icon>add</mat-icon>\n    </button>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [":host ::ng-deep .mat-mdc-form-field-subscript-wrapper{display:none}.mat-flat-button{min-width:0;line-height:0;padding:0}.rulesContainer{overflow-y:scroll}.rule-set-header{border-top:lightgrey solid 1px;border-bottom:lightgrey solid 1px}.mat-button-toggle-checked{border-bottom:#3f51b5 2px solid;color:#3f51b5}.rule{margin:10px}code-rule-list{margin:10px}:host ::ng-deep .header-less-tabs .mat-mdc-tab-labels{height:0}.code-rule-list{min-width:0}@container code-rules (max-width: 500px){.rule-set{flex-direction:column}.rule-set-index{flex-direction:row;gap:10px}.code-rule-list{align-self:stretch;margin:10px 0}}.rule-sets-toolbar{flex-wrap:wrap;gap:10px}mat-button-toggle-group{flex-shrink:0}:host{display:block;container:code-rules/inline-size}\n"], dependencies: [{ kind: "component", type: MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "directive", type: MatCardContent, selector: "mat-card-content" }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: CodeRuleListComponent, selector: "code-rule-list", inputs: ["ruleSet", "fragmentMode", "arrayMode", "canDeleteRuleSet"], outputs: ["codeRulesChanged", "deleteRuleSetRequested"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: RuleReferencePipe, name: "ruleReference" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeRulesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'code-rules', standalone: true, imports: [
                        MatCard,
                        MatIconButton,
                        MatTooltipModule,
                        MatIcon,
                        MatButtonToggleGroup,
                        ReactiveFormsModule,
                        FormsModule,
                        MatButtonToggle,
                        MatCardContent,
                        MatButton,
                        TranslateModule,
                        RuleReferencePipe,
                        CodeRuleListComponent
                    ], template: "<mat-card [style.height.%]=\"100\">\n  <mat-card-content>\n    @if (code ) { @if(code.ruleSets && code.ruleSets.length > 1 || varInfo &&\n    varInfo.multiple) {\n    <div class=\"rule-sets-toolbar fx-row-space-between-start\">\n      <h4>Regels\u00E4tze</h4>\n      <div class=\"fx-row-end-center\">\n        @if (code.ruleSets && code.ruleSets.length > 1 &&\n        schemerService.userRole !== 'RO') {\n        <mat-button-toggle-group\n          appearance=\"legacy\"\n          (ngModelChange)=\"setCodeRulesChanged()\"\n          [(ngModel)]=\"code.ruleSetOperatorAnd\"\n          [matTooltip]=\"'rule-set.prompt.operator' | translate\"\n        >\n          <mat-button-toggle [value]=\"false\">{{\n            \"rule.operator.false\" | translate\n          }}</mat-button-toggle>\n          <mat-button-toggle [value]=\"true\">{{\n            \"rule.operator.true\" | translate\n          }}</mat-button-toggle>\n        </mat-button-toggle-group>\n        }\n      </div>\n    </div>\n    } @for (ruleSet of code.ruleSets; track ruleSet; let ruleSetIndex = $index)\n    {\n    <div class=\"rule-set fx-row-start-start\">\n      <div class=\"rule-set-index fx-column-center-center\">\n        @if(code.ruleSets && code.ruleSets.length > 1 || varInfo &&\n        varInfo.multiple) {\n        <h4>{{ ruleSetIndex + 1 }}</h4>\n        } @if ((varInfo && varInfo.multiple || false) && ruleSet.rules.length >\n        0 && schemerService.userRole !== 'RO') {\n        <button\n          mat-flat-button\n          (click)=\"editArrayReference(ruleSet)\"\n          [matTooltip]=\"'rule-set.reference.title' | translate\"\n        >\n          A {{ ruleSet.valueArrayPos | ruleReference }}\n        </button>\n        }\n      </div>\n      <code-rule-list\n        [fragmentMode]=\"fragmentMode || false\"\n        [ruleSet]=\"ruleSet\"\n        class=\"fx-flex-fill code-rule-list\"\n        [arrayMode]=\"(varInfo && varInfo.multiple) || false\"\n        (deleteRuleSetRequested)=\"deleteRuleSet(ruleSetIndex)\"\n        [canDeleteRuleSet]=\"\n          !!(\n            (code.ruleSets && code.ruleSets.length > 1) ||\n            (varInfo && varInfo.multiple)\n          )\n        \"\n        (codeRulesChanged)=\"setCodeRulesChanged()\"\n      >\n      </code-rule-list>\n    </div>\n\n    } } @if (varInfo?.multiple && schemerService.userRole !== 'RO') {\n    <button\n      mat-icon-button\n      [matTooltip]=\"'rule-set.prompt.add' | translate\"\n      (click)=\"addRuleSet()\"\n    >\n      <mat-icon>add</mat-icon>\n    </button>\n    }\n  </mat-card-content>\n</mat-card>\n", styles: [":host ::ng-deep .mat-mdc-form-field-subscript-wrapper{display:none}.mat-flat-button{min-width:0;line-height:0;padding:0}.rulesContainer{overflow-y:scroll}.rule-set-header{border-top:lightgrey solid 1px;border-bottom:lightgrey solid 1px}.mat-button-toggle-checked{border-bottom:#3f51b5 2px solid;color:#3f51b5}.rule{margin:10px}code-rule-list{margin:10px}:host ::ng-deep .header-less-tabs .mat-mdc-tab-labels{height:0}.code-rule-list{min-width:0}@container code-rules (max-width: 500px){.rule-set{flex-direction:column}.rule-set-index{flex-direction:row;gap:10px}.code-rule-list{align-self:stretch;margin:10px 0}}.rule-sets-toolbar{flex-wrap:wrap;gap:10px}mat-button-toggle-group{flex-shrink:0}:host{display:block;container:code-rules/inline-size}\n"] }]
        }], ctorParameters: () => [{ type: SchemerService }, { type: i4.MatDialog }], propDecorators: { codeRulesChanged: [{
                type: Output
            }], code: [{
                type: Input
            }], varInfo: [{
                type: Input
            }], fragmentMode: [{
                type: Input
            }], ruleSetElement: [{
                type: ViewChild,
                args: [MatTabGroup]
            }] } });

class CodeInstructionComponent {
    constructor(sanitizer, translateService, editTextDialog) {
        this.sanitizer = sanitizer;
        this.translateService = translateService;
        this.editTextDialog = editTextDialog;
        this.codeDataChanged = new EventEmitter();
        this.userRole = 'RO';
        this.hasIntendedIncompleteCode = false;
        this.hasResidualAutoCode = false;
        this.suppressResidualAutoWarning = false;
    }
    editTextDialog_manualInstruction() {
        if (this.code) {
            const dialogRef = this.editTextDialog.open(RichTextEditDialogComponent, {
                width: '1100px',
                data: {
                    title: this.translateService.instant('manual-instruction.code.prompt-edit'),
                    content: this.code.manualInstruction || '',
                    defaultFontSize: 20,
                    editorHeightPx: 400
                },
                autoFocus: false
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (typeof dialogResult !== 'undefined') {
                    if (dialogResult !== false && this.code) {
                        this.code.manualInstruction = dialogResult;
                        this.codeDataChanged.emit(this.code);
                    }
                }
            });
        }
    }
    wipeInstructions() {
        if (this.code) {
            this.code.manualInstruction = '';
            this.codeDataChanged.emit(this.code);
        }
    }
    getSanitizedText(text) {
        return this.sanitizer.bypassSecurityTrustHtml(renderManualInstructionMath(text));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeInstructionComponent, deps: [{ token: i1$1.DomSanitizer }, { token: i1.TranslateService }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: CodeInstructionComponent, isStandalone: true, selector: "code-instruction", inputs: { code: "code", userRole: "userRole", hasIntendedIncompleteCode: "hasIntendedIncompleteCode", hasResidualAutoCode: "hasResidualAutoCode", suppressResidualAutoWarning: "suppressResidualAutoWarning" }, outputs: { codeDataChanged: "codeDataChanged" }, ngImport: i0, template: `
    @if (code) {
    <mat-card [style.padding-left.px]="12" [style.height.%]="100">
      <mat-card-subtitle class="hover-area">
        <div class="fx-row-space-between-center">
          <div class="fx-row-start-center">
            <div [style.color]="'grey'" [style.font-size]="'smaller'">
              {{ 'manual-instruction.code.title' | translate }}
            </div>
            <button
              mat-icon-button
              [matTooltip]="'manual-instruction.code.prompt-edit' | translate"
              [disabled]="userRole === 'RO'"
              (click)="editTextDialog_manualInstruction()"
            >
              <mat-icon> edit </mat-icon>
            </button>
            @if (
              (hasResidualAutoCode) &&
              !suppressResidualAutoWarning &&
              code.manualInstruction
            ) {
            <mat-icon
              [style.color]="'red'"
              [matTooltip]="
                'manual-instruction.code.error-residual-auto' | translate
              "
            >
              error
            </mat-icon>
            } @if ((hasIntendedIncompleteCode) && code.manualInstruction) {
            <mat-icon
              [style.color]="'red'"
              [matTooltip]="
                'manual-instruction.code.error-intended-incomplete' | translate
              "
            >
              error
            </mat-icon>
            }
          </div>
          @if (code.manualInstruction) {
          <button
            mat-icon-button
            (click)="wipeInstructions()"
            class="wipe-button"
            [disabled]="userRole === 'RO'"
            [matTooltip]="'manual-instruction.code.wipe' | translate"
            [matTooltipShowDelay]="500"
          >
            <mat-icon> close </mat-icon>
          </button>
          }
        </div>
      </mat-card-subtitle>
      <mat-card-content [style.overflow-x]="'auto'">
        <div
          [innerHTML]="
            code ? getSanitizedText(code.manualInstruction || '') : null
          "
        ></div>
      </mat-card-content>
    </mat-card>
    }
  `, isInline: true, styles: [".hover-area .wipe-button{visibility:hidden}.hover-area:hover .wipe-button{visibility:visible}\n"], dependencies: [{ kind: "component", type: MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatCardContent, selector: "mat-card-content" }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodeInstructionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'code-instruction', template: `
    @if (code) {
    <mat-card [style.padding-left.px]="12" [style.height.%]="100">
      <mat-card-subtitle class="hover-area">
        <div class="fx-row-space-between-center">
          <div class="fx-row-start-center">
            <div [style.color]="'grey'" [style.font-size]="'smaller'">
              {{ 'manual-instruction.code.title' | translate }}
            </div>
            <button
              mat-icon-button
              [matTooltip]="'manual-instruction.code.prompt-edit' | translate"
              [disabled]="userRole === 'RO'"
              (click)="editTextDialog_manualInstruction()"
            >
              <mat-icon> edit </mat-icon>
            </button>
            @if (
              (hasResidualAutoCode) &&
              !suppressResidualAutoWarning &&
              code.manualInstruction
            ) {
            <mat-icon
              [style.color]="'red'"
              [matTooltip]="
                'manual-instruction.code.error-residual-auto' | translate
              "
            >
              error
            </mat-icon>
            } @if ((hasIntendedIncompleteCode) && code.manualInstruction) {
            <mat-icon
              [style.color]="'red'"
              [matTooltip]="
                'manual-instruction.code.error-intended-incomplete' | translate
              "
            >
              error
            </mat-icon>
            }
          </div>
          @if (code.manualInstruction) {
          <button
            mat-icon-button
            (click)="wipeInstructions()"
            class="wipe-button"
            [disabled]="userRole === 'RO'"
            [matTooltip]="'manual-instruction.code.wipe' | translate"
            [matTooltipShowDelay]="500"
          >
            <mat-icon> close </mat-icon>
          </button>
          }
        </div>
      </mat-card-subtitle>
      <mat-card-content [style.overflow-x]="'auto'">
        <div
          [innerHTML]="
            code ? getSanitizedText(code.manualInstruction || '') : null
          "
        ></div>
      </mat-card-content>
    </mat-card>
    }
  `, standalone: true, imports: [
                        MatCard,
                        MatCardSubtitle,
                        MatIconButton,
                        MatTooltipModule,
                        MatIcon,
                        MatCardContent,
                        TranslateModule
                    ], styles: [".hover-area .wipe-button{visibility:hidden}.hover-area:hover .wipe-button{visibility:visible}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.DomSanitizer }, { type: i1.TranslateService }, { type: i4.MatDialog }], propDecorators: { codeDataChanged: [{
                type: Output
            }], code: [{
                type: Input
            }], userRole: [{
                type: Input
            }], hasIntendedIncompleteCode: [{
                type: Input
            }], hasResidualAutoCode: [{
                type: Input
            }], suppressResidualAutoWarning: [{
                type: Input
            }] } });

class SingleCodeComponent {
    constructor(schemerService) {
        this.schemerService = schemerService;
        this.codeDataChanged = new EventEmitter();
        this.hasResidualAutoCode = false;
        this.hasIntendedIncompleteAutoCode = false;
    }
    canCopySingleCode() {
        if (this.schemerService.userRole === 'RO') {
            return false;
        }
        return !!this.code;
    }
    copySingleCode() {
        if (!this.code) {
            return;
        }
        this.schemerService.copySingleCode(this.code);
    }
    codeIdIsUnique(codeToValidate, codeIndex) {
        if (!this.allCodes ||
            codeToValidate === 'INVALID' ||
            codeToValidate === 'INTENDED_INCOMPLETE') {
            return true;
        }
        const firstEqualCode = this.allCodes.find((c, index) => index !== codeIndex && c.id === codeToValidate);
        return !firstEqualCode;
    }
    deleteCode(codeIndex) {
        if (this.allCodes && typeof codeIndex !== 'undefined') {
            this.schemerService.deleteCode(this.allCodes, codeIndex);
            this.setCodeChanged();
        }
    }
    setCodeChanged() {
        this.codeDataChanged.emit(this.code);
    }
    setCodeType(codeType) {
        if (this.code) {
            this.code.type = codeType;
            ensureResidualAutoManualInstruction(this.code);
            this.setCodeChanged();
        }
    }
    showResidualAutoManualInstruction() {
        return this.sourceType === 'SOLVER';
    }
    showManualOnlyInstruction() {
        if (!this.code)
            return false;
        if (this.code.type === 'RESIDUAL_AUTO')
            return this.showResidualAutoManualInstruction();
        return this.code.type !== 'INTENDED_INCOMPLETE';
    }
    showSideInstruction() {
        if (!this.code)
            return false;
        if (this.code.type === 'RESIDUAL_AUTO')
            return this.showResidualAutoManualInstruction();
        if (this.code.type === 'INTENDED_INCOMPLETE')
            return !!this.code.manualInstruction;
        return true;
    }
    suppressResidualAutoWarning() {
        return this.showResidualAutoManualInstruction();
    }
    setCodeInvalid() {
        if (this.code) {
            this.code.id = 'INVALID';
            this.setCodeChanged();
        }
    }
    setCodeValid() {
        if (this.code && this.allCodes) {
            const hasNullCode = this.allCodes.length > 0 ?
                !!this.allCodes.find(c => c.id === 0) :
                false;
            if (hasNullCode) {
                let maxId = 0;
                if (this.allCodes.length > 0) {
                    maxId = Math.max(...this.allCodes
                        .filter(c => typeof c.id === 'number')
                        .map(c => Number(c.id) || 0));
                }
                this.code.id = maxId + 1;
            }
            else {
                this.code.id = 0;
            }
            this.setCodeChanged();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SingleCodeComponent, deps: [{ token: SchemerService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SingleCodeComponent, isStandalone: true, selector: "single-code", inputs: { code: "code", allCodes: "allCodes", varInfo: "varInfo", fragmentMode: "fragmentMode", codeIndex: "codeIndex", codeModel: "codeModel", sourceType: "sourceType", hasResidualAutoCode: "hasResidualAutoCode", hasIntendedIncompleteAutoCode: "hasIntendedIncompleteAutoCode" }, outputs: { codeDataChanged: "codeDataChanged" }, ngImport: i0, template: "<div class=\"code\" [class.with-instruction]=\"(codeModel ?? 'NONE') === 'NONE' || codeModel === 'MANUAL_AND_RULES'\">\n  @if (code && allCodes) {\n  <button\n    mat-icon-button\n    class=\"code-type\"\n    [matMenuTriggerFor]=\"selectCodeType\"\n    [matTooltip]=\"'code.prompt.add-' + code.type | translate\"\n    [matTooltipShowDelay]=\"500\"\n    [disabled]=\"schemerService.userRole === 'RO'\"\n  >\n    @if (code.type === 'FULL_CREDIT') {\n    <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n    } @else if (code.type === 'PARTIAL_CREDIT') {\n    <mat-icon style=\"color: green\">check</mat-icon>\n    } @else if (code.type === 'TO_CHECK') {\n    <mat-icon style=\"color: blue\"\n      ><svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        height=\"24px\"\n        viewBox=\"0 -960 960 960\"\n        width=\"24px\"\n      >\n        <path\n          d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n        /></svg\n    ></mat-icon>\n    } @else if (code.type === 'NO_CREDIT') {\n    <mat-icon style=\"color: gold\">remove_done</mat-icon>\n    } @else if (code.type === 'UNSET') {\n    <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n    } @else if (code.type === 'INTENDED_INCOMPLETE' ) {\n    <mat-icon style=\"color: darkgrey\">disabled_by_default</mat-icon>\n    } @else if (code.type === 'RESIDUAL') {\n    <mat-icon>close</mat-icon>\n    } @else if (code.type === 'RESIDUAL_AUTO') {\n    <mat-icon style=\"color: orangered\">close</mat-icon>\n    }\n  </button>\n  <mat-menu #selectCodeType>\n    @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n    <button\n      mat-menu-item\n      [disabled]=\"\n        allCodes.length > 1 &&\n        (codeType === 'RESIDUAL_AUTO' ||\n          codeType === 'INTENDED_INCOMPLETE' ||\n          codeType === 'RESIDUAL') &&\n        (hasResidualAutoCode || hasIntendedIncompleteAutoCode)\n      \"\n      (click)=\"setCodeType(codeType)\"\n    >\n      @if (codeType === 'FULL_CREDIT') {\n      <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n      } @else if (codeType === 'PARTIAL_CREDIT') {\n      <mat-icon style=\"color: green\">check</mat-icon>\n      } @else if (codeType === 'NO_CREDIT') {\n      <mat-icon style=\"color: gold\">remove_done</mat-icon>\n      } @else if (codeType === 'UNSET') {\n      <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n      } @else if (codeType === 'TO_CHECK') {\n      <mat-icon style=\"color: blue\"\n        ><svg\n          xmlns=\"http://www.w3.org/2000/svg\"\n          height=\"24px\"\n          viewBox=\"0 -960 960 960\"\n          width=\"24px\"\n        >\n          <path\n            d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n          /></svg\n      ></mat-icon>\n      } @else if (codeType === 'INTENDED_INCOMPLETE' ) {\n      <mat-icon style=\"color: lightgrey\">disabled_by_default</mat-icon>\n      } @else if (codeType === 'RESIDUAL') {\n      <mat-icon>close</mat-icon>\n      } @else if (codeType === 'RESIDUAL_AUTO') {\n      <mat-icon style=\"color: orangered\">close</mat-icon>\n      } @else {\n      <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n      }\n      {{ \"code.prompt.add-\" + codeType | translate }}\n    </button>\n    @if (codeType === 'UNSET') {\n    <mat-divider></mat-divider>\n    } }\n  </mat-menu>\n  <div\n    class=\"code-content fx-column-start-stretch\"\n  >\n    <div class=\"code-main-data fx-row-start-center fx-gap-5\">\n      @if (code.id === 'INVALID') {\n      <div\n        class=\"fx-flex-fill\"\n        [class.type-residual-auto]=\"code.type === 'RESIDUAL_AUTO'\"\n        [class.type-no-residual-auto]=\"code.type !== 'RESIDUAL_AUTO'\"\n      >\n        {{ \"code.type-label.\" + code.type | translate }};\n        {{ \"code.is-invalid\" | translate }}\n      </div>\n      <button\n        mat-icon-button\n        [style.width.px]=\"50\"\n        (click)=\"setCodeValid()\"\n        [matTooltip]=\"'code.make-not-invalid' | translate\"\n      >\n        <mat-icon>do_not_disturb_off</mat-icon>\n      </button>\n      } @if (code.id === 'INTENDED_INCOMPLETE') {\n      <div [class]=\"'type-intended-incomplete fx-flex-fill'\">\n        {{ \"code.type-label.\" + code.type | translate }}\n      </div>\n      } @if (code.id !== 'INVALID' && code.id !== 'INTENDED_INCOMPLETE') {\n      <mat-form-field\n        [class.unique-id]=\"codeIdIsUnique(code.id, codeIndex)\"\n        [class.not-unique-id]=\"!codeIdIsUnique(code.id, codeIndex)\"\n        [style.width.px]=\"80\"\n      >\n        <mat-label>{{ \"code.id\" | translate }}</mat-label>\n        <input\n          matInput\n          required\n          [(ngModel)]=\"code.id\"\n          (ngModelChange)=\"setCodeChanged()\"\n          type=\"number\"\n        />\n      </mat-form-field>\n      @if (code.type === 'UNSET') {\n      <mat-form-field class=\"fx-flex-fill\">\n        <mat-label>{{ \"code.description\" | translate }}</mat-label>\n        <input\n          matInput\n          [placeholder]=\"'code.description' | translate\"\n          [(ngModel)]=\"code.label\"\n          (ngModelChange)=\"setCodeChanged()\"\n        />\n      </mat-form-field>\n      } @else {\n      <div\n        class=\"fx-flex-fill\"\n        [class.type-residual-auto]=\"code.type === 'RESIDUAL_AUTO'\"\n        style=\"align-content: center\"\n      >\n        {{ \"code.type-label.\" + code.type | translate }}\n      </div>\n      } @if (code.type !== 'RESIDUAL' && code.type !== 'RESIDUAL_AUTO' &&\n      code.type !== 'INTENDED_INCOMPLETE') {\n      <mat-form-field\n        [class.correct]=\"(code.score ?? 0) > 0\"\n        [class.not-correct]=\"(code.score ?? 0) <= 0\"\n        [style.width.px]=\"100\"\n      >\n        <mat-label>{{ \"code.score\" | translate }}</mat-label>\n        <input\n          matInput\n          type=\"number\"\n          required\n          [disabled]=\"code.type === 'NO_CREDIT'\"\n          [(ngModel)]=\"code.score\"\n          (ngModelChange)=\"setCodeChanged()\"\n        />\n      </mat-form-field>\n      } @if ((code.type === 'RESIDUAL' || code.type === 'RESIDUAL_AUTO' ||\n      code.type === 'INTENDED_INCOMPLETE') && (code.id !== null)) {\n      <button\n        mat-icon-button\n        [style.width.px]=\"50\"\n        (click)=\"setCodeInvalid()\"\n        [matTooltip]=\"'code.make-invalid' | translate\"\n      >\n        <mat-icon>do_not_disturb_on</mat-icon>\n      </button>\n      } }\n    </div>\n    @if (codeModel !== 'MANUAL_ONLY' && code.type !== 'RESIDUAL' && code.type\n    !== 'RESIDUAL_AUTO' && code.type !== 'INTENDED_INCOMPLETE') {\n    <code-rules\n      [style.padding-left.px]=\"4\"\n      [style.height]=\"'calc(100% - 60px)'\"\n      [code]=\"code\"\n      [fragmentMode]=\"fragmentMode\"\n      [varInfo]=\"varInfo\"\n      (codeRulesChanged)=\"setCodeChanged()\"\n    >\n    </code-rules>\n    } @else if (codeModel === 'MANUAL_ONLY' && showManualOnlyInstruction()) {\n    <code-instruction\n      [code]=\"code\"\n      (codeDataChanged)=\"setCodeChanged()\"\n      [userRole]=\"schemerService.userRole\"\n      [hasResidualAutoCode]=\"hasResidualAutoCode\"\n      [hasIntendedIncompleteCode]=\"hasIntendedIncompleteAutoCode\"\n      [suppressResidualAutoWarning]=\"suppressResidualAutoWarning()\"\n    >\n    </code-instruction>\n    }\n  </div>\n  @if ((codeModel ?? 'NONE') === 'NONE' || codeModel === 'MANUAL_AND_RULES') {\n  @if (showSideInstruction()) {\n  <code-instruction\n    [code]=\"code\"\n    (codeDataChanged)=\"setCodeChanged()\"\n    [userRole]=\"schemerService.userRole\"\n    [hasResidualAutoCode]=\"hasResidualAutoCode\"\n    [hasIntendedIncompleteCode]=\"hasIntendedIncompleteAutoCode\"\n    [suppressResidualAutoWarning]=\"suppressResidualAutoWarning()\"\n    class=\"side-instruction\"\n  >\n  </code-instruction>\n  } @else {\n  <div class=\"side-instruction\"></div>\n  } }\n  <button\n    mat-icon-button\n    (click)=\"copySingleCode()\"\n    class=\"copy-code\"\n    [disabled]=\"!canCopySingleCode()\"\n    [matTooltip]=\"'varList.copy-code' | translate\"\n  >\n    <mat-icon>content_copy</mat-icon>\n  </button>\n  <button\n    mat-icon-button\n    (click)=\"deleteCode(codeIndex)\"\n    class=\"delete-code\"\n    [disabled]=\"schemerService.userRole === 'RO'\"\n    [matTooltip]=\"'code.prompt.delete' | translate\"\n  >\n    <mat-icon>delete</mat-icon>\n  </button>\n  }\n</div>\n", styles: [".code{display:grid;grid-template-columns:48px minmax(0,1fr) 48px 48px;gap:10px;margin-bottom:10px}.code.with-instruction{grid-template-columns:48px minmax(0,3fr) minmax(0,2fr) 48px 48px}.code-content,.side-instruction{min-width:0}.code-main-data{background-color:#f5f5f5;flex-wrap:wrap}.code-main-data>mat-form-field{flex-shrink:0}@container var-coding (max-width: 800px){.code,.code.with-instruction{grid-template-columns:48px minmax(0,1fr) 48px 48px}.code-type{grid-column:1;grid-row:1}.copy-code{grid-column:3;grid-row:1}.delete-code{grid-column:4;grid-row:1}.code-content{grid-column:1 / -1;grid-row:2}.side-instruction{grid-column:1 / -1;grid-row:3}}.not-unique-id{border:orange solid 2px}.correct{border:limegreen solid 2px}.unique-id,.not-correct{border:transparent solid 2px}.type-residual-auto{background:bisque;padding:10px 4px}.type-no-residual-auto{padding-left:8px}.type-intended-incomplete{background:bisque;padding:15px 4px}\n"], dependencies: [{ kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: CodeRulesComponent, selector: "code-rules", inputs: ["code", "varInfo", "fragmentMode"], outputs: ["codeRulesChanged"] }, { kind: "component", type: CodeInstructionComponent, selector: "code-instruction", inputs: ["code", "userRole", "hasIntendedIncompleteCode", "hasResidualAutoCode", "suppressResidualAutoWarning"], outputs: ["codeDataChanged"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SingleCodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'single-code', standalone: true, imports: [
                        MatIconButton,
                        MatTooltipModule,
                        MatIcon,
                        MatFormField,
                        MatLabel,
                        MatInput,
                        ReactiveFormsModule,
                        FormsModule,
                        TranslateModule,
                        CodeRulesComponent,
                        CodeInstructionComponent,
                        MatDivider,
                        MatMenu,
                        MatMenuItem,
                        MatMenuTrigger
                    ], template: "<div class=\"code\" [class.with-instruction]=\"(codeModel ?? 'NONE') === 'NONE' || codeModel === 'MANUAL_AND_RULES'\">\n  @if (code && allCodes) {\n  <button\n    mat-icon-button\n    class=\"code-type\"\n    [matMenuTriggerFor]=\"selectCodeType\"\n    [matTooltip]=\"'code.prompt.add-' + code.type | translate\"\n    [matTooltipShowDelay]=\"500\"\n    [disabled]=\"schemerService.userRole === 'RO'\"\n  >\n    @if (code.type === 'FULL_CREDIT') {\n    <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n    } @else if (code.type === 'PARTIAL_CREDIT') {\n    <mat-icon style=\"color: green\">check</mat-icon>\n    } @else if (code.type === 'TO_CHECK') {\n    <mat-icon style=\"color: blue\"\n      ><svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        height=\"24px\"\n        viewBox=\"0 -960 960 960\"\n        width=\"24px\"\n      >\n        <path\n          d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n        /></svg\n    ></mat-icon>\n    } @else if (code.type === 'NO_CREDIT') {\n    <mat-icon style=\"color: gold\">remove_done</mat-icon>\n    } @else if (code.type === 'UNSET') {\n    <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n    } @else if (code.type === 'INTENDED_INCOMPLETE' ) {\n    <mat-icon style=\"color: darkgrey\">disabled_by_default</mat-icon>\n    } @else if (code.type === 'RESIDUAL') {\n    <mat-icon>close</mat-icon>\n    } @else if (code.type === 'RESIDUAL_AUTO') {\n    <mat-icon style=\"color: orangered\">close</mat-icon>\n    }\n  </button>\n  <mat-menu #selectCodeType>\n    @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n    <button\n      mat-menu-item\n      [disabled]=\"\n        allCodes.length > 1 &&\n        (codeType === 'RESIDUAL_AUTO' ||\n          codeType === 'INTENDED_INCOMPLETE' ||\n          codeType === 'RESIDUAL') &&\n        (hasResidualAutoCode || hasIntendedIncompleteAutoCode)\n      \"\n      (click)=\"setCodeType(codeType)\"\n    >\n      @if (codeType === 'FULL_CREDIT') {\n      <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n      } @else if (codeType === 'PARTIAL_CREDIT') {\n      <mat-icon style=\"color: green\">check</mat-icon>\n      } @else if (codeType === 'NO_CREDIT') {\n      <mat-icon style=\"color: gold\">remove_done</mat-icon>\n      } @else if (codeType === 'UNSET') {\n      <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n      } @else if (codeType === 'TO_CHECK') {\n      <mat-icon style=\"color: blue\"\n        ><svg\n          xmlns=\"http://www.w3.org/2000/svg\"\n          height=\"24px\"\n          viewBox=\"0 -960 960 960\"\n          width=\"24px\"\n        >\n          <path\n            d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n          /></svg\n      ></mat-icon>\n      } @else if (codeType === 'INTENDED_INCOMPLETE' ) {\n      <mat-icon style=\"color: lightgrey\">disabled_by_default</mat-icon>\n      } @else if (codeType === 'RESIDUAL') {\n      <mat-icon>close</mat-icon>\n      } @else if (codeType === 'RESIDUAL_AUTO') {\n      <mat-icon style=\"color: orangered\">close</mat-icon>\n      } @else {\n      <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n      }\n      {{ \"code.prompt.add-\" + codeType | translate }}\n    </button>\n    @if (codeType === 'UNSET') {\n    <mat-divider></mat-divider>\n    } }\n  </mat-menu>\n  <div\n    class=\"code-content fx-column-start-stretch\"\n  >\n    <div class=\"code-main-data fx-row-start-center fx-gap-5\">\n      @if (code.id === 'INVALID') {\n      <div\n        class=\"fx-flex-fill\"\n        [class.type-residual-auto]=\"code.type === 'RESIDUAL_AUTO'\"\n        [class.type-no-residual-auto]=\"code.type !== 'RESIDUAL_AUTO'\"\n      >\n        {{ \"code.type-label.\" + code.type | translate }};\n        {{ \"code.is-invalid\" | translate }}\n      </div>\n      <button\n        mat-icon-button\n        [style.width.px]=\"50\"\n        (click)=\"setCodeValid()\"\n        [matTooltip]=\"'code.make-not-invalid' | translate\"\n      >\n        <mat-icon>do_not_disturb_off</mat-icon>\n      </button>\n      } @if (code.id === 'INTENDED_INCOMPLETE') {\n      <div [class]=\"'type-intended-incomplete fx-flex-fill'\">\n        {{ \"code.type-label.\" + code.type | translate }}\n      </div>\n      } @if (code.id !== 'INVALID' && code.id !== 'INTENDED_INCOMPLETE') {\n      <mat-form-field\n        [class.unique-id]=\"codeIdIsUnique(code.id, codeIndex)\"\n        [class.not-unique-id]=\"!codeIdIsUnique(code.id, codeIndex)\"\n        [style.width.px]=\"80\"\n      >\n        <mat-label>{{ \"code.id\" | translate }}</mat-label>\n        <input\n          matInput\n          required\n          [(ngModel)]=\"code.id\"\n          (ngModelChange)=\"setCodeChanged()\"\n          type=\"number\"\n        />\n      </mat-form-field>\n      @if (code.type === 'UNSET') {\n      <mat-form-field class=\"fx-flex-fill\">\n        <mat-label>{{ \"code.description\" | translate }}</mat-label>\n        <input\n          matInput\n          [placeholder]=\"'code.description' | translate\"\n          [(ngModel)]=\"code.label\"\n          (ngModelChange)=\"setCodeChanged()\"\n        />\n      </mat-form-field>\n      } @else {\n      <div\n        class=\"fx-flex-fill\"\n        [class.type-residual-auto]=\"code.type === 'RESIDUAL_AUTO'\"\n        style=\"align-content: center\"\n      >\n        {{ \"code.type-label.\" + code.type | translate }}\n      </div>\n      } @if (code.type !== 'RESIDUAL' && code.type !== 'RESIDUAL_AUTO' &&\n      code.type !== 'INTENDED_INCOMPLETE') {\n      <mat-form-field\n        [class.correct]=\"(code.score ?? 0) > 0\"\n        [class.not-correct]=\"(code.score ?? 0) <= 0\"\n        [style.width.px]=\"100\"\n      >\n        <mat-label>{{ \"code.score\" | translate }}</mat-label>\n        <input\n          matInput\n          type=\"number\"\n          required\n          [disabled]=\"code.type === 'NO_CREDIT'\"\n          [(ngModel)]=\"code.score\"\n          (ngModelChange)=\"setCodeChanged()\"\n        />\n      </mat-form-field>\n      } @if ((code.type === 'RESIDUAL' || code.type === 'RESIDUAL_AUTO' ||\n      code.type === 'INTENDED_INCOMPLETE') && (code.id !== null)) {\n      <button\n        mat-icon-button\n        [style.width.px]=\"50\"\n        (click)=\"setCodeInvalid()\"\n        [matTooltip]=\"'code.make-invalid' | translate\"\n      >\n        <mat-icon>do_not_disturb_on</mat-icon>\n      </button>\n      } }\n    </div>\n    @if (codeModel !== 'MANUAL_ONLY' && code.type !== 'RESIDUAL' && code.type\n    !== 'RESIDUAL_AUTO' && code.type !== 'INTENDED_INCOMPLETE') {\n    <code-rules\n      [style.padding-left.px]=\"4\"\n      [style.height]=\"'calc(100% - 60px)'\"\n      [code]=\"code\"\n      [fragmentMode]=\"fragmentMode\"\n      [varInfo]=\"varInfo\"\n      (codeRulesChanged)=\"setCodeChanged()\"\n    >\n    </code-rules>\n    } @else if (codeModel === 'MANUAL_ONLY' && showManualOnlyInstruction()) {\n    <code-instruction\n      [code]=\"code\"\n      (codeDataChanged)=\"setCodeChanged()\"\n      [userRole]=\"schemerService.userRole\"\n      [hasResidualAutoCode]=\"hasResidualAutoCode\"\n      [hasIntendedIncompleteCode]=\"hasIntendedIncompleteAutoCode\"\n      [suppressResidualAutoWarning]=\"suppressResidualAutoWarning()\"\n    >\n    </code-instruction>\n    }\n  </div>\n  @if ((codeModel ?? 'NONE') === 'NONE' || codeModel === 'MANUAL_AND_RULES') {\n  @if (showSideInstruction()) {\n  <code-instruction\n    [code]=\"code\"\n    (codeDataChanged)=\"setCodeChanged()\"\n    [userRole]=\"schemerService.userRole\"\n    [hasResidualAutoCode]=\"hasResidualAutoCode\"\n    [hasIntendedIncompleteCode]=\"hasIntendedIncompleteAutoCode\"\n    [suppressResidualAutoWarning]=\"suppressResidualAutoWarning()\"\n    class=\"side-instruction\"\n  >\n  </code-instruction>\n  } @else {\n  <div class=\"side-instruction\"></div>\n  } }\n  <button\n    mat-icon-button\n    (click)=\"copySingleCode()\"\n    class=\"copy-code\"\n    [disabled]=\"!canCopySingleCode()\"\n    [matTooltip]=\"'varList.copy-code' | translate\"\n  >\n    <mat-icon>content_copy</mat-icon>\n  </button>\n  <button\n    mat-icon-button\n    (click)=\"deleteCode(codeIndex)\"\n    class=\"delete-code\"\n    [disabled]=\"schemerService.userRole === 'RO'\"\n    [matTooltip]=\"'code.prompt.delete' | translate\"\n  >\n    <mat-icon>delete</mat-icon>\n  </button>\n  }\n</div>\n", styles: [".code{display:grid;grid-template-columns:48px minmax(0,1fr) 48px 48px;gap:10px;margin-bottom:10px}.code.with-instruction{grid-template-columns:48px minmax(0,3fr) minmax(0,2fr) 48px 48px}.code-content,.side-instruction{min-width:0}.code-main-data{background-color:#f5f5f5;flex-wrap:wrap}.code-main-data>mat-form-field{flex-shrink:0}@container var-coding (max-width: 800px){.code,.code.with-instruction{grid-template-columns:48px minmax(0,1fr) 48px 48px}.code-type{grid-column:1;grid-row:1}.copy-code{grid-column:3;grid-row:1}.delete-code{grid-column:4;grid-row:1}.code-content{grid-column:1 / -1;grid-row:2}.side-instruction{grid-column:1 / -1;grid-row:3}}.not-unique-id{border:orange solid 2px}.correct{border:limegreen solid 2px}.unique-id,.not-correct{border:transparent solid 2px}.type-residual-auto{background:bisque;padding:10px 4px}.type-no-residual-auto{padding-left:8px}.type-intended-incomplete{background:bisque;padding:15px 4px}\n"] }]
        }], ctorParameters: () => [{ type: SchemerService }], propDecorators: { codeDataChanged: [{
                type: Output
            }], code: [{
                type: Input
            }], allCodes: [{
                type: Input
            }], varInfo: [{
                type: Input
            }], fragmentMode: [{
                type: Input
            }], codeIndex: [{
                type: Input
            }], codeModel: [{
                type: Input
            }], sourceType: [{
                type: Input
            }], hasResidualAutoCode: [{
                type: Input
            }], hasIntendedIncompleteAutoCode: [{
                type: Input
            }] } });

class VariableAliasPipe {
    constructor(schemerService) {
        this.schemerService = schemerService;
    }
    transform(value, maxEntries) {
        if (Array.isArray(value))
            return this.schemerService.getVariableAliasByIdListString(value, maxEntries || 0);
        return this.schemerService.getVariableAliasById(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: VariableAliasPipe, deps: [{ token: SchemerService }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.24", ngImport: i0, type: VariableAliasPipe, isStandalone: true, name: "varAlias" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: VariableAliasPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'varAlias',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: SchemerService }] });

const VARIABLE_IDENTIFIER_PATTERN = /^[0-9A-Za-z_-]+$/;
const isValidVariableIdentifier = (value) => (typeof value === 'string' && VARIABLE_IDENTIFIER_PATTERN.test(value));
const addIdentifierError = (errors, value, variableIndex, property) => {
    if (!isValidVariableIdentifier(value)) {
        errors.push({
            code: value === '' || value === null || value === undefined ?
                'EMPTY_IDENTIFIER' :
                'INVALID_CHARACTERS',
            variableIndex,
            property,
            value
        });
    }
};
const addDuplicateErrors = (variables, property, code, errors) => {
    const firstIndexByIdentifier = new Map();
    variables.forEach((variable, variableIndex) => {
        const value = variable[property];
        if (!isValidVariableIdentifier(value))
            return;
        const normalizedValue = value.toLowerCase();
        const conflictingVariableIndex = firstIndexByIdentifier.get(normalizedValue);
        if (conflictingVariableIndex === undefined) {
            firstIndexByIdentifier.set(normalizedValue, variableIndex);
        }
        else {
            errors.push({
                code,
                variableIndex,
                property,
                value,
                conflictingVariableIndex
            });
        }
    });
};
const addPublicIdentifierCollisionErrors = (variables, errors) => {
    const firstPublicIdentifier = new Map();
    variables.forEach((variable, variableIndex) => {
        const property = variable.alias === undefined ? 'id' : 'alias';
        const value = variable[property];
        if (!isValidVariableIdentifier(value))
            return;
        const normalizedValue = value.toLowerCase();
        const conflicting = firstPublicIdentifier.get(normalizedValue);
        if (!conflicting) {
            firstPublicIdentifier.set(normalizedValue, { variableIndex, property });
        }
        else if (conflicting.property !== property) {
            errors.push({
                code: 'PUBLIC_IDENTIFIER_COLLISION',
                variableIndex,
                property,
                value,
                conflictingVariableIndex: conflicting.variableIndex
            });
        }
    });
};
const validateVariableList = (variables) => {
    const errors = [];
    variables.forEach((variable, variableIndex) => {
        addIdentifierError(errors, variable.id, variableIndex, 'id');
        if (variable.alias !== undefined) {
            addIdentifierError(errors, variable.alias, variableIndex, 'alias');
        }
    });
    addDuplicateErrors(variables, 'id', 'DUPLICATE_ID', errors);
    addDuplicateErrors(variables, 'alias', 'DUPLICATE_ALIAS', errors);
    addPublicIdentifierCollisionErrors(variables, errors);
    return errors;
};

const SOLVER_VARIABLE_PREFIX = '$';
const SOLVER_VARIABLE_REFERENCE_PATTERN = /\$\{\s*([\w,-]+)(?:\s*\[\s*(\d+)\s*])?(?:\s*:([^}:]*))?(?:\s*:([^}:]*))?\s*}/g;
class EditSourceParametersDialog {
    constructor(data, schemerService, translateService) {
        this.data = data;
        this.schemerService = schemerService;
        this.translateService = translateService;
        this.solverExpressionDocsUrl = 'https://mathjs.org/docs/expressions/syntax.html';
        this.solverPolicySyntax = `${SOLVER_VARIABLE_PREFIX}{VAR[i]:emptyPolicy:nonNumericPolicy}`;
        this.solverExpressionExamples = [
            {
                expression: '1 + 2 * 3',
                descriptionKey: 'derive-processing.solver-help.examples.arithmetic'
            },
            {
                expression: `${SOLVER_VARIABLE_PREFIX}{Punkte} + ${SOLVER_VARIABLE_PREFIX}{Bonus}`,
                descriptionKey: 'derive-processing.solver-help.examples.variables'
            },
            {
                expression: `round(${SOLVER_VARIABLE_PREFIX}{Punkte} / ` +
                    `${SOLVER_VARIABLE_PREFIX}{MaxPunkte} * 100, 1)`,
                descriptionKey: 'derive-processing.solver-help.examples.function'
            },
            {
                expression: `${SOLVER_VARIABLE_PREFIX}{Punkte} >= 5 ? 1 : 0`,
                descriptionKey: 'derive-processing.solver-help.examples.condition'
            },
            {
                expression: `${SOLVER_VARIABLE_PREFIX}{Bruch[0]:INC}`,
                descriptionKey: 'derive-processing.solver-help.examples.fragment'
            },
            {
                expression: `${SOLVER_VARIABLE_PREFIX}{Summand:0:INC}`,
                descriptionKey: 'derive-processing.solver-help.examples.policies'
            }
        ];
        this.solverVariablePrefix = SOLVER_VARIABLE_PREFIX;
        this.sourceTypeList = [
            'COPY_VALUE',
            'CONCAT_CODE',
            'SUM_CODE',
            'SUM_SCORE',
            'UNIQUE_VALUES',
            'SOLVER',
            'MANUAL'
        ];
        this.possibleDeriveProcessing = [];
        this.selectedSources = new FormControl();
        this.possibleNewSources = new Map([]);
        this.newVariableMode = false;
        this.solverTestValues = {};
        this.solverTestResult = null;
        // eslint-disable-next-line class-methods-use-this
        this.compareFn = (a, b) => a.value.localeCompare(b.value);
        this.newVariableMode = !this.data.selfId;
        const shadowProcessing = {
            ...this.data,
            sourceType: this.data.sourceType,
            sourceParameters: {
                ...this.data.sourceParameters,
                solverExpression: this.data.sourceParameters.solverExpression,
                processing: [...(this.data.sourceParameters.processing || [])]
            },
            deriveSources: [...this.data.deriveSources]
        };
        this.data = shadowProcessing;
        this.updatePossibleDeriveProcessing();
        this.updatePossibleNewSources();
    }
    get selectedSolverSources() {
        return (this.data.deriveSources || []).map(sourceId => ({
            id: sourceId,
            label: this.possibleNewSources.get(sourceId) || sourceId
        }));
    }
    get solverSourceReferences() {
        return this.selectedSolverSources.flatMap(source => {
            const fragmentReferences = this.getSourceFragmentIndexes(source.id)
                .map(fragmentIndex => ({
                ...source,
                fragmentIndex
            }));
            return [source, ...fragmentReferences];
        });
    }
    get solverSourceWarning() {
        const missingSourceLabels = this.getMissingSolverSourceIds()
            .map(sourceId => this.getSourceLabel(sourceId));
        if (missingSourceLabels.length < 1)
            return null;
        return `${this.tr('derive-processing.solver-source-warning.unselected-sources')}: ${missingSourceLabels.join(', ')}`;
    }
    updatePossibleNewSources() {
        const codingScheme = this.schemerService.codingScheme;
        if (!codingScheme)
            return;
        const validCodings = codingScheme.variableCodings.filter((variableCoding) => (!this.isOwnVariable(variableCoding) &&
            variableCoding.sourceType !== 'BASE_NO_VALUE' &&
            !this.isDerivedFromSelf(variableCoding, codingScheme.variableCodings)));
        this.possibleNewSources = new Map(validCodings.map(variableCoding => [
            variableCoding.id,
            variableCoding.alias || variableCoding.id
        ]));
        const possibleSourceIds = new Set(this.possibleNewSources.keys());
        this.data.deriveSources = this.data.deriveSources.filter(sourceId => possibleSourceIds.has(sourceId));
        this.selectedSources.setValue(this.data.deriveSources);
        this.syncSolverTestValues();
    }
    updatePossibleDeriveProcessing() {
        const processingOptions = {
            BASE: [
                'TAKE_DISPLAYED_AS_VALUE_CHANGED',
                'TAKE_NOT_REACHED_AS_VALUE_CHANGED',
                'TAKE_EMPTY_AS_VALID'
            ],
            UNIQUE_VALUES: [
                'REMOVE_ALL_SPACES',
                'REMOVE_DISPENSABLE_SPACES',
                'TO_NUMBER',
                'TO_LOWER_CASE'
            ],
            CONCAT_CODE: ['SORT']
        };
        this.possibleDeriveProcessing =
            processingOptions[this.data.sourceType] || [];
        this.clearSolverTestResult();
    }
    alterProcessing(processingId, checked) {
        const processingList = this.data.sourceParameters.processing;
        if (!processingList)
            return;
        const processIndex = processingList.indexOf(processingId);
        if (checked && processIndex === -1) {
            processingList.push(processingId);
            return;
        }
        if (!checked && processIndex !== -1) {
            processingList.splice(processIndex, 1);
        }
    }
    updateDeriveSources() {
        this.data.deriveSources = this.selectedSources.value || [];
        this.syncSolverTestValues();
        this.clearSolverTestResult();
    }
    toggleAllSelection() {
        this.selectedSources.setValue(Array.from(this.possibleNewSources.keys()));
        this.updateDeriveSources();
    }
    insertSolverSourceReference(source, input) {
        const reference = this.getSolverVariableReference(source.label || source.id, source.fragmentIndex);
        const expression = this.data.sourceParameters.solverExpression || '';
        const selectionStart = input.selectionStart ?? expression.length;
        const selectionEnd = input.selectionEnd ?? selectionStart;
        this.data.sourceParameters.solverExpression =
            `${expression.slice(0, selectionStart)}${reference}${expression.slice(selectionEnd)}`;
        this.clearSolverTestResult();
        const cursorPosition = selectionStart + reference.length;
        window.setTimeout(() => {
            input.focus();
            input.setSelectionRange(cursorPosition, cursorPosition);
        });
    }
    getSolverSourceReference(source) {
        return this.getSolverVariableReference(source.label || source.id, source.fragmentIndex);
    }
    clearSolverTestResult() {
        this.solverTestResult = null;
    }
    runSolverTest() {
        this.updateDeriveSources();
        const expression = this.data.sourceParameters.solverExpression || '';
        if (!expression.trim()) {
            this.setSolverTestError('derive-processing.solver-test.error-expression-missing');
            return;
        }
        if (!this.data.deriveSources.length) {
            this.setSolverTestError('derive-processing.solver-test.error-sources-missing');
            return;
        }
        const variableCodings = this.getVariableCodingsForSolverTest();
        const solverReferences = EditSourceParametersDialog.getSolverReferences(expression, variableCodings);
        const referencedVariables = EditSourceParametersDialog
            .getReferencedSolverVariables(solverReferences);
        const missingSources = this.getMissingSolverSourceIds(referencedVariables);
        if (missingSources.length > 0) {
            this.solverTestResult = {
                type: 'error',
                message: `${this.tr('derive-processing.solver-test.error-unselected-source')}: ${missingSources.map(sourceId => this.getSourceLabel(sourceId))
                    .join(', ')}`
            };
            return;
        }
        const invalidNumericSources = [
            ...new Set(solverReferences
                .filter(reference => this.isInvalidSolverTestValue(reference))
                .map(reference => reference.sourceId))
        ];
        if (invalidNumericSources.length > 0) {
            this.solverTestResult = {
                type: 'error',
                message: `${this.tr('derive-processing.solver-test.error-invalid-value')}: ${invalidNumericSources.map(sourceId => this.getSourceLabel(sourceId))
                    .join(', ')}`
            };
            return;
        }
        try {
            const result = CodingSchemeFactory.deriveValue(variableCodings, this.getSolverTestCoding(), this.getSolverTestResponses());
            if (result.status === 'VALUE_CHANGED') {
                this.solverTestResult = {
                    type: 'success',
                    message: `${this.tr('derive-processing.solver-test.result')}: ${EditSourceParametersDialog.formatSolverTestValue(result.value)}`
                };
                return;
            }
            if (result.status === 'CODING_INCOMPLETE') {
                this.solverTestResult = {
                    type: 'incomplete',
                    message: `${this.tr('derive-processing.solver-test.result')}: ${this.tr('status-label.CODING_INCOMPLETE')}`
                };
                return;
            }
        }
        catch {
            // fall through to the shared error message
        }
        this.setSolverTestError('derive-processing.solver-test.error-evaluation');
    }
    syncSolverTestValues() {
        const selectedSourceIds = new Set(this.data.deriveSources || []);
        const nextValues = {};
        selectedSourceIds.forEach(sourceId => {
            nextValues[sourceId] = this.solverTestValues[sourceId] || '';
        });
        this.solverTestValues = nextValues;
    }
    getVariableCodingsForSolverTest() {
        const sourceCodings = this.schemerService.codingScheme?.variableCodings ||
            [];
        const solverCoding = this.getSolverTestCoding();
        const hasSelfCoding = sourceCodings.some(coding => coding.id === solverCoding.id);
        if (hasSelfCoding) {
            return sourceCodings.map(coding => (coding.id === solverCoding.id ? solverCoding : coding));
        }
        return [...sourceCodings, solverCoding];
    }
    getSolverTestCoding() {
        return {
            id: this.data.selfId || this.data.selfAlias || '__solver_test__',
            alias: this.data.selfAlias,
            sourceType: 'SOLVER',
            sourceParameters: {
                ...this.data.sourceParameters,
                processing: this.data.sourceParameters.processing || [],
                solverExpression: this.data.sourceParameters.solverExpression || ''
            },
            deriveSources: [...this.data.deriveSources]
        };
    }
    getSolverTestResponses() {
        return this.data.deriveSources.map(sourceId => ({
            id: sourceId,
            value: this.solverTestValues[sourceId] || '',
            status: 'VALUE_CHANGED'
        }));
    }
    getMissingSolverSourceIds(referencedVariables) {
        if (this.data.sourceType !== 'SOLVER')
            return [];
        const expression = this.data.sourceParameters.solverExpression || '';
        if (!expression.trim())
            return [];
        const solverReferences = referencedVariables ||
            EditSourceParametersDialog.getReferencedSolverVariables(EditSourceParametersDialog.getSolverReferences(expression, this.getVariableCodingsForSolverTest()));
        return solverReferences.filter(variableId => !this.data.deriveSources.includes(variableId));
    }
    static getSolverReferences(expression, variableCodings) {
        const variableIdsByAlias = new Map(variableCodings
            .filter(coding => Boolean(coding.alias))
            .map(coding => [coding.alias, coding.id]));
        return Array.from(expression.matchAll(SOLVER_VARIABLE_REFERENCE_PATTERN))
            .map(match => ({
            sourceId: variableIdsByAlias.get(match[1]) || match[1],
            hasFragmentIndex: typeof match[2] !== 'undefined',
            emptyPolicy: match[3],
            nonNumericPolicy: match[4]
        }));
    }
    static getReferencedSolverVariables(references) {
        return [...new Set(references.map(reference => reference.sourceId))];
    }
    isInvalidSolverTestValue(reference) {
        if (reference.hasFragmentIndex)
            return false;
        const value = this.solverTestValues[reference.sourceId] || '';
        if (!value.trim())
            return false;
        if (CodingFactory$1.getValueAsNumber(value) !== null)
            return false;
        const policy = reference.nonNumericPolicy;
        if (typeof policy === 'undefined')
            return true;
        const trimmedPolicy = policy.trim();
        return trimmedPolicy.toUpperCase() !== 'INC' &&
            CodingFactory$1.getValueAsNumber(trimmedPolicy) === null;
    }
    getSourceLabel(sourceId) {
        const sourceAlias = this.schemerService.getVariableAliasById(sourceId);
        return this.possibleNewSources.get(sourceId) ||
            (sourceAlias === '?' ? sourceId : sourceAlias);
    }
    isOwnVariable(variableCoding) {
        return this.getSelfReferenceKeys([variableCoding]).some(selfReference => (variableCoding.id === selfReference ||
            variableCoding.alias === selfReference));
    }
    isDerivedFromSelf(variableCoding, variableCodings) {
        const selfReferenceKeys = new Set(this.getSelfReferenceKeys(variableCodings));
        if (selfReferenceKeys.size < 1)
            return false;
        const codingsByReference = new Map();
        variableCodings.forEach(coding => {
            codingsByReference.set(coding.id, coding);
            if (coding.alias)
                codingsByReference.set(coding.alias, coding);
        });
        const visited = new Set();
        const sourcesToCheck = [...(variableCoding.deriveSources || [])];
        while (sourcesToCheck.length > 0) {
            const sourceReference = sourcesToCheck.pop();
            if (sourceReference) {
                if (selfReferenceKeys.has(sourceReference))
                    return true;
                const sourceCoding = codingsByReference.get(sourceReference);
                if (sourceCoding && !visited.has(sourceCoding.id)) {
                    if (selfReferenceKeys.has(sourceCoding.id) ||
                        (sourceCoding.alias && selfReferenceKeys.has(sourceCoding.alias))) {
                        return true;
                    }
                    visited.add(sourceCoding.id);
                    sourcesToCheck.push(...(sourceCoding.deriveSources || []));
                }
            }
        }
        return false;
    }
    getSelfReferenceKeys(variableCodings) {
        const selfReferences = new Set();
        if (this.data.selfId)
            selfReferences.add(this.data.selfId);
        if (this.data.selfAlias)
            selfReferences.add(this.data.selfAlias);
        const selfCoding = variableCodings.find(coding => ((this.data.selfId && coding.id === this.data.selfId) ||
            (this.data.selfAlias && (coding.id === this.data.selfAlias ||
                coding.alias === this.data.selfAlias))));
        if (selfCoding) {
            selfReferences.add(selfCoding.id);
            if (selfCoding.alias)
                selfReferences.add(selfCoding.alias);
        }
        return Array.from(selfReferences);
    }
    static formatSolverTestValue(value) {
        if (typeof value === 'string')
            return value;
        return JSON.stringify(value) || '';
    }
    getSourceFragmentIndexes(sourceId) {
        const sourceCoding = this.schemerService.codingScheme?.variableCodings
            .find(coding => coding.id === sourceId);
        const fragmenting = sourceCoding?.fragmenting;
        if (!fragmenting)
            return [];
        try {
            const emptyAlternativeMatch = new RegExp(`(?:${fragmenting})|`).exec('');
            const fragmentCount = (emptyAlternativeMatch?.length || 1) - 1;
            return Array.from({ length: fragmentCount }, (_, index) => index);
        }
        catch {
            return [];
        }
    }
    getSolverVariableReference(variableName, fragmentIndex) {
        const fragmentSuffix = typeof fragmentIndex === 'number' ?
            `[${fragmentIndex}]` :
            '';
        return `${this.solverVariablePrefix}{${variableName}${fragmentSuffix}}`;
    }
    setSolverTestError(translationKey) {
        this.solverTestResult = {
            type: 'error',
            message: this.tr(translationKey)
        };
    }
    tr(translationKey) {
        return this.translateService.instant(translationKey);
    }
    // eslint-disable-next-line class-methods-use-this
    isValidVariableIdentifier(value) {
        return isValidVariableIdentifier(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: EditSourceParametersDialog, deps: [{ token: MAT_DIALOG_DATA }, { token: SchemerService }, { token: i1.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: EditSourceParametersDialog, isStandalone: true, selector: "ng-component", ngImport: i0, template: "<h1 mat-dialog-title>{{ (newVariableMode ? 'varList.add' : 'derive-processing.prompt') | translate }}</h1>\n\n<mat-dialog-content>\n  <div class=\"fx-column-start-stretch\">\n    <mat-form-field>\n      <mat-label>Name</mat-label>\n      <input matInput id=\"variableId\" name=\"variableId\" required\n        [readonly]=\"data.sourceType === 'BASE'\"\n        [(ngModel)]=\"data.selfAlias\">\n      @if (data.selfAlias && !isValidVariableIdentifier(data.selfAlias)) {\n        <mat-hint>\n          Erlaubt sind ASCII-Buchstaben, Ziffern, _ und - (mindestens ein Zeichen).\n        </mat-hint>\n      }\n    </mat-form-field>\n\n    @if (data.sourceType !== 'BASE') {\n      <mat-form-field>\n        <mat-select  placeholder=\"Quell-Variablen\" [formControl]=\"selectedSources\" multiple\n          (selectionChange)=\"updateDeriveSources()\" (closed)=\"updateDeriveSources()\">\n          <button (click)=\"toggleAllSelection()\" style=\"margin: 10px\" mat-stroked-button>Alle ausw\u00E4hlen</button>\n          <mat-select-trigger>\n            Quell-Variablen\n            @if (selectedSources.value) {\n              <span class=\"example-additional-selection\">\n                ({{selectedSources.value.length}})\n              </span>\n            }\n          </mat-select-trigger>\n          @for (source of possibleNewSources | keyvalue: compareFn; track source) {\n            <mat-option [value]=\"source.key\">{{source.value}}</mat-option>\n          }\n        </mat-select>\n      </mat-form-field>\n      <mat-form-field>\n        <mat-label>{{ 'derive-method.prompt' | translate }}</mat-label>\n        <mat-select required [(value)]=\"data.sourceType\" (selectionChange)=\"updatePossibleDeriveProcessing()\">\n          @for (st of sourceTypeList; track st) {\n            <mat-option [value]=\"st\">\n              {{ 'derive-method.' + st | translate }}\n            </mat-option>\n          }\n        </mat-select>\n      </mat-form-field>\n    }\n\n    @if (possibleDeriveProcessing.length > 0) {\n      @for (p of possibleDeriveProcessing; track p) {\n        <mat-checkbox [checked]=\"data.sourceParameters.processing?.includes(p)\"\n          (change)=\"alterProcessing(p, $event.checked)\">\n          {{ 'derive-processing.' + p | translate }}\n        </mat-checkbox>\n      }\n    }\n    @if (data.sourceType === 'SOLVER') {\n      <mat-form-field class=\"solver-expression-field\">\n        <mat-label>{{ 'derive-processing.SOLVER_EXPRESSION' | translate }}</mat-label>\n        <input #solverExpressionInput matInput [(ngModel)]=\"data.sourceParameters.solverExpression\"\n          (ngModelChange)=\"clearSolverTestResult()\">\n        <button mat-icon-button matSuffix type=\"button\"\n          [matMenuTriggerFor]=\"solverSourceMenu\"\n          [disabled]=\"selectedSolverSources.length < 1\"\n          [attr.aria-label]=\"'derive-processing.solver-insert-source.label' | translate\"\n          [matTooltip]=\"'derive-processing.solver-insert-source.label' | translate\">\n          <mat-icon>data_object</mat-icon>\n        </button>\n      </mat-form-field>\n\n      <mat-menu #solverSourceMenu=\"matMenu\">\n        @for (source of solverSourceReferences; track getSolverSourceReference(source)) {\n          <button class=\"solver-source-menu__item\"\n            mat-menu-item\n            type=\"button\"\n            (click)=\"insertSolverSourceReference(source, solverExpressionInput)\">\n            <mat-icon>input</mat-icon>\n            <span>\n              {{ source.label }}\n              @if (source.fragmentIndex !== undefined) {\n                [{{ source.fragmentIndex }}]\n              }\n            </span>\n            <code class=\"solver-source-menu__reference\">\n              {{ getSolverSourceReference(source) }}\n            </code>\n          </button>\n        }\n      </mat-menu>\n\n      @if (solverSourceWarning; as warning) {\n        <div class=\"solver-source-warning\" role=\"alert\">\n          <mat-icon aria-hidden=\"true\">warning</mat-icon>\n          <span>{{ warning }}</span>\n        </div>\n      }\n\n      <section class=\"solver-test-area\">\n        <div class=\"solver-test-header\">\n          <div class=\"solver-test-title\">{{ 'derive-processing.solver-test.title' | translate }}</div>\n          <button mat-stroked-button color=\"primary\" type=\"button\"\n            [disabled]=\"data.deriveSources.length < 1\"\n            (click)=\"runSolverTest()\">\n            <mat-icon>calculate</mat-icon>\n            {{ 'derive-processing.solver-test.action' | translate }}\n          </button>\n        </div>\n\n        @if (selectedSolverSources.length > 0) {\n          <div class=\"solver-test-values\">\n            @for (source of selectedSolverSources; track source.id) {\n              <mat-form-field>\n                <mat-label>{{ source.label }}</mat-label>\n                <input matInput [(ngModel)]=\"solverTestValues[source.id]\"\n                  (ngModelChange)=\"clearSolverTestResult()\">\n              </mat-form-field>\n            }\n          </div>\n        } @else {\n          <div class=\"solver-test-hint\">\n            {{ 'derive-processing.solver-test.no-sources' | translate }}\n          </div>\n        }\n\n        @if (solverTestResult) {\n          <div class=\"solver-test-result\"\n            [class.solver-test-result-ok]=\"solverTestResult.type === 'success'\"\n            [class.solver-test-result-incomplete]=\"solverTestResult.type === 'incomplete'\"\n            [class.solver-test-result-error]=\"solverTestResult.type === 'error'\">\n            {{ solverTestResult.message }}\n          </div>\n        }\n      </section>\n\n      <div class=\"solver-expression-help\" role=\"note\" aria-labelledby=\"solver-expression-help-title\">\n        <div class=\"solver-expression-help__header\">\n          <mat-icon class=\"solver-expression-help__icon\" aria-hidden=\"true\">info</mat-icon>\n          <span id=\"solver-expression-help-title\">\n            {{ 'derive-processing.solver-help.title' | translate }}\n          </span>\n        </div>\n        <p>{{ 'derive-processing.solver-help.description' | translate }}</p>\n        <p>\n          <code>{{ solverPolicySyntax }}</code>\n          -\n          {{ 'derive-processing.solver-help.policy-description' | translate }}\n        </p>\n        <div>{{ 'derive-processing.solver-help.examples-title' | translate }}</div>\n        <ul>\n          @for (example of solverExpressionExamples; track example.expression) {\n            <li>\n              <code>{{ example.expression }}</code>\n              -\n              {{ example.descriptionKey | translate }}\n            </li>\n          }\n        </ul>\n        <a class=\"solver-expression-help__link\"\n          [href]=\"solverExpressionDocsUrl\"\n          target=\"_blank\"\n          rel=\"noopener noreferrer\">\n          {{ 'derive-processing.solver-help.docs-link' | translate }}\n          <mat-icon aria-hidden=\"true\">open_in_new</mat-icon>\n        </a>\n      </div>\n    }\n  </div>\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-raised-button color=\"primary\"\n    [disabled]=\"!isValidVariableIdentifier(data.selfAlias) || !data.sourceType || (data.sourceType !== 'BASE' && data.deriveSources.length < 1)\"\n  [mat-dialog-close]=\"data\">{{ 'dialog-save' | translate }}</button>\n  <button mat-raised-button [mat-dialog-close]=\"false\">{{ 'dialog-cancel' | translate }}</button>\n</mat-dialog-actions>\n", styles: [".solver-expression-field{width:100%}.solver-expression-help{background:#f5f7ff;border-left:4px solid #3f51b5;border-radius:4px;color:#000000d1;margin:-8px 0 8px;max-width:640px;padding:12px 14px}.solver-expression-help__header{align-items:center;display:flex;gap:8px;font-weight:500}.solver-expression-help__icon{color:#3f51b5;font-size:20px;height:20px;width:20px}.solver-expression-help p{margin:8px 0}.solver-expression-help ul{margin:6px 0 10px;padding-left:20px}.solver-expression-help li{margin-bottom:4px}.solver-expression-help code{background:#0000000f;border-radius:3px;overflow-wrap:anywhere;padding:1px 4px;white-space:normal}.solver-expression-help__link{align-items:center;display:inline-flex;gap:4px}.solver-expression-help__link mat-icon{font-size:16px;height:16px;width:16px}.solver-source-menu__item{justify-content:flex-start}.solver-source-menu__reference{color:#0009;font-size:12px;margin-left:8px}.solver-source-warning{align-items:flex-start;background:#fff8e1;border-left:4px solid #ff8f00;border-radius:4px;color:#5f3f00;display:flex;gap:8px;margin:-8px 0 12px;max-width:640px;padding:10px 14px}.solver-source-warning mat-icon{color:#f57c00;flex:0 0 auto;font-size:20px;height:20px;width:20px}\n", ".solver-test-area{border-top:1px solid rgba(0,0,0,.12);margin-top:8px;padding-top:16px}.solver-test-header{align-items:center;display:flex;gap:16px;justify-content:space-between;margin-bottom:12px}.solver-test-title{font-weight:600}.solver-test-values{display:grid;gap:8px 12px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}.solver-test-result{border-radius:4px;margin-top:8px;padding:8px 12px}.solver-test-result-ok{background:#e8f5e9;color:#1b5e20}.solver-test-result-incomplete{background:#fff8e1;color:#5f3f00}.solver-test-result-error{background:#ffebee;color:#b71c1c}.solver-test-hint{color:#0009;margin-bottom:8px}\n"], dependencies: [{ kind: "directive", type: MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "component", type: MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: MatOption$1, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: EditSourceParametersDialog, decorators: [{
            type: Component,
            args: [{ standalone: true, imports: [
                        MatSelectTrigger,
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton,
                        MatIconButton,
                        MatDialogClose,
                        TranslateModule,
                        FormsModule,
                        MatFormField,
                        MatHint,
                        MatInput,
                        MatCheckbox,
                        MatLabel,
                        MatSelect,
                        MatOption$1,
                        MatSuffix,
                        MatMenu,
                        MatMenuItem,
                        MatMenuTrigger,
                        MatTooltip,
                        KeyValuePipe,
                        ReactiveFormsModule,
                        MatIcon
                    ], template: "<h1 mat-dialog-title>{{ (newVariableMode ? 'varList.add' : 'derive-processing.prompt') | translate }}</h1>\n\n<mat-dialog-content>\n  <div class=\"fx-column-start-stretch\">\n    <mat-form-field>\n      <mat-label>Name</mat-label>\n      <input matInput id=\"variableId\" name=\"variableId\" required\n        [readonly]=\"data.sourceType === 'BASE'\"\n        [(ngModel)]=\"data.selfAlias\">\n      @if (data.selfAlias && !isValidVariableIdentifier(data.selfAlias)) {\n        <mat-hint>\n          Erlaubt sind ASCII-Buchstaben, Ziffern, _ und - (mindestens ein Zeichen).\n        </mat-hint>\n      }\n    </mat-form-field>\n\n    @if (data.sourceType !== 'BASE') {\n      <mat-form-field>\n        <mat-select  placeholder=\"Quell-Variablen\" [formControl]=\"selectedSources\" multiple\n          (selectionChange)=\"updateDeriveSources()\" (closed)=\"updateDeriveSources()\">\n          <button (click)=\"toggleAllSelection()\" style=\"margin: 10px\" mat-stroked-button>Alle ausw\u00E4hlen</button>\n          <mat-select-trigger>\n            Quell-Variablen\n            @if (selectedSources.value) {\n              <span class=\"example-additional-selection\">\n                ({{selectedSources.value.length}})\n              </span>\n            }\n          </mat-select-trigger>\n          @for (source of possibleNewSources | keyvalue: compareFn; track source) {\n            <mat-option [value]=\"source.key\">{{source.value}}</mat-option>\n          }\n        </mat-select>\n      </mat-form-field>\n      <mat-form-field>\n        <mat-label>{{ 'derive-method.prompt' | translate }}</mat-label>\n        <mat-select required [(value)]=\"data.sourceType\" (selectionChange)=\"updatePossibleDeriveProcessing()\">\n          @for (st of sourceTypeList; track st) {\n            <mat-option [value]=\"st\">\n              {{ 'derive-method.' + st | translate }}\n            </mat-option>\n          }\n        </mat-select>\n      </mat-form-field>\n    }\n\n    @if (possibleDeriveProcessing.length > 0) {\n      @for (p of possibleDeriveProcessing; track p) {\n        <mat-checkbox [checked]=\"data.sourceParameters.processing?.includes(p)\"\n          (change)=\"alterProcessing(p, $event.checked)\">\n          {{ 'derive-processing.' + p | translate }}\n        </mat-checkbox>\n      }\n    }\n    @if (data.sourceType === 'SOLVER') {\n      <mat-form-field class=\"solver-expression-field\">\n        <mat-label>{{ 'derive-processing.SOLVER_EXPRESSION' | translate }}</mat-label>\n        <input #solverExpressionInput matInput [(ngModel)]=\"data.sourceParameters.solverExpression\"\n          (ngModelChange)=\"clearSolverTestResult()\">\n        <button mat-icon-button matSuffix type=\"button\"\n          [matMenuTriggerFor]=\"solverSourceMenu\"\n          [disabled]=\"selectedSolverSources.length < 1\"\n          [attr.aria-label]=\"'derive-processing.solver-insert-source.label' | translate\"\n          [matTooltip]=\"'derive-processing.solver-insert-source.label' | translate\">\n          <mat-icon>data_object</mat-icon>\n        </button>\n      </mat-form-field>\n\n      <mat-menu #solverSourceMenu=\"matMenu\">\n        @for (source of solverSourceReferences; track getSolverSourceReference(source)) {\n          <button class=\"solver-source-menu__item\"\n            mat-menu-item\n            type=\"button\"\n            (click)=\"insertSolverSourceReference(source, solverExpressionInput)\">\n            <mat-icon>input</mat-icon>\n            <span>\n              {{ source.label }}\n              @if (source.fragmentIndex !== undefined) {\n                [{{ source.fragmentIndex }}]\n              }\n            </span>\n            <code class=\"solver-source-menu__reference\">\n              {{ getSolverSourceReference(source) }}\n            </code>\n          </button>\n        }\n      </mat-menu>\n\n      @if (solverSourceWarning; as warning) {\n        <div class=\"solver-source-warning\" role=\"alert\">\n          <mat-icon aria-hidden=\"true\">warning</mat-icon>\n          <span>{{ warning }}</span>\n        </div>\n      }\n\n      <section class=\"solver-test-area\">\n        <div class=\"solver-test-header\">\n          <div class=\"solver-test-title\">{{ 'derive-processing.solver-test.title' | translate }}</div>\n          <button mat-stroked-button color=\"primary\" type=\"button\"\n            [disabled]=\"data.deriveSources.length < 1\"\n            (click)=\"runSolverTest()\">\n            <mat-icon>calculate</mat-icon>\n            {{ 'derive-processing.solver-test.action' | translate }}\n          </button>\n        </div>\n\n        @if (selectedSolverSources.length > 0) {\n          <div class=\"solver-test-values\">\n            @for (source of selectedSolverSources; track source.id) {\n              <mat-form-field>\n                <mat-label>{{ source.label }}</mat-label>\n                <input matInput [(ngModel)]=\"solverTestValues[source.id]\"\n                  (ngModelChange)=\"clearSolverTestResult()\">\n              </mat-form-field>\n            }\n          </div>\n        } @else {\n          <div class=\"solver-test-hint\">\n            {{ 'derive-processing.solver-test.no-sources' | translate }}\n          </div>\n        }\n\n        @if (solverTestResult) {\n          <div class=\"solver-test-result\"\n            [class.solver-test-result-ok]=\"solverTestResult.type === 'success'\"\n            [class.solver-test-result-incomplete]=\"solverTestResult.type === 'incomplete'\"\n            [class.solver-test-result-error]=\"solverTestResult.type === 'error'\">\n            {{ solverTestResult.message }}\n          </div>\n        }\n      </section>\n\n      <div class=\"solver-expression-help\" role=\"note\" aria-labelledby=\"solver-expression-help-title\">\n        <div class=\"solver-expression-help__header\">\n          <mat-icon class=\"solver-expression-help__icon\" aria-hidden=\"true\">info</mat-icon>\n          <span id=\"solver-expression-help-title\">\n            {{ 'derive-processing.solver-help.title' | translate }}\n          </span>\n        </div>\n        <p>{{ 'derive-processing.solver-help.description' | translate }}</p>\n        <p>\n          <code>{{ solverPolicySyntax }}</code>\n          -\n          {{ 'derive-processing.solver-help.policy-description' | translate }}\n        </p>\n        <div>{{ 'derive-processing.solver-help.examples-title' | translate }}</div>\n        <ul>\n          @for (example of solverExpressionExamples; track example.expression) {\n            <li>\n              <code>{{ example.expression }}</code>\n              -\n              {{ example.descriptionKey | translate }}\n            </li>\n          }\n        </ul>\n        <a class=\"solver-expression-help__link\"\n          [href]=\"solverExpressionDocsUrl\"\n          target=\"_blank\"\n          rel=\"noopener noreferrer\">\n          {{ 'derive-processing.solver-help.docs-link' | translate }}\n          <mat-icon aria-hidden=\"true\">open_in_new</mat-icon>\n        </a>\n      </div>\n    }\n  </div>\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-raised-button color=\"primary\"\n    [disabled]=\"!isValidVariableIdentifier(data.selfAlias) || !data.sourceType || (data.sourceType !== 'BASE' && data.deriveSources.length < 1)\"\n  [mat-dialog-close]=\"data\">{{ 'dialog-save' | translate }}</button>\n  <button mat-raised-button [mat-dialog-close]=\"false\">{{ 'dialog-cancel' | translate }}</button>\n</mat-dialog-actions>\n", styles: [".solver-expression-field{width:100%}.solver-expression-help{background:#f5f7ff;border-left:4px solid #3f51b5;border-radius:4px;color:#000000d1;margin:-8px 0 8px;max-width:640px;padding:12px 14px}.solver-expression-help__header{align-items:center;display:flex;gap:8px;font-weight:500}.solver-expression-help__icon{color:#3f51b5;font-size:20px;height:20px;width:20px}.solver-expression-help p{margin:8px 0}.solver-expression-help ul{margin:6px 0 10px;padding-left:20px}.solver-expression-help li{margin-bottom:4px}.solver-expression-help code{background:#0000000f;border-radius:3px;overflow-wrap:anywhere;padding:1px 4px;white-space:normal}.solver-expression-help__link{align-items:center;display:inline-flex;gap:4px}.solver-expression-help__link mat-icon{font-size:16px;height:16px;width:16px}.solver-source-menu__item{justify-content:flex-start}.solver-source-menu__reference{color:#0009;font-size:12px;margin-left:8px}.solver-source-warning{align-items:flex-start;background:#fff8e1;border-left:4px solid #ff8f00;border-radius:4px;color:#5f3f00;display:flex;gap:8px;margin:-8px 0 12px;max-width:640px;padding:10px 14px}.solver-source-warning mat-icon{color:#f57c00;flex:0 0 auto;font-size:20px;height:20px;width:20px}\n", ".solver-test-area{border-top:1px solid rgba(0,0,0,.12);margin-top:8px;padding-top:16px}.solver-test-header{align-items:center;display:flex;gap:16px;justify-content:space-between;margin-bottom:12px}.solver-test-title{font-weight:600}.solver-test-values{display:grid;gap:8px 12px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}.solver-test-result{border-radius:4px;margin-top:8px;padding:8px 12px}.solver-test-result-ok{background:#e8f5e9;color:#1b5e20}.solver-test-result-incomplete{background:#fff8e1;color:#5f3f00}.solver-test-result-error{background:#ffebee;color:#b71c1c}.solver-test-hint{color:#0009;margin-bottom:8px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: SchemerService }, { type: i1.TranslateService }] });

const copyVariableIdentifiers = (variable, origin, sourceIndex) => ({
    id: variable.id,
    ...(Object.prototype.hasOwnProperty.call(variable, 'alias') ?
        { alias: variable.alias } :
        {}),
    origin,
    sourceIndex
});
const isEmptyVariableCoding = (coding) => {
    if (coding.label && coding.label !== coding.id)
        return false;
    if ((coding.processing && coding.processing.length > 0) ||
        coding.fragmenting ||
        (coding.codes && coding.codes.length > 0))
        return false;
    return !((coding.manualInstruction && coding.manualInstruction.length > 0) ||
        coding.codeModel !== 'MANUAL_AND_RULES');
};
const getSchemerIdentifiersForValidation = (varList = [], variableCodings = []) => {
    const representedBaseIds = new Set(varList.map(variable => variable.id));
    const matchedBaseIds = new Set();
    const canRemoveOrphanBaseCodings = varList.length > 0;
    return [
        ...varList.map((variable, sourceIndex) => copyVariableIdentifiers(variable, 'VAR_LIST', sourceIndex)),
        ...variableCodings
            .map((coding, sourceIndex) => ({ coding, sourceIndex }))
            .filter(({ coding }) => {
            const isBaseCoding = coding.sourceType === 'BASE' ||
                coding.sourceType === 'BASE_NO_VALUE';
            if (canRemoveOrphanBaseCodings &&
                coding.sourceType === 'BASE' &&
                !representedBaseIds.has(coding.id) &&
                isEmptyVariableCoding(coding))
                return false;
            if (!isBaseCoding || !representedBaseIds.has(coding.id))
                return true;
            if (matchedBaseIds.has(coding.id))
                return true;
            matchedBaseIds.add(coding.id);
            return false;
        })
            .map(({ coding, sourceIndex }) => copyVariableIdentifiers(coding, coding.sourceType === 'BASE' || coding.sourceType === 'BASE_NO_VALUE' ?
            'BASE_CODING' :
            'DERIVED_CODING', sourceIndex))
    ];
};
const isInvalidVarListName = (value) => !isValidVariableIdentifier(value);
const isInvalidVarListId = (value) => !isValidVariableIdentifier(value);
const isInvalidVarListAlias = isInvalidVarListId;
const isInvalidIdentifierError = (error) => (error.code === 'EMPTY_IDENTIFIER' || error.code === 'INVALID_CHARACTERS');
const analyzeVariableIdentifiers = (varList = [], variableCodings = []) => {
    const identifiers = getSchemerIdentifiersForValidation(varList, variableCodings);
    const signature = JSON.stringify(identifiers.map(variable => ({
        id: variable.id,
        alias: variable.alias,
        hasAlias: Object.prototype.hasOwnProperty.call(variable, 'alias'),
        origin: variable.origin,
        sourceIndex: variable.sourceIndex
    })));
    const errors = validateVariableList(identifiers);
    const duplicateIds = new Set(errors
        .filter(error => error.code === 'DUPLICATE_ID')
        .map(error => String(error.value).toUpperCase()));
    const duplicateAliases = new Set(errors
        .filter(error => error.code === 'DUPLICATE_ALIAS')
        .map(error => String(error.value).toUpperCase()));
    const invalidIdCount = errors.filter(error => (error.property === 'id' && isInvalidIdentifierError(error))).length;
    const invalidAliasCount = errors.filter(error => (error.property === 'alias' && isInvalidIdentifierError(error))).length;
    const hasDuplicateId = duplicateIds.size > 0;
    const hasDuplicateAlias = duplicateAliases.size > 0;
    const hasInvalid = errors.some(isInvalidIdentifierError);
    return {
        identifiers,
        signature,
        errors,
        duplicateIds,
        duplicateAliases,
        duplicateIdValues: Array.from(duplicateIds.values()).sort(),
        duplicateAliasValues: Array.from(duplicateAliases.values()).sort(),
        invalidIdCount,
        invalidAliasCount,
        hasDuplicateId,
        hasDuplicateAlias,
        hasInvalid,
        hasProblems: errors.length > 0
    };
};
const validateVariableCodingChange = (varList, variableCodings, change) => {
    const replacedIndex = change.replacedCodingId === undefined ?
        -1 :
        variableCodings.findIndex(coding => coding.id === change.replacedCodingId);
    const changedVariableCodings = replacedIndex < 0 ?
        [...variableCodings, change.coding] :
        variableCodings.map((coding, index) => (index === replacedIndex ? change.coding : coding));
    return analyzeVariableIdentifiers(varList, changedVariableCodings);
};

class VarCodingComponent {
    set varCoding(value) {
        this._varCoding = value;
        this.applySolverResidualAutoInstructionDefault();
        this.updateHasResidualAutoCode();
        this.updateHasIntendedIncompleteAutoCode();
    }
    get varCoding() {
        return this._varCoding;
    }
    static hasManualInstructionContent(html) {
        const template = document.createElement('template');
        template.innerHTML = html;
        return Boolean(template.content.textContent?.replace(/[\s\u200B-\u200D\uFEFF]/g, '') ||
            template.content.querySelector('img, .iqb-math-formula, math'));
    }
    constructor(schemerService, sanitizer, translateService, editTextDialog, showCodingDialog, confirmDialog, generateCodingDialog, messageDialog, editSourceParametersDialog) {
        this.schemerService = schemerService;
        this.sanitizer = sanitizer;
        this.translateService = translateService;
        this.editTextDialog = editTextDialog;
        this.showCodingDialog = showCodingDialog;
        this.confirmDialog = confirmDialog;
        this.generateCodingDialog = generateCodingDialog;
        this.messageDialog = messageDialog;
        this.editSourceParametersDialog = editSourceParametersDialog;
        this.varCodingChanged = new EventEmitter();
        this._varCoding = null;
        this.lastChangeFrom$ = new BehaviorSubject('init');
        this.lastChangeFromSubscription = null;
        this.hasResidualAutoCode = false;
        this.hasIntendedIncompleteAutoCode = false;
    }
    ngOnInit() {
        this.lastChangeFromSubscription = this.lastChangeFrom$
            .pipe(debounceTime(500))
            .subscribe(source => {
            if (source !== 'init') {
                this.updateHasResidualAutoCode();
                this.updateHasIntendedIncompleteAutoCode();
                this.varCodingChanged.emit(this.varCoding);
            }
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    ngOnChanges(changes) {
        this.updateVarInfo();
    }
    updateVarInfo() {
        this.varInfo = this.varCoding ?
            this.schemerService.getVarInfoByCoding(this.varCoding) :
            undefined;
    }
    updateHasResidualAutoCode() {
        this.hasResidualAutoCode = this.varCoding ?
            !!(this.varCoding.codes || []).find(c => c.type === 'RESIDUAL_AUTO') :
            false;
    }
    updateHasIntendedIncompleteAutoCode() {
        this.hasIntendedIncompleteAutoCode = this.varCoding ?
            !!(this.varCoding.codes || []).find(c => c.type === 'INTENDED_INCOMPLETE') :
            false;
    }
    applySolverResidualAutoInstructionDefault() {
        if (this.varCoding?.sourceType === 'SOLVER') {
            (this.varCoding.codes || []).forEach(ensureResidualAutoManualInstruction);
        }
    }
    getSanitizedText(text) {
        return this.sanitizer.bypassSecurityTrustHtml(renderManualInstructionMath(text));
    }
    editTextDialog_manualInstruction() {
        if (this.varCoding) {
            const dialogRef = this.editTextDialog.open(RichTextEditDialogComponent, {
                width: '1100px',
                data: {
                    title: this.translateService.instant('manual-instruction.coding.prompt-edit'),
                    content: this.varCoding.manualInstruction || '',
                    defaultFontSize: 20,
                    editorHeightPx: 400
                },
                autoFocus: false
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (typeof dialogResult !== 'undefined') {
                    if (dialogResult !== false && this.varCoding) {
                        this.varCoding.manualInstruction = dialogResult;
                        this.varCodingChanged.emit(this.varCoding);
                    }
                }
            });
        }
    }
    wipeInstructions() {
        if (this.varCoding) {
            this.varCoding.manualInstruction = '';
            this.varCodingChanged.emit(this.varCoding);
        }
    }
    codingAsText() {
        if (this.varCoding) {
            const deriveSourcesAliases = (this.varCoding.deriveSources || []).map(ds => this.schemerService.getVariableAliasById(ds));
            const dialogRef = this.showCodingDialog.open(ShowCodingDialogComponent, {
                width: '1000px',
                data: {
                    varCoding: { ...this.varCoding, deriveSources: deriveSourcesAliases },
                    mode: this.schemerService.codingToTextMode
                }
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (typeof dialogResult === 'string') {
                    this.schemerService.setCodingToTextMode(dialogResult);
                }
            });
        }
    }
    deactivateBaseVar() {
        if (this.schemerService.codingScheme) {
            if (this.schemerService.codingScheme.variableCodings.filter(c => c.sourceType === 'BASE').length > 1) {
                const dialogRef = this.confirmDialog.open(ConfirmDialogComponent, {
                    width: '400px',
                    data: {
                        title: `Deaktiviere Variable '${this.varCoding?.alias || this.varCoding?.id}'`,
                        content: 'Es werden die vorhandenen Kodierungen entfernt und die Basisvariable deaktiviert.',
                        confirmButtonLabel: 'Deaktivieren',
                        showCancel: true
                    }
                });
                dialogRef.afterClosed().subscribe(result => {
                    if (result !== false && this.schemerService.codingScheme) {
                        if (this.varCoding && this.varCoding.sourceType === 'BASE') {
                            this.schemerService.codingScheme.variableCodings =
                                this.schemerService.codingScheme.variableCodings.filter(c => c.id !== this.varCoding?.id);
                            const noValueVarCoding = CodingFactory.createBaseCodingVariable(this.varCoding.id, 'BASE_NO_VALUE');
                            this.schemerService.codingScheme.variableCodings.push(noValueVarCoding);
                            this.varCodingChanged.emit(noValueVarCoding);
                            this.varCoding = null;
                        }
                    }
                });
            }
        }
    }
    smartSchemer(event) {
        if (this.varCoding) {
            if (event.ctrlKey) {
                if (this.schemerService.codingScheme && this.varCoding) {
                    (this.varCoding?.codes || []).forEach(c => {
                        if (!c.type || c.type === 'UNSET') {
                            if (/teilw/i.exec(c.label || '')) {
                                c.label = '';
                                c.type = 'PARTIAL_CREDIT';
                            }
                            else if (/richtig/i.exec(c.label || '')) {
                                c.label = '';
                                c.type = 'FULL_CREDIT';
                            }
                            else if (/falsch/i.exec(c.label || '')) {
                                c.label = '';
                                c.type = 'NO_CREDIT';
                            }
                        }
                    });
                    this.schemerService.sortCodes(this.varCoding?.codes || [], true);
                    this.varCodingChanged.emit(this.varCoding);
                }
            }
            else {
                const dialogRef = this.generateCodingDialog.open(GenerateCodingDialogComponent, {
                    width: '1000px',
                    data: this.varInfo
                });
                dialogRef.afterClosed().subscribe(dialogResult => {
                    if (typeof dialogResult !== 'undefined' &&
                        dialogResult !== false &&
                        dialogResult !== null &&
                        this.varCoding) {
                        const newCoding = dialogResult;
                        Object.assign(this.varCoding, {
                            processing: newCoding.processing,
                            fragmenting: newCoding.fragmenting,
                            manualInstruction: VarCodingComponent.hasManualInstructionContent(this.varCoding.manualInstruction || '') ? this.varCoding.manualInstruction :
                                newCoding.manualInstruction || '',
                            codeModel: newCoding.codeModel,
                            codes: newCoding.codes
                        });
                        this.applySolverResidualAutoInstructionDefault();
                        this.updateHasResidualAutoCode();
                        this.updateHasIntendedIncompleteAutoCode();
                        this.varCodingChanged.emit(this.varCoding);
                    }
                });
            }
        }
    }
    addCode(codeType) {
        if (this.varCoding && this.varCoding.codes) {
            const addResult = this.schemerService.addCode(this.varCoding.codes, codeType);
            if (typeof addResult === 'string') {
                this.messageDialog.open(MessageDialogComponent, {
                    width: '400px',
                    data: {
                        title: this.translateService.instant('code.prompt.add'),
                        content: this.translateService.instant(addResult),
                        type: MessageType.error
                    }
                });
            }
            else {
                this.applySolverResidualAutoInstructionDefault();
                this.updateHasResidualAutoCode();
                this.updateHasIntendedIncompleteAutoCode();
                this.varCodingChanged.emit(this.varCoding);
            }
        }
    }
    canPasteSingleCode() {
        if (!this.varCoding || !this.varCoding.codes) {
            return false;
        }
        return this.schemerService.canPasteSingleCodeInto(this.varCoding.codes);
    }
    pasteSingleCode() {
        if (!this.varCoding || !this.varCoding.codes) {
            return;
        }
        const warningKeys = this.schemerService.getPasteSingleCodeWarningKeys(this.varCoding, this.varInfo);
        if (warningKeys.length > 0) {
            const warningContent = [
                this.translateService.instant('code.paste-warning.content'),
                ...warningKeys.map(key => this.translateService.instant(key))
            ].join(' ');
            const dialogRef = this.confirmDialog.open(ConfirmDialogComponent, {
                width: '500px',
                data: {
                    title: this.translateService.instant('code.paste-warning.title'),
                    content: warningContent,
                    confirmButtonLabel: this.translateService.instant('code.paste-warning.confirm'),
                    showCancel: true
                }
            });
            dialogRef.afterClosed().subscribe(result => {
                if (result === true)
                    this.performPasteSingleCode();
            });
            return;
        }
        this.performPasteSingleCode();
    }
    performPasteSingleCode() {
        if (!this.varCoding || !this.varCoding.codes) {
            return;
        }
        const problemsBeforePaste = this.schemerService.getCodingProblemsForVarCoding(this.varCoding);
        const pasteResult = this.schemerService.pasteSingleCode(this.varCoding.codes);
        if (typeof pasteResult === 'string') {
            this.messageDialog.open(MessageDialogComponent, {
                width: '400px',
                data: {
                    title: this.translateService.instant('code.prompt.add'),
                    content: this.translateService.instant(pasteResult),
                    type: MessageType.error
                }
            });
        }
        else {
            this.applySolverResidualAutoInstructionDefault();
            this.updateHasResidualAutoCode();
            this.updateHasIntendedIncompleteAutoCode();
            this.varCodingChanged.emit(this.varCoding);
            const newProblems = VarCodingComponent.getNewCodingProblems(problemsBeforePaste, this.schemerService.getCodingProblemsForVarCoding(this.varCoding));
            if (newProblems.length > 0)
                this.showPasteValidationWarning(newProblems);
        }
    }
    static getNewCodingProblems(beforeProblems, afterProblems) {
        const beforeProblemKeys = new Set(beforeProblems.map(problem => (VarCodingComponent.getCodingProblemKey(problem))));
        return afterProblems.filter(problem => (!beforeProblemKeys.has(VarCodingComponent.getCodingProblemKey(problem))));
    }
    static getCodingProblemKey(problem) {
        return [
            problem.variableId,
            problem.type,
            problem.breaking ? 'breaking' : 'warning',
            problem.code || ''
        ].join('|');
    }
    showPasteValidationWarning(problems) {
        const problemDescriptions = Array.from(new Set(problems.map(problem => this.translateService.instant(`coding-problem.${problem.type}`))));
        this.messageDialog.open(MessageDialogComponent, {
            width: '500px',
            data: {
                title: this.translateService.instant('code.post-paste-validation.title'),
                content: [
                    this.translateService.instant('code.post-paste-validation.content'),
                    ...problemDescriptions
                ].join(' '),
                type: problems.some(problem => problem.breaking) ?
                    MessageType.error :
                    MessageType.warning
            }
        });
    }
    editSourceParameters() {
        if (this.schemerService.userRole !== 'RO' && this.varCoding) {
            const dialogRef = this.editSourceParametersDialog.open(EditSourceParametersDialog, {
                width: '600px',
                minHeight: '400px',
                data: {
                    selfId: this.varCoding.id,
                    selfAlias: this.varCoding.alias || this.varCoding.id,
                    sourceType: this.varCoding.sourceType,
                    sourceParameters: this.varCoding.sourceParameters,
                    deriveSources: this.varCoding.deriveSources
                }
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (typeof dialogResult !== 'undefined' &&
                    dialogResult !== false &&
                    this.varCoding) {
                    const { selfAlias, sourceType, sourceParameters, deriveSources } = dialogResult;
                    const prospectiveCoding = {
                        ...this.varCoding,
                        alias: selfAlias,
                        sourceType,
                        sourceParameters,
                        deriveSources
                    };
                    const hasCodingScheme = !!this.schemerService.codingScheme;
                    const variableCodings = this.schemerService.codingScheme?.variableCodings ||
                        [this.varCoding];
                    const identifierAnalysis = validateVariableCodingChange(hasCodingScheme ? this.schemerService.varList : [], variableCodings, {
                        coding: prospectiveCoding,
                        replacedCodingId: this.varCoding.id
                    });
                    if (identifierAnalysis.hasProblems) {
                        this.messageDialog.open(MessageDialogComponent, {
                            width: '400px',
                            data: {
                                title: this.translateService.instant('schemer.rename.error.title'),
                                content: this.translateService.instant('data-error.variable-id.double'),
                                type: MessageType.error
                            }
                        });
                        return;
                    }
                    Object.assign(this.varCoding, {
                        alias: selfAlias,
                        sourceType,
                        sourceParameters,
                        deriveSources
                    });
                    this.applySolverResidualAutoInstructionDefault();
                    this.varCodingChanged.emit(this.varCoding);
                }
            });
        }
    }
    ngOnDestroy() {
        if (this.lastChangeFromSubscription !== null)
            this.lastChangeFromSubscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: VarCodingComponent, deps: [{ token: SchemerService }, { token: i1$1.DomSanitizer }, { token: i1.TranslateService }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: VarCodingComponent, isStandalone: true, selector: "var-coding", inputs: { varCoding: "varCoding" }, outputs: { varCodingChanged: "varCodingChanged" }, usesOnChanges: true, ngImport: i0, template: "@if (!varCoding) {\n<div class=\"fx-flex-fill\">&nbsp;</div>\n} @if (varCoding) {\n<div class=\"fx-column-space-between-stretch\" [style.padding]=\"'10px'\">\n  <div class=\"editor-header fx-row-start-stretch fx-gap-10\">\n    <div class=\"variable-details fx-column-start-stretch fx-gap-10\">\n      <mat-form-field>\n        <mat-label>{{ \"description-position\" | translate }}</mat-label>\n        <input\n          matInput\n          [(ngModel)]=\"varCoding.label\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n          (change)=\"lastChangeFrom$.next('label')\"\n        />\n      </mat-form-field>\n      <mat-form-field>\n        <mat-label>{{ \"page\" | translate }}</mat-label>\n        <input\n          matInput\n          [(ngModel)]=\"varCoding.page\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n          (change)=\"lastChangeFrom$.next('page')\"\n          [matTooltip]=\"'page.tooltip' | translate\"\n        />\n      </mat-form-field>\n      <div class=\"fx-row-start-stretch fx-gap-10\">\n        <div class=\"fx-flex-fill fx-column-start-start\">\n          <button\n            mat-button\n            [matTooltip]=\"'derive-processing.prompt' | translate\"\n            [disabled]=\"schemerService.userRole === 'RO'\"\n            (click)=\"editSourceParameters()\"\n          >\n            <mat-icon>edit</mat-icon>\n            {{ \"derive-processing.prompt\" | translate }}\n          </button>\n          <div style=\"margin-left: 35px; margin-bottom: 10px\">\n            @if (varCoding.sourceType !== 'BASE' && varCoding.sourceType !==\n            'BASE_NO_VALUE') {\n            <div>\n              {{ \"derive-method.label\" | translate }}:\n              {{ \"derive-method.\" + varCoding.sourceType | translate }}\n            </div>\n            @if (varCoding.sourceParameters &&\n            varCoding.sourceParameters.solverExpression && varCoding.sourceType\n            === 'SOLVER') {\n            <div>\n              {{ \"derive-processing.SOLVER_EXPRESSION\" | translate }}:\n              {{ varCoding.sourceParameters.solverExpression }}\n            </div>\n            } @if (varCoding.deriveSources && varCoding.deriveSources.length ===\n            0) {\n            <div class=\"no-sources\">\n              {{ \"derive-sources.error\" | translate }}\n            </div>\n            } @else {\n            <div>\n              {{ \"derive-sources.label\" | translate }}:\n              {{ varCoding.deriveSources || [] | varAlias : 10 }}\n            </div>\n            } }\n          </div>\n          <div style=\"margin-left: 35px; margin-bottom: 10px\">\n            @for (p of (varCoding.sourceParameters?.processing || []); track p)\n            {\n            <div class=\"fx-row-start-start\" style=\"font-size: small\">\n              <mat-icon style=\"font-size: small\">check</mat-icon>\n              <div>{{ \"derive-processing.\" + p | translate }}</div>\n            </div>\n            }\n          </div>\n        </div>\n      </div>\n    </div>\n    <mat-card class=\"manual-instruction\" [style.padding-left.px]=\"12\">\n      <mat-card-subtitle class=\"hover-area\">\n        <div class=\"fx-row-space-between-center\">\n          <div class=\"fx-row-start-center\">\n            <div [style.color]=\"'grey'\" [style.font-size]=\"'smaller'\">\n              {{ \"manual-instruction.coding.title\" | translate }}\n            </div>\n            <button\n              mat-icon-button\n              [matTooltip]=\"'manual-instruction.coding.prompt-edit' | translate\"\n              [disabled]=\"schemerService.userRole === 'RO'\"\n              (click)=\"editTextDialog_manualInstruction()\"\n            >\n              <mat-icon>edit</mat-icon>\n            </button>\n          </div>\n          <button\n            mat-icon-button\n            (click)=\"wipeInstructions()\"\n            class=\"wipe-button\"\n            [matTooltip]=\"'manual-instruction.coding.wipe' | translate\"\n            [matTooltipShowDelay]=\"500\"\n          >\n            <mat-icon>close</mat-icon>\n          </button>\n        </div>\n      </mat-card-subtitle>\n      <mat-card-content class=\"instructions\">\n        <div\n          [innerHTML]=\"\n            varCoding && varCoding.manualInstruction\n              ? getSanitizedText(varCoding.manualInstruction)\n              : null\n          \"\n        ></div>\n      </mat-card-content>\n    </mat-card>\n  </div>\n  <div class=\"coding-toolbar fx-row-space-between-center\">\n    <div class=\"coding-actions fx-row-start-start fx-gap-5\">\n      @if (!schemerService.codingScheme) {\n      <button\n        mat-icon-button\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matMenuTriggerFor]=\"menuAddCode\"\n        [matTooltip]=\"'code.prompt.add' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n      <mat-menu #menuAddCode>\n        @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n        <button mat-menu-item (click)=\"addCode(codeType)\">\n          @if (codeType === 'FULL_CREDIT') {\n          <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n          } @else if (codeType === 'PARTIAL_CREDIT') {\n          <mat-icon style=\"color: green\">check</mat-icon>\n          } @else if (codeType === 'NO_CREDIT') {\n          <mat-icon style=\"color: gold\">remove_done</mat-icon>\n          } @else if (codeType === 'UNSET') {\n          <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n          } @else if (codeType === 'TO_CHECK') {\n          <mat-icon style=\"color: blue\"\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n            >\n              <path\n                d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n              /></svg\n          ></mat-icon>\n          } @else if (codeType === 'RESIDUAL') {\n          <mat-icon>close</mat-icon>\n          } @else if (codeType === 'RESIDUAL_AUTO') {\n          <mat-icon style=\"color: orangered\">close</mat-icon>\n          } @else {\n          <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n          }\n          {{ \"code.prompt.add-\" + codeType | translate }}\n        </button>\n        @if (codeType === 'UNSET') {\n        <mat-divider></mat-divider>\n        } }\n      </mat-menu>\n      }\n      <button\n        mat-icon-button\n        (click)=\"smartSchemer($event)\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matTooltip]=\"'click.smart-schemer' | translate\"\n      >\n        <mat-icon\n          ><svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\n            <path\n              d=\"M7.5,5.6L5,7L6.4,4.5L5,2L7.5,3.4L10,2L8.6,4.5L10,7L7.5,5.6M19.5,15.4L22,14L20.6,16.5L22,19L19.5,17.6L17,19L18.4,16.5L17,14L19.5,15.4M22,2L20.6,4.5L22,7L19.5,5.6L17,7L18.4,4.5L17,2L19.5,3.4L22,2M13.34,12.78L15.78,10.34L13.66,8.22L11.22,10.66L13.34,12.78M14.37,7.29L16.71,9.63C17.1,10 17.1,10.65 16.71,11.04L5.04,22.71C4.65,23.1 4,23.1 3.63,22.71L1.29,20.37C0.9,20 0.9,19.35 1.29,18.96L12.96,7.29C13.35,6.9 14,6.9 14.37,7.29Z\"\n            /></svg\n        ></mat-icon>\n      </button>\n      <mat-button-toggle-group\n        [(value)]=\"varCoding.codeModel\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        hideSingleSelectionIndicator=\"true\"\n      >\n        <mat-button-toggle\n          [value]=\"'MANUAL_AND_RULES'\"\n          [matTooltip]=\"'code-model.MANUAL_AND_RULES' | translate\"\n          ><mat-icon>vertical_split</mat-icon></mat-button-toggle\n        >\n        <mat-button-toggle\n          [value]=\"'RULES_ONLY'\"\n          [matTooltip]=\"'code-model.RULES_ONLY' | translate\"\n          ><mat-icon>reorder</mat-icon></mat-button-toggle\n        >\n        <mat-button-toggle\n          [value]=\"'MANUAL_ONLY'\"\n          [matTooltip]=\"'code-model.MANUAL_ONLY' | translate\"\n        >\n          <mat-icon\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n              fill=\"#5f6368\"\n            >\n              <path\n                d=\"M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Z\"\n              /></svg\n          ></mat-icon>\n        </mat-button-toggle>\n      </mat-button-toggle-group>\n      <button\n        mat-icon-button\n        (click)=\"codingAsText()\"\n        [matTooltip]=\"'click.coding-as-text' | translate\"\n      >\n        <mat-icon>description</mat-icon>\n      </button>\n      <button\n        mat-icon-button\n        (click)=\"deactivateBaseVar()\"\n        [disabled]=\"\n          schemerService.userRole === 'RO' ||\n          schemerService.getBaseVarsList().length === 1 ||\n          varCoding.sourceType !== 'BASE'\n        \"\n        [matTooltip]=\"'click.deactivate-base-var' | translate\"\n      >\n        <mat-icon>cancel</mat-icon>\n      </button>\n    </div>\n    <div class=\"add-code-toolbar fx-row-start-center fx-gap-10\">\n      @if (schemerService.userRole !== 'RO') {\n      <div>{{ \"code.prompt.add\" | translate }}</div>\n      <div class=\"add-code-actions\">\n        @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n        <button\n          mat-icon-button\n          (click)=\"addCode(codeType)\"\n          [matTooltip]=\"'code.prompt.add-' + codeType | translate\"\n        >\n          @if (codeType === 'FULL_CREDIT') {\n          <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n          } @else if (codeType === 'PARTIAL_CREDIT') {\n          <mat-icon style=\"color: green\">check</mat-icon>\n          } @else if (codeType === 'NO_CREDIT') {\n          <mat-icon style=\"color: gold\">remove_done</mat-icon>\n          } @else if (codeType === 'UNSET') {\n          <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n          } @else if (codeType === 'TO_CHECK') {\n          <mat-icon style=\"color: blue\"\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n            >\n              <path\n                d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n              /></svg\n          ></mat-icon>\n          } @else if (codeType === 'INTENDED_INCOMPLETE') {\n          <mat-icon style=\"color: darkgrey\">disabled_by_default</mat-icon>\n          } @else if (codeType === 'RESIDUAL') {\n          <mat-icon>close</mat-icon>\n          } @else if (codeType === 'RESIDUAL_AUTO') {\n          <mat-icon style=\"color: orangered\">close</mat-icon>\n          } @else {\n          <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n          }\n        </button>\n        }\n      </div>\n      }\n    </div>\n  </div>\n  <codes-title\n    [codeList]=\"varCoding.codes\"\n    [fragmenting]=\"varCoding.fragmenting\"\n    [processing]=\"varCoding.processing\"\n    [canPaste]=\"canPasteSingleCode()\"\n    (pasteRequested)=\"pasteSingleCode()\"\n    (codeListChanged)=\"varCodingChanged.emit(varCoding)\"\n    (processingChanged)=\"lastChangeFrom$.next('var-codes-full processing')\"\n    (fragmentingChanged)=\"\n      varCoding.fragmenting = $event;\n      lastChangeFrom$.next('var-codes-full fragmenting')\n    \"\n  ></codes-title>\n  @if (varCoding.codes) { @for (code of varCoding.codes; track code; let\n  codeIndex = $index) {\n  <single-code\n    (codeDataChanged)=\"lastChangeFrom$.next('single-code codes')\"\n    [varInfo]=\"varInfo\"\n    [fragmentMode]=\"!!varCoding.fragmenting\"\n    [codeModel]=\"varCoding.codeModel\"\n    [sourceType]=\"varCoding.sourceType\"\n    [hasResidualAutoCode]=\"hasResidualAutoCode\"\n    [hasIntendedIncompleteAutoCode]=\"hasIntendedIncompleteAutoCode\"\n    [code]=\"code\"\n    [codeIndex]=\"codeIndex\"\n    [allCodes]=\"varCoding.codes\"\n  ></single-code>\n  } @if (varCoding.codes.length === 0) {\n  <div class=\"no-codes\">{{ \"code.no-codes\" | translate }}</div>\n  } }\n</div>\n}\n", styles: [":host{display:block;container:var-coding/inline-size}.variable-details{flex:0 0 30%;min-width:0}.manual-instruction{flex:1 1 0;min-width:0}.coding-toolbar,.coding-actions,.add-code-toolbar,.add-code-actions{display:flex;flex-wrap:wrap;gap:5px}@container var-coding (max-width: 650px){.editor-header{flex-direction:column}.variable-details{flex-basis:auto}}.element-host{width:100%;padding:10px}.sources{width:100%}.no-sources{color:red}.source-ok{background-color:#c4e6e882}.source-missing{background-color:#ff330054}.instructions{max-height:200px;overflow-x:auto;overflow-y:scroll}.no-codes{font-style:italic}.mat-mdc-card-subtitle{margin:0 4px}:host ::ng-deep .mat-mdc-form-field-subscript-wrapper{display:none}.var-codes-container{margin:10px}.hover-area .wipe-button{visibility:hidden}.hover-area:hover .wipe-button{visibility:visible}mat-chip-listbox{margin-top:10px}mat-menu button{margin-left:20px}\n"], dependencies: [{ kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }, { kind: "directive", type: MatCardContent, selector: "mat-card-content" }, { kind: "ngmodule", type: TranslateModule }, { kind: "directive", type: MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: CodesTitleComponent, selector: "codes-title", inputs: ["codeList", "fragmenting", "processing", "canPaste"], outputs: ["processingChanged", "fragmentingChanged", "codeListChanged", "pasteRequested"] }, { kind: "component", type: SingleCodeComponent, selector: "single-code", inputs: ["code", "allCodes", "varInfo", "fragmentMode", "codeIndex", "codeModel", "sourceType", "hasResidualAutoCode", "hasIntendedIncompleteAutoCode"], outputs: ["codeDataChanged"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: VariableAliasPipe, name: "varAlias" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: VarCodingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'var-coding', standalone: true, imports: [
                        MatFormField,
                        MatLabel,
                        MatInput,
                        ReactiveFormsModule,
                        FormsModule,
                        MatMenuTrigger,
                        MatIcon,
                        MatIconButton,
                        MatMenu,
                        MatMenuItem,
                        MatTooltipModule,
                        MatCard,
                        MatCardSubtitle,
                        MatCardContent,
                        TranslateModule,
                        MatButtonToggleGroup,
                        MatButtonToggle,
                        MatDivider,
                        CodesTitleComponent,
                        SingleCodeComponent,
                        VariableAliasPipe,
                        MatButton
                    ], template: "@if (!varCoding) {\n<div class=\"fx-flex-fill\">&nbsp;</div>\n} @if (varCoding) {\n<div class=\"fx-column-space-between-stretch\" [style.padding]=\"'10px'\">\n  <div class=\"editor-header fx-row-start-stretch fx-gap-10\">\n    <div class=\"variable-details fx-column-start-stretch fx-gap-10\">\n      <mat-form-field>\n        <mat-label>{{ \"description-position\" | translate }}</mat-label>\n        <input\n          matInput\n          [(ngModel)]=\"varCoding.label\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n          (change)=\"lastChangeFrom$.next('label')\"\n        />\n      </mat-form-field>\n      <mat-form-field>\n        <mat-label>{{ \"page\" | translate }}</mat-label>\n        <input\n          matInput\n          [(ngModel)]=\"varCoding.page\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n          (change)=\"lastChangeFrom$.next('page')\"\n          [matTooltip]=\"'page.tooltip' | translate\"\n        />\n      </mat-form-field>\n      <div class=\"fx-row-start-stretch fx-gap-10\">\n        <div class=\"fx-flex-fill fx-column-start-start\">\n          <button\n            mat-button\n            [matTooltip]=\"'derive-processing.prompt' | translate\"\n            [disabled]=\"schemerService.userRole === 'RO'\"\n            (click)=\"editSourceParameters()\"\n          >\n            <mat-icon>edit</mat-icon>\n            {{ \"derive-processing.prompt\" | translate }}\n          </button>\n          <div style=\"margin-left: 35px; margin-bottom: 10px\">\n            @if (varCoding.sourceType !== 'BASE' && varCoding.sourceType !==\n            'BASE_NO_VALUE') {\n            <div>\n              {{ \"derive-method.label\" | translate }}:\n              {{ \"derive-method.\" + varCoding.sourceType | translate }}\n            </div>\n            @if (varCoding.sourceParameters &&\n            varCoding.sourceParameters.solverExpression && varCoding.sourceType\n            === 'SOLVER') {\n            <div>\n              {{ \"derive-processing.SOLVER_EXPRESSION\" | translate }}:\n              {{ varCoding.sourceParameters.solverExpression }}\n            </div>\n            } @if (varCoding.deriveSources && varCoding.deriveSources.length ===\n            0) {\n            <div class=\"no-sources\">\n              {{ \"derive-sources.error\" | translate }}\n            </div>\n            } @else {\n            <div>\n              {{ \"derive-sources.label\" | translate }}:\n              {{ varCoding.deriveSources || [] | varAlias : 10 }}\n            </div>\n            } }\n          </div>\n          <div style=\"margin-left: 35px; margin-bottom: 10px\">\n            @for (p of (varCoding.sourceParameters?.processing || []); track p)\n            {\n            <div class=\"fx-row-start-start\" style=\"font-size: small\">\n              <mat-icon style=\"font-size: small\">check</mat-icon>\n              <div>{{ \"derive-processing.\" + p | translate }}</div>\n            </div>\n            }\n          </div>\n        </div>\n      </div>\n    </div>\n    <mat-card class=\"manual-instruction\" [style.padding-left.px]=\"12\">\n      <mat-card-subtitle class=\"hover-area\">\n        <div class=\"fx-row-space-between-center\">\n          <div class=\"fx-row-start-center\">\n            <div [style.color]=\"'grey'\" [style.font-size]=\"'smaller'\">\n              {{ \"manual-instruction.coding.title\" | translate }}\n            </div>\n            <button\n              mat-icon-button\n              [matTooltip]=\"'manual-instruction.coding.prompt-edit' | translate\"\n              [disabled]=\"schemerService.userRole === 'RO'\"\n              (click)=\"editTextDialog_manualInstruction()\"\n            >\n              <mat-icon>edit</mat-icon>\n            </button>\n          </div>\n          <button\n            mat-icon-button\n            (click)=\"wipeInstructions()\"\n            class=\"wipe-button\"\n            [matTooltip]=\"'manual-instruction.coding.wipe' | translate\"\n            [matTooltipShowDelay]=\"500\"\n          >\n            <mat-icon>close</mat-icon>\n          </button>\n        </div>\n      </mat-card-subtitle>\n      <mat-card-content class=\"instructions\">\n        <div\n          [innerHTML]=\"\n            varCoding && varCoding.manualInstruction\n              ? getSanitizedText(varCoding.manualInstruction)\n              : null\n          \"\n        ></div>\n      </mat-card-content>\n    </mat-card>\n  </div>\n  <div class=\"coding-toolbar fx-row-space-between-center\">\n    <div class=\"coding-actions fx-row-start-start fx-gap-5\">\n      @if (!schemerService.codingScheme) {\n      <button\n        mat-icon-button\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matMenuTriggerFor]=\"menuAddCode\"\n        [matTooltip]=\"'code.prompt.add' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n      <mat-menu #menuAddCode>\n        @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n        <button mat-menu-item (click)=\"addCode(codeType)\">\n          @if (codeType === 'FULL_CREDIT') {\n          <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n          } @else if (codeType === 'PARTIAL_CREDIT') {\n          <mat-icon style=\"color: green\">check</mat-icon>\n          } @else if (codeType === 'NO_CREDIT') {\n          <mat-icon style=\"color: gold\">remove_done</mat-icon>\n          } @else if (codeType === 'UNSET') {\n          <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n          } @else if (codeType === 'TO_CHECK') {\n          <mat-icon style=\"color: blue\"\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n            >\n              <path\n                d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n              /></svg\n          ></mat-icon>\n          } @else if (codeType === 'RESIDUAL') {\n          <mat-icon>close</mat-icon>\n          } @else if (codeType === 'RESIDUAL_AUTO') {\n          <mat-icon style=\"color: orangered\">close</mat-icon>\n          } @else {\n          <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n          }\n          {{ \"code.prompt.add-\" + codeType | translate }}\n        </button>\n        @if (codeType === 'UNSET') {\n        <mat-divider></mat-divider>\n        } }\n      </mat-menu>\n      }\n      <button\n        mat-icon-button\n        (click)=\"smartSchemer($event)\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matTooltip]=\"'click.smart-schemer' | translate\"\n      >\n        <mat-icon\n          ><svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\n            <path\n              d=\"M7.5,5.6L5,7L6.4,4.5L5,2L7.5,3.4L10,2L8.6,4.5L10,7L7.5,5.6M19.5,15.4L22,14L20.6,16.5L22,19L19.5,17.6L17,19L18.4,16.5L17,14L19.5,15.4M22,2L20.6,4.5L22,7L19.5,5.6L17,7L18.4,4.5L17,2L19.5,3.4L22,2M13.34,12.78L15.78,10.34L13.66,8.22L11.22,10.66L13.34,12.78M14.37,7.29L16.71,9.63C17.1,10 17.1,10.65 16.71,11.04L5.04,22.71C4.65,23.1 4,23.1 3.63,22.71L1.29,20.37C0.9,20 0.9,19.35 1.29,18.96L12.96,7.29C13.35,6.9 14,6.9 14.37,7.29Z\"\n            /></svg\n        ></mat-icon>\n      </button>\n      <mat-button-toggle-group\n        [(value)]=\"varCoding.codeModel\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        hideSingleSelectionIndicator=\"true\"\n      >\n        <mat-button-toggle\n          [value]=\"'MANUAL_AND_RULES'\"\n          [matTooltip]=\"'code-model.MANUAL_AND_RULES' | translate\"\n          ><mat-icon>vertical_split</mat-icon></mat-button-toggle\n        >\n        <mat-button-toggle\n          [value]=\"'RULES_ONLY'\"\n          [matTooltip]=\"'code-model.RULES_ONLY' | translate\"\n          ><mat-icon>reorder</mat-icon></mat-button-toggle\n        >\n        <mat-button-toggle\n          [value]=\"'MANUAL_ONLY'\"\n          [matTooltip]=\"'code-model.MANUAL_ONLY' | translate\"\n        >\n          <mat-icon\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n              fill=\"#5f6368\"\n            >\n              <path\n                d=\"M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Z\"\n              /></svg\n          ></mat-icon>\n        </mat-button-toggle>\n      </mat-button-toggle-group>\n      <button\n        mat-icon-button\n        (click)=\"codingAsText()\"\n        [matTooltip]=\"'click.coding-as-text' | translate\"\n      >\n        <mat-icon>description</mat-icon>\n      </button>\n      <button\n        mat-icon-button\n        (click)=\"deactivateBaseVar()\"\n        [disabled]=\"\n          schemerService.userRole === 'RO' ||\n          schemerService.getBaseVarsList().length === 1 ||\n          varCoding.sourceType !== 'BASE'\n        \"\n        [matTooltip]=\"'click.deactivate-base-var' | translate\"\n      >\n        <mat-icon>cancel</mat-icon>\n      </button>\n    </div>\n    <div class=\"add-code-toolbar fx-row-start-center fx-gap-10\">\n      @if (schemerService.userRole !== 'RO') {\n      <div>{{ \"code.prompt.add\" | translate }}</div>\n      <div class=\"add-code-actions\">\n        @for (codeType of schemerService.orderOfCodeTypes; track codeType) {\n        <button\n          mat-icon-button\n          (click)=\"addCode(codeType)\"\n          [matTooltip]=\"'code.prompt.add-' + codeType | translate\"\n        >\n          @if (codeType === 'FULL_CREDIT') {\n          <mat-icon style=\"color: limegreen\">done_all</mat-icon>\n          } @else if (codeType === 'PARTIAL_CREDIT') {\n          <mat-icon style=\"color: green\">check</mat-icon>\n          } @else if (codeType === 'NO_CREDIT') {\n          <mat-icon style=\"color: gold\">remove_done</mat-icon>\n          } @else if (codeType === 'UNSET') {\n          <mat-icon style=\"color: lightgrey\">check_box_outline_blank</mat-icon>\n          } @else if (codeType === 'TO_CHECK') {\n          <mat-icon style=\"color: blue\"\n            ><svg\n              xmlns=\"http://www.w3.org/2000/svg\"\n              height=\"24px\"\n              viewBox=\"0 -960 960 960\"\n              width=\"24px\"\n            >\n              <path\n                d=\"M424-320q0-81 14.5-116.5T500-514q41-36 62.5-62.5T584-637q0-41-27.5-68T480-732q-51 0-77.5 31T365-638l-103-44q21-64 77-111t141-47q105 0 161.5 58.5T698-641q0 50-21.5 85.5T609-475q-49 47-59.5 71.5T539-320H424Zm56 240q-33 0-56.5-23.5T400-160q0-33 23.5-56.5T480-240q33 0 56.5 23.5T560-160q0 33-23.5 56.5T480-80Z\"\n              /></svg\n          ></mat-icon>\n          } @else if (codeType === 'INTENDED_INCOMPLETE') {\n          <mat-icon style=\"color: darkgrey\">disabled_by_default</mat-icon>\n          } @else if (codeType === 'RESIDUAL') {\n          <mat-icon>close</mat-icon>\n          } @else if (codeType === 'RESIDUAL_AUTO') {\n          <mat-icon style=\"color: orangered\">close</mat-icon>\n          } @else {\n          <div>{{ \"code type \" + codeType + \" unknown\" }}</div>\n          }\n        </button>\n        }\n      </div>\n      }\n    </div>\n  </div>\n  <codes-title\n    [codeList]=\"varCoding.codes\"\n    [fragmenting]=\"varCoding.fragmenting\"\n    [processing]=\"varCoding.processing\"\n    [canPaste]=\"canPasteSingleCode()\"\n    (pasteRequested)=\"pasteSingleCode()\"\n    (codeListChanged)=\"varCodingChanged.emit(varCoding)\"\n    (processingChanged)=\"lastChangeFrom$.next('var-codes-full processing')\"\n    (fragmentingChanged)=\"\n      varCoding.fragmenting = $event;\n      lastChangeFrom$.next('var-codes-full fragmenting')\n    \"\n  ></codes-title>\n  @if (varCoding.codes) { @for (code of varCoding.codes; track code; let\n  codeIndex = $index) {\n  <single-code\n    (codeDataChanged)=\"lastChangeFrom$.next('single-code codes')\"\n    [varInfo]=\"varInfo\"\n    [fragmentMode]=\"!!varCoding.fragmenting\"\n    [codeModel]=\"varCoding.codeModel\"\n    [sourceType]=\"varCoding.sourceType\"\n    [hasResidualAutoCode]=\"hasResidualAutoCode\"\n    [hasIntendedIncompleteAutoCode]=\"hasIntendedIncompleteAutoCode\"\n    [code]=\"code\"\n    [codeIndex]=\"codeIndex\"\n    [allCodes]=\"varCoding.codes\"\n  ></single-code>\n  } @if (varCoding.codes.length === 0) {\n  <div class=\"no-codes\">{{ \"code.no-codes\" | translate }}</div>\n  } }\n</div>\n}\n", styles: [":host{display:block;container:var-coding/inline-size}.variable-details{flex:0 0 30%;min-width:0}.manual-instruction{flex:1 1 0;min-width:0}.coding-toolbar,.coding-actions,.add-code-toolbar,.add-code-actions{display:flex;flex-wrap:wrap;gap:5px}@container var-coding (max-width: 650px){.editor-header{flex-direction:column}.variable-details{flex-basis:auto}}.element-host{width:100%;padding:10px}.sources{width:100%}.no-sources{color:red}.source-ok{background-color:#c4e6e882}.source-missing{background-color:#ff330054}.instructions{max-height:200px;overflow-x:auto;overflow-y:scroll}.no-codes{font-style:italic}.mat-mdc-card-subtitle{margin:0 4px}:host ::ng-deep .mat-mdc-form-field-subscript-wrapper{display:none}.var-codes-container{margin:10px}.hover-area .wipe-button{visibility:hidden}.hover-area:hover .wipe-button{visibility:visible}mat-chip-listbox{margin-top:10px}mat-menu button{margin-left:20px}\n"] }]
        }], ctorParameters: () => [{ type: SchemerService }, { type: i1$1.DomSanitizer }, { type: i1.TranslateService }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }], propDecorators: { varCodingChanged: [{
                type: Output
            }], varCoding: [{
                type: Input
            }] } });

class CodingSchemeDialogComponent {
    constructor(dialogRef, clipboard, snackBar, translate, data) {
        this.dialogRef = dialogRef;
        this.clipboard = clipboard;
        this.snackBar = snackBar;
        this.translate = translate;
        this.data = data;
        // JSON.stringify mit Einrückung für eine lesbare Darstellung
        this.jsonData = JSON.stringify(data.codingScheme, null, 2);
    }
    onCopy() {
        this.clipboard.copy(this.jsonData);
        this.translate.get('copied-to-clipboard').subscribe((translatedMessage) => {
            this.snackBar.open(translatedMessage, '', {
                duration: 1000
            });
        });
    }
    onClose() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodingSchemeDialogComponent, deps: [{ token: i4.MatDialogRef }, { token: i2.Clipboard }, { token: i3$3.MatSnackBar }, { token: i1.TranslateService }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.24", type: CodingSchemeDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <mat-dialog-content>
      <div class="fx-row-space-between-end">
        <h2>Kodierschema</h2>
        <button mat-icon-button (click)="onCopy()" class="copy-button">
          <mat-icon>content_copy</mat-icon>
        </button>
        </div>
        <pre>{{ jsonData }}</pre>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" (click)="onClose()">{{ 'dialog-close' | translate }}</button>
    </mat-dialog-actions>
  `, isInline: true, styles: ["pre{background:#f4f4f4;padding:16px;border-radius:4px;overflow:auto;max-height:400px;font-size:14px}.copy-button{margin-bottom:8px}.copy-button:hover{border-color:#888}.copy-button:active{background-color:#e0e0e0;border-color:#888}\n"], dependencies: [{ kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: CodingSchemeDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <mat-dialog-content>
      <div class="fx-row-space-between-end">
        <h2>Kodierschema</h2>
        <button mat-icon-button (click)="onCopy()" class="copy-button">
          <mat-icon>content_copy</mat-icon>
        </button>
        </div>
        <pre>{{ jsonData }}</pre>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" (click)="onClose()">{{ 'dialog-close' | translate }}</button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogContent,
                        MatDialogActions,
                        TranslateModule,
                        MatButton,
                        MatIcon,
                        MatIconButton
                    ], styles: ["pre{background:#f4f4f4;padding:16px;border-radius:4px;overflow:auto;max-height:400px;font-size:14px}.copy-button{margin-bottom:8px}.copy-button:hover{border-color:#888}.copy-button:active{background-color:#e0e0e0;border-color:#888}\n"] }]
        }], ctorParameters: () => [{ type: i4.MatDialogRef }, { type: i2.Clipboard }, { type: i3$3.MatSnackBar }, { type: i1.TranslateService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ShowCodingProblemsDialogComponent {
    constructor(codingProblems) {
        this.codingProblems = codingProblems;
        this.codingProblemsGrouped = {};
        const allVariables = [];
        codingProblems.forEach(p => {
            if (allVariables.indexOf(p.variableId) < 0)
                allVariables.push(p.variableId);
        });
        this.allVariables = allVariables.sort();
        allVariables.forEach(v => {
            this.codingProblemsGrouped[v] = codingProblems.filter(p => p.variableId === v);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingProblemsDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ShowCodingProblemsDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>Kodierschema prüfen</h1>

    <mat-dialog-content>
      @for (v of allVariables; track v) {
        <div class="fx-column-start-stretch">
          <div class="var-header">{{v}}</div>
          @for (p of codingProblemsGrouped[v]; track p) {
            <div class="fx-row-start-center code-row">
              <div [class]="(p.breaking ? 'problem-error' : 'problem-warning') + ' fx-flex-row-5'"
                   [style.text-align]="'center'">&nbsp;</div>
              <div class="fx-flex-fill">{{'coding-problem.' + p.type | translate}}</div>
              @if (p.code) {
                <div class="fx-flex-row-10" [style.text-align]="'center'">Code: {{p.code}}</div>
              }
            </div>
          }
        </div>
      }
      @if (allVariables.length === 0) {
        <div>keine Probleme gefunden.</div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">{{'dialog-close' | translate}}</button>
    </mat-dialog-actions>
    `, isInline: true, styles: [".code-row:nth-child(2n){background-color:#f1f1f1}\n", ".code-row{margin-left:12px}\n", ".var-header{margin-top:12px;margin-bottom:3px;font-size:larger;color:#00008b}\n", ".problem-warning{background-color:#fc0;margin-right:5px}\n", ".problem-error{background-color:#f30;margin-right:5px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowCodingProblemsDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>Kodierschema prüfen</h1>

    <mat-dialog-content>
      @for (v of allVariables; track v) {
        <div class="fx-column-start-stretch">
          <div class="var-header">{{v}}</div>
          @for (p of codingProblemsGrouped[v]; track p) {
            <div class="fx-row-start-center code-row">
              <div [class]="(p.breaking ? 'problem-error' : 'problem-warning') + ' fx-flex-row-5'"
                   [style.text-align]="'center'">&nbsp;</div>
              <div class="fx-flex-fill">{{'coding-problem.' + p.type | translate}}</div>
              @if (p.code) {
                <div class="fx-flex-row-10" [style.text-align]="'center'">Code: {{p.code}}</div>
              }
            </div>
          }
        </div>
      }
      @if (allVariables.length === 0) {
        <div>keine Probleme gefunden.</div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">{{'dialog-close' | translate}}</button>
    </mat-dialog-actions>
    `, standalone: true, imports: [MatDialogTitle, MatDialogContent, MatDialogActions, MatButton, MatDialogClose, TranslateModule], styles: [".code-row:nth-child(2n){background-color:#f1f1f1}\n", ".code-row{margin-left:12px}\n", ".var-header{margin-top:12px;margin-bottom:3px;font-size:larger;color:#00008b}\n", ".problem-warning{background-color:#fc0;margin-right:5px}\n", ".problem-error{background-color:#f30;margin-right:5px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class SelectVariableDialogComponent {
    constructor(selectData, dialogRef) {
        this.selectData = selectData;
        this.dialogRef = dialogRef;
    }
    ngOnInit() {
        if ((typeof this.selectData.title === 'undefined') || (this.selectData.title.length === 0)) {
            this.selectData.title = 'Variable wählen';
        }
        if ((typeof this.selectData.okButtonLabel === 'undefined') ||
            (this.selectData.okButtonLabel.length === 0)) {
            this.selectData.okButtonLabel = 'OK';
        }
        this.selectData.variables.sort((a, b) => {
            const compareValueA = a.alias || a.id;
            const compareValueB = b.alias || b.id;
            return compareValueA.localeCompare(compareValueB);
        });
        setTimeout(() => {
            this.setSelectedValues();
        }, 500);
    }
    getSelected() {
        return this.variablesElement?.selectedOptions?.selected?.map(o => o.value) || [];
    }
    okButtonClick() {
        const selectedOptions = this.variablesElement?.selectedOptions.selected;
        this.dialogRef.close(selectedOptions?.map(o => o.value));
    }
    setSelectedValues() {
        if (!this.variablesElement?.options || !this.selectData.selectedVariable?.alias) {
            return;
        }
        const selectedAlias = this.selectData.selectedVariable.alias;
        this.variablesElement.options.forEach(option => {
            option.selected = option.value === selectedAlias;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SelectVariableDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i4.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SelectVariableDialogComponent, isStandalone: true, selector: "ng-component", viewQueries: [{ propertyName: "variablesElement", first: true, predicate: ["variables"], descendants: true }], ngImport: i0, template: `
      <h4 mat-dialog-title>{{ selectData.title }}</h4>
      <mat-dialog-content>
        @if (selectData.variables.length === 0) {
          {{'dialog-no-variables' | translate}}
        } @else if (selectData.prompt) {
          {{selectData.prompt}}
        }
        <mat-selection-list #variables multiple="true">
          @for (v of selectData.variables; track v) {
            <mat-list-option [value]="v.alias || v.id">
              <div class="fx-row-start-start">
                @if(selectData.codingStatus){
                  @if(selectData.codingStatus[v.id] === 'OK') {
                    <div>&nbsp;&nbsp;</div>
                  } @else {
                    <div
                      [class]="(this.selectData.codingStatus[v.id] === 'WARNING' ? 'problem-warning' : 'problem-error')"
                      [style.text-align]="'center'">
                      &nbsp;
                    </div>
                  }
                }
                {{v.alias || v.id}}
              </div>
            </mat-list-option>
          }
        </mat-selection-list>
      </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary"
        [disabled]="!variables || getSelected().length === 0"
        (click)="okButtonClick()">{{ selectData.okButtonLabel }}
      </button>
      <button mat-raised-button
        [mat-dialog-close]=[]>{{'dialog-cancel' | translate}}
      </button>
    </mat-dialog-actions>
    `, isInline: true, styles: [".problem-warning{background-color:#fc0;margin-right:5px}\n", ".problem-error{background-color:#f30;margin-right:5px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SelectVariableDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
      <h4 mat-dialog-title>{{ selectData.title }}</h4>
      <mat-dialog-content>
        @if (selectData.variables.length === 0) {
          {{'dialog-no-variables' | translate}}
        } @else if (selectData.prompt) {
          {{selectData.prompt}}
        }
        <mat-selection-list #variables multiple="true">
          @for (v of selectData.variables; track v) {
            <mat-list-option [value]="v.alias || v.id">
              <div class="fx-row-start-start">
                @if(selectData.codingStatus){
                  @if(selectData.codingStatus[v.id] === 'OK') {
                    <div>&nbsp;&nbsp;</div>
                  } @else {
                    <div
                      [class]="(this.selectData.codingStatus[v.id] === 'WARNING' ? 'problem-warning' : 'problem-error')"
                      [style.text-align]="'center'">
                      &nbsp;
                    </div>
                  }
                }
                {{v.alias || v.id}}
              </div>
            </mat-list-option>
          }
        </mat-selection-list>
      </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary"
        [disabled]="!variables || getSelected().length === 0"
        (click)="okButtonClick()">{{ selectData.okButtonLabel }}
      </button>
      <button mat-raised-button
        [mat-dialog-close]=[]>{{'dialog-cancel' | translate}}
      </button>
    </mat-dialog-actions>
    `, standalone: true, imports: [MatDialogTitle,
                        MatDialogContent,
                        MatSelectionList,
                        MatListOption,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule], styles: [".problem-warning{background-color:#fc0;margin-right:5px}\n", ".problem-error{background-color:#f30;margin-right:5px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i4.MatDialogRef }], propDecorators: { variablesElement: [{
                type: ViewChild,
                args: ['variables']
            }] } });

class SimpleInputDialogComponent {
    constructor(inputData) {
        this.inputData = inputData;
        this.showCancel = true;
    }
    ngOnInit() {
        this.inputData.title = this.inputData.title?.trim() || 'Dateneingabe';
        this.inputData.saveButtonLabel = this.inputData.saveButtonLabel?.trim() || 'OK';
        this.inputData.placeholder = this.inputData.placeholder?.trim() || 'Bitte eingeben';
        this.showCancel = this.inputData.showCancel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SimpleInputDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SimpleInputDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>{{ inputData.title }}</h1>

    <mat-dialog-content>
      @if (inputData.prompt) {
        <div class="prompt">{{inputData.prompt}}</div>
      }
      <mat-form-field>
        <input matInput [placeholder]="inputData.placeholder" [(ngModel)]="inputData.value">
      </mat-form-field>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="inputData.value">
        {{ inputData.saveButtonLabel }}
      </button>
      @if (showCancel) {
        <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
      }
    </mat-dialog-actions>
    `, isInline: true, styles: [".prompt{padding-bottom:20px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SimpleInputDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>{{ inputData.title }}</h1>

    <mat-dialog-content>
      @if (inputData.prompt) {
        <div class="prompt">{{inputData.prompt}}</div>
      }
      <mat-form-field>
        <input matInput [placeholder]="inputData.placeholder" [(ngModel)]="inputData.value">
      </mat-form-field>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="inputData.value">
        {{ inputData.saveButtonLabel }}
      </button>
      @if (showCancel) {
        <button mat-raised-button [mat-dialog-close]="false">{{'dialog-cancel' | translate}}</button>
      }
    </mat-dialog-actions>
    `, standalone: true, imports: [
                        MatDialogTitle, MatDialogContent, MatFormField, MatInput, ReactiveFormsModule, FormsModule,
                        MatDialogActions, MatButton, MatDialogClose, TranslateModule
                    ], styles: [".prompt{padding-bottom:20px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ShowDependencyTreeDialogComponent {
    constructor(codingScheme) {
        this.codingScheme = codingScheme;
        this.varNodeRows = new Map([]);
        this.errorMessage = '';
        const newVarNodeRows = new Map();
        let varNodes;
        try {
            varNodes = CodingSchemeFactory.getVariableDependencyTree(codingScheme.variableCodings);
            this.errorMessage = '';
        }
        catch {
            varNodes = [];
            this.errorMessage = 'varList.derived-tree.error';
        }
        if (!this.errorMessage) {
            const maxLevel = Math.max(...varNodes.map(n => n.level));
            for (let i = maxLevel; i > 0; i--) {
                varNodes
                    .filter(n => n.level === i)
                    .forEach(n => {
                    newVarNodeRows.set(n.id, varNodes
                        .filter(sn => n.sources.includes(sn.id))
                        .map(cn => cn.id));
                });
            }
            this.varNodeRows = newVarNodeRows;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowDependencyTreeDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ShowDependencyTreeDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>{{ 'varList.derived-tree.title' | translate }}</h1>

    <mat-dialog-content>
      @if (errorMessage) {
      <div>{{ errorMessage | translate }}</div>
      } @for (vn of varNodeRows | keyvalue; track vn) {
      <div class="fx-row-start-center fx-gap-15 var-row">
        <div class="fx-column-start-start">
          @if (vn.value.length > 0) { @for (vSource of vn.value; track vSource)
          {
          <div>{{ vSource | varAlias }}</div>
          } } @else {
          <div>{{ 'varList.derived-tree.no-sources' | translate }}</div>
          }
        </div>
        @if (vn.value.length > 0) {
        <div><mat-icon>chevron_right</mat-icon></div>
        }
        <div>{{ vn.key | varAlias }}</div>
      </div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">
        {{ 'dialog-close' | translate }}
      </button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".var-row:nth-child(2n){background-color:#f1f1f1}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: VariableAliasPipe, name: "varAlias" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ShowDependencyTreeDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>{{ 'varList.derived-tree.title' | translate }}</h1>

    <mat-dialog-content>
      @if (errorMessage) {
      <div>{{ errorMessage | translate }}</div>
      } @for (vn of varNodeRows | keyvalue; track vn) {
      <div class="fx-row-start-center fx-gap-15 var-row">
        <div class="fx-column-start-start">
          @if (vn.value.length > 0) { @for (vSource of vn.value; track vSource)
          {
          <div>{{ vSource | varAlias }}</div>
          } } @else {
          <div>{{ 'varList.derived-tree.no-sources' | translate }}</div>
          }
        </div>
        @if (vn.value.length > 0) {
        <div><mat-icon>chevron_right</mat-icon></div>
        }
        <div>{{ vn.key | varAlias }}</div>
      </div>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" [mat-dialog-close]="false">
        {{ 'dialog-close' | translate }}
      </button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton,
                        MatDialogClose,
                        TranslateModule,
                        KeyValuePipe,
                        MatIcon,
                        VariableAliasPipe
                    ], styles: [".var-row:nth-child(2n){background-color:#f1f1f1}\n"] }]
        }], ctorParameters: () => [{ type: i2$1.CodingScheme, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

const parseVarListInput = (value) => {
    if (!value)
        return [];
    if (typeof value === 'string') {
        if (!value)
            return [];
        try {
            return JSON.parse(value);
        }
        catch {
            return [];
        }
    }
    return value;
};

class SchemerInfoDialogComponent {
    constructor() {
        this.majorVersion = CodingSchemeVersionMajor;
        this.minorVersion = CodingSchemeVersionMinor;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerInfoDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.24", type: SchemerInfoDialogComponent, isStandalone: true, selector: "iqb-schemer-info-dialog", ngImport: i0, template: `
    <h2 mat-dialog-title class="dialog-title">
      <mat-icon class="title-icon">info</mat-icon>
      <span>{{ 'schemer.info.title' | translate }}</span>
    </h2>
    <mat-dialog-content class="dialog-content">
      <div class="info-container">
        <p class="intro-text">{{ 'schemer.info.intro' | translate }}</p>

        <div class="feature-overview">
          <div class="feature-card">
            <mat-icon class="feature-icon">input</mat-icon>
            <div class="feature-content">
              <span class="feature-title">{{ 'schemer.info.feature-base-title' | translate }}</span>
              <span class="feature-description">{{ 'schemer.info.feature-base-desc' | translate }}</span>
            </div>
          </div>

          <div class="feature-card">
            <mat-icon class="feature-icon">account_tree</mat-icon>
            <div class="feature-content">
              <span class="feature-title">{{ 'schemer.info.feature-derived-title' | translate }}</span>
              <span class="feature-description">{{ 'schemer.info.feature-derived-desc' | translate }}</span>
            </div>
          </div>
        </div>

        <div class="version-badge">
          <mat-icon>workspace_premium</mat-icon>
          <span>{{ 'schemer.info.version-text' | translate: { major: majorVersion, minor: minorVersion } }}</span>
        </div>

        <div class="compatibility-note">
          <mat-icon>history</mat-icon>
          <div class="note-text">
            <strong>Hinweis zur Kompatibilität:</strong>
            <p>{{ 'schemer.info.compatibility-hint' | translate: { major: majorVersion, minor: minorVersion } }}</p>
          </div>
        </div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button color="primary" mat-dialog-close>{{ 'close' | translate }}</button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".dialog-title{display:flex;align-items:center;gap:12px;margin:0;padding:20px 24px;color:#1976d2;background:#f0f7ff;border-bottom:1px solid #e0eefd}.title-icon{font-size:28px;width:28px;height:28px;line-height:28px;display:flex;align-items:center;justify-content:center}.dialog-content{padding:24px!important;margin:0}.info-container{display:flex;flex-direction:column;gap:24px}.intro-text{margin:0;font-size:16px;color:#333;line-height:1.5}.feature-overview{display:grid;grid-template-columns:1fr 1fr;gap:16px}.feature-card{display:flex;align-items:center;gap:16px;padding:16px;background:#fafafa;border:1px solid #eee;border-radius:12px}.feature-icon{color:#1976d2;background:#e3f2fd;padding:10px;border-radius:10px;font-size:24px;width:24px;min-width:24px;height:24px;box-sizing:content-box;display:flex;align-items:center;justify-content:center;flex-shrink:0}.feature-content{display:flex;flex-direction:column;gap:4px}.feature-title{font-weight:600;color:#222;font-size:14px}.feature-description{color:#666;font-size:13px;line-height:1.4}.version-badge{display:flex;align-items:center;gap:12px;padding:12px 16px;background:#e8f5e9;color:#2e7d32;border-radius:12px;font-weight:500;font-size:14px}.version-badge mat-icon{color:#2e7d32;width:24px;min-width:24px;height:24px;font-size:24px;flex-shrink:0}.compatibility-note{display:flex;align-items:flex-start;gap:16px;padding:16px;background:#fff8e1;border-radius:12px;border-left:4px solid #ffb300}.compatibility-note mat-icon{color:#f57f17;width:24px;min-width:24px;height:24px;font-size:24px;flex-shrink:0;margin-top:2px}.note-text{display:flex;flex-direction:column;gap:4px}.note-text strong{font-size:14px;color:#333}.note-text p{margin:0;font-size:13px;color:#555;line-height:1.5}mat-dialog-actions{padding:12px 24px 20px!important}@media(max-width:600px){.feature-overview{grid-template-columns:1fr}}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i4.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i4.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i4.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i4.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2$2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerInfoDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iqb-schemer-info-dialog', template: `
    <h2 mat-dialog-title class="dialog-title">
      <mat-icon class="title-icon">info</mat-icon>
      <span>{{ 'schemer.info.title' | translate }}</span>
    </h2>
    <mat-dialog-content class="dialog-content">
      <div class="info-container">
        <p class="intro-text">{{ 'schemer.info.intro' | translate }}</p>

        <div class="feature-overview">
          <div class="feature-card">
            <mat-icon class="feature-icon">input</mat-icon>
            <div class="feature-content">
              <span class="feature-title">{{ 'schemer.info.feature-base-title' | translate }}</span>
              <span class="feature-description">{{ 'schemer.info.feature-base-desc' | translate }}</span>
            </div>
          </div>

          <div class="feature-card">
            <mat-icon class="feature-icon">account_tree</mat-icon>
            <div class="feature-content">
              <span class="feature-title">{{ 'schemer.info.feature-derived-title' | translate }}</span>
              <span class="feature-description">{{ 'schemer.info.feature-derived-desc' | translate }}</span>
            </div>
          </div>
        </div>

        <div class="version-badge">
          <mat-icon>workspace_premium</mat-icon>
          <span>{{ 'schemer.info.version-text' | translate: { major: majorVersion, minor: minorVersion } }}</span>
        </div>

        <div class="compatibility-note">
          <mat-icon>history</mat-icon>
          <div class="note-text">
            <strong>Hinweis zur Kompatibilität:</strong>
            <p>{{ 'schemer.info.compatibility-hint' | translate: { major: majorVersion, minor: minorVersion } }}</p>
          </div>
        </div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button color="primary" mat-dialog-close>{{ 'close' | translate }}</button>
    </mat-dialog-actions>
  `, standalone: true, imports: [MatDialogModule, MatButtonModule, MatIconModule, TranslateModule], styles: [".dialog-title{display:flex;align-items:center;gap:12px;margin:0;padding:20px 24px;color:#1976d2;background:#f0f7ff;border-bottom:1px solid #e0eefd}.title-icon{font-size:28px;width:28px;height:28px;line-height:28px;display:flex;align-items:center;justify-content:center}.dialog-content{padding:24px!important;margin:0}.info-container{display:flex;flex-direction:column;gap:24px}.intro-text{margin:0;font-size:16px;color:#333;line-height:1.5}.feature-overview{display:grid;grid-template-columns:1fr 1fr;gap:16px}.feature-card{display:flex;align-items:center;gap:16px;padding:16px;background:#fafafa;border:1px solid #eee;border-radius:12px}.feature-icon{color:#1976d2;background:#e3f2fd;padding:10px;border-radius:10px;font-size:24px;width:24px;min-width:24px;height:24px;box-sizing:content-box;display:flex;align-items:center;justify-content:center;flex-shrink:0}.feature-content{display:flex;flex-direction:column;gap:4px}.feature-title{font-weight:600;color:#222;font-size:14px}.feature-description{color:#666;font-size:13px;line-height:1.4}.version-badge{display:flex;align-items:center;gap:12px;padding:12px 16px;background:#e8f5e9;color:#2e7d32;border-radius:12px;font-weight:500;font-size:14px}.version-badge mat-icon{color:#2e7d32;width:24px;min-width:24px;height:24px;font-size:24px;flex-shrink:0}.compatibility-note{display:flex;align-items:flex-start;gap:16px;padding:16px;background:#fff8e1;border-radius:12px;border-left:4px solid #ffb300}.compatibility-note mat-icon{color:#f57f17;width:24px;min-width:24px;height:24px;font-size:24px;flex-shrink:0;margin-top:2px}.note-text{display:flex;flex-direction:column;gap:4px}.note-text strong{font-size:14px;color:#333}.note-text p{margin:0;font-size:13px;color:#555;line-height:1.5}mat-dialog-actions{padding:12px 24px 20px!important}@media(max-width:600px){.feature-overview{grid-template-columns:1fr}}\n"] }]
        }] });

const CYCLIC_DERIVATION_PROBLEM_TYPE = 'CYCLIC_DERIVATION';
const isDerivedVariable = (coding) => (coding.sourceType !== 'BASE' && coding.sourceType !== 'BASE_NO_VALUE');
const getProblemVariableId = (coding) => (coding.alias || coding.id);
const createCodingResolver = (variableCodings) => {
    const codingsById = new Map();
    const codingsByAlias = new Map();
    variableCodings.forEach(coding => {
        codingsById.set(coding.id, coding);
        if (coding.alias) {
            codingsByAlias.set(coding.alias, [
                ...(codingsByAlias.get(coding.alias) || []),
                coding
            ]);
        }
    });
    return (reference) => {
        const codingById = codingsById.get(reference);
        if (codingById)
            return codingById;
        const codingsForAlias = codingsByAlias.get(reference) || [];
        return codingsForAlias.length === 1 ? codingsForAlias[0] : undefined;
    };
};
const getCyclicDerivationProblems = (variableCodings) => {
    const resolveCoding = createCodingResolver(variableCodings);
    const visitState = new Map();
    const path = [];
    const cyclicCodingIds = new Set();
    const markCycle = (cycleStartCodingId) => {
        const cycleStartIndex = path.indexOf(cycleStartCodingId);
        if (cycleStartIndex < 0)
            return;
        path.slice(cycleStartIndex).forEach(codingId => {
            cyclicCodingIds.add(codingId);
        });
    };
    const visitCoding = (coding) => {
        const currentState = visitState.get(coding.id);
        if (currentState === 'visiting') {
            markCycle(coding.id);
            return;
        }
        if (currentState === 'visited')
            return;
        visitState.set(coding.id, 'visiting');
        path.push(coding.id);
        (coding.deriveSources || []).forEach(sourceReference => {
            const sourceCoding = resolveCoding(sourceReference);
            if (sourceCoding && isDerivedVariable(sourceCoding)) {
                visitCoding(sourceCoding);
            }
        });
        path.pop();
        visitState.set(coding.id, 'visited');
    };
    variableCodings
        .filter(isDerivedVariable)
        .forEach(visitCoding);
    return variableCodings
        .filter(coding => cyclicCodingIds.has(coding.id))
        .map(coding => ({
        type: CYCLIC_DERIVATION_PROBLEM_TYPE,
        breaking: true,
        variableId: getProblemVariableId(coding),
        variableLabel: coding.label || ''
    }));
};
const validateCodingScheme = (baseVariables, variableCodings) => [
    ...CodingSchemeFactory.validate(baseVariables, variableCodings),
    ...getCyclicDerivationProblems(variableCodings)
];

const ERROR_GROUPS = [
    {
        code: 'INVALID_CHARACTERS',
        heading: 'Ungültige Zeichen',
        reason: 'Der Bezeichner enthält nicht erlaubte Zeichen.'
    },
    {
        code: 'EMPTY_IDENTIFIER',
        heading: 'Leerer Bezeichner',
        reason: 'Der Bezeichner ist leer oder fehlt.'
    },
    {
        code: 'DUPLICATE_ID',
        heading: 'Doppelte ID',
        reason: 'Die technische ID kommt mehrfach vor.'
    },
    {
        code: 'DUPLICATE_ALIAS',
        heading: 'Doppelter Alias',
        reason: 'Der Alias kommt mehrfach vor.'
    },
    {
        code: 'PUBLIC_IDENTIFIER_COLLISION',
        heading: 'Kollision öffentlicher Bezeichner',
        reason: 'Alias und öffentliche ID bezeichnen verschiedene Variablen gleich.'
    }
];
class ResolveIdentifierConflictsDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.errorGroups = [];
        this.identifiers = data.analysis.identifiers.map(identifier => ({
            ...identifier
        }));
        this.errorGroups = ERROR_GROUPS
            .map(group => ({
            ...group,
            errors: data.analysis.errors.filter(error => error.code === group.code)
        }))
            .filter(group => group.errors.length > 0);
    }
    displayId(variableIndex) {
        const id = this.identifiers[variableIndex]?.id;
        return id === '' || id === undefined ? '(leer)' : id;
    }
    displayAlias(variableIndex) {
        const variable = this.identifiers[variableIndex];
        if (!variable || variable.alias === undefined)
            return '(nicht gesetzt)';
        return variable.alias === '' ? '(leer)' : variable.alias;
    }
    displayConflictPartner(variableIndex) {
        return `Eintrag ${variableIndex + 1} ` +
            `(${this.sourceLabel(variableIndex)}, ` +
            `ID: ${this.displayId(variableIndex)}, ` +
            `Alias: ${this.displayAlias(variableIndex)})`;
    }
    sourceLabel(variableIndex) {
        const identifier = this.identifiers[variableIndex];
        if (!identifier)
            return '(unbekannt)';
        const labels = {
            VAR_LIST: 'Variablenliste',
            BASE_CODING: 'Coding-Scheme (Basisvariable)',
            DERIVED_CODING: 'Coding-Scheme (Derived-Variable)'
        };
        return `${labels[identifier.origin]}, Eintrag ${identifier.sourceIndex + 1}`;
    }
    // eslint-disable-next-line class-methods-use-this
    propertyLabel(property) {
        return property === 'id' ? 'ID' : 'Alias';
    }
    close() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ResolveIdentifierConflictsDialogComponent, deps: [{ token: i4.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: ResolveIdentifierConflictsDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <h1 mat-dialog-title>Ungültige Variablenbezeichner</h1>

    <mat-dialog-content>
      <p>
        Die Variablenbezeichner können nicht übernommen werden. Bitte
        korrigiere die betroffenen Einträge an der jeweils angegebenen Quelle
        und lade den Schemer neu.
      </p>

      <aside class="identifier-help">
        <b>Erlaubte Bezeichner:</b>
        mindestens ein Zeichen; erlaubt sind ASCII-Buchstaben, Ziffern,
        <code>_</code> und <code>-</code>. Es gibt keine Maximallänge.
        Beispiele: <code>a</code>, <code>_03a</code>, <code>ggb-01</code>.
        Werte mit Leerzeichen, Punkt oder Umlaut sind nicht zulässig.
        <a
          href="https://iqb-berlin.github.io/tba-info/coding/data-structures/coding-scheme.html#identifizierung"
          target="_blank"
          rel="noopener noreferrer"
        >TBA-Dokumentation zu Variablenbezeichnern</a>
      </aside>

      @for (group of errorGroups; track group.code) {
        <section class="error-group">
          <h2>{{ group.heading }} ({{ group.errors.length }})</h2>
          @for (error of group.errors; track $index) {
            <div class="error-entry">
              <div><b>Eintrag {{ error.variableIndex + 1 }}</b></div>
              <div><b>Quelle:</b> {{ sourceLabel(error.variableIndex) }}</div>
              <div><b>ID:</b> {{ displayId(error.variableIndex) }}</div>
              <div><b>Alias:</b> {{ displayAlias(error.variableIndex) }}</div>
              <div><b>Betroffen:</b> {{ propertyLabel(error.property) }}</div>
              <div><b>Fehlergrund:</b> {{ group.reason }}</div>
              @if (error.conflictingVariableIndex !== undefined) {
                <div>
                  <b>Konfliktpartner:</b>
                  {{ displayConflictPartner(error.conflictingVariableIndex) }}
                </div>
              }
            </div>
          }
        </section>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" (click)="close()">
        Schließen
      </button>
    </mat-dialog-actions>
  `, isInline: true, styles: [".identifier-help{background:#f5f7ff;border-left:4px solid #3f51b5;border-radius:4px;margin:12px 0 18px;padding:12px 14px}.identifier-help a{display:block;margin-top:8px}.error-group{margin-bottom:20px}.error-group h2{font-size:16px;margin:0 0 8px}.error-entry{border:1px solid #d7d7d7;border-left:4px solid #b00020;border-radius:4px;display:grid;gap:4px;margin-bottom:8px;padding:10px 12px}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: ResolveIdentifierConflictsDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <h1 mat-dialog-title>Ungültige Variablenbezeichner</h1>

    <mat-dialog-content>
      <p>
        Die Variablenbezeichner können nicht übernommen werden. Bitte
        korrigiere die betroffenen Einträge an der jeweils angegebenen Quelle
        und lade den Schemer neu.
      </p>

      <aside class="identifier-help">
        <b>Erlaubte Bezeichner:</b>
        mindestens ein Zeichen; erlaubt sind ASCII-Buchstaben, Ziffern,
        <code>_</code> und <code>-</code>. Es gibt keine Maximallänge.
        Beispiele: <code>a</code>, <code>_03a</code>, <code>ggb-01</code>.
        Werte mit Leerzeichen, Punkt oder Umlaut sind nicht zulässig.
        <a
          href="https://iqb-berlin.github.io/tba-info/coding/data-structures/coding-scheme.html#identifizierung"
          target="_blank"
          rel="noopener noreferrer"
        >TBA-Dokumentation zu Variablenbezeichnern</a>
      </aside>

      @for (group of errorGroups; track group.code) {
        <section class="error-group">
          <h2>{{ group.heading }} ({{ group.errors.length }})</h2>
          @for (error of group.errors; track $index) {
            <div class="error-entry">
              <div><b>Eintrag {{ error.variableIndex + 1 }}</b></div>
              <div><b>Quelle:</b> {{ sourceLabel(error.variableIndex) }}</div>
              <div><b>ID:</b> {{ displayId(error.variableIndex) }}</div>
              <div><b>Alias:</b> {{ displayAlias(error.variableIndex) }}</div>
              <div><b>Betroffen:</b> {{ propertyLabel(error.property) }}</div>
              <div><b>Fehlergrund:</b> {{ group.reason }}</div>
              @if (error.conflictingVariableIndex !== undefined) {
                <div>
                  <b>Konfliktpartner:</b>
                  {{ displayConflictPartner(error.conflictingVariableIndex) }}
                </div>
              }
            </div>
          }
        </section>
      }
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-raised-button color="primary" (click)="close()">
        Schließen
      </button>
    </mat-dialog-actions>
  `, standalone: true, imports: [
                        MatDialogTitle,
                        MatDialogContent,
                        MatDialogActions,
                        MatButton
                    ], styles: [".identifier-help{background:#f5f7ff;border-left:4px solid #3f51b5;border-radius:4px;margin:12px 0 18px;padding:12px 14px}.identifier-help a{display:block;margin-top:8px}.error-group{margin-bottom:20px}.error-group h2{font-size:16px;margin:0 0 8px}.error-entry{border:1px solid #d7d7d7;border-left:4px solid #b00020;border-radius:4px;display:grid;gap:4px;margin-bottom:8px;padding:10px 12px}\n"] }]
        }], ctorParameters: () => [{ type: i4.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class SchemerFacadeService {
    constructor(schemerService, dialog) {
        this.schemerService = schemerService;
        this.dialog = dialog;
        this.resolvingIdentifierConflicts = false;
        this.dismissedIdentifierConflictSignature = null;
        this.identifierConflictResolutionGeneration = 0;
        this.identifierConflictDialogRef = null;
    }
    setVarList(value) {
        this.schemerService.setVarList(value);
    }
    resetIdentifierConflictResolutionState() {
        this.identifierConflictResolutionGeneration += 1;
        this.resolvingIdentifierConflicts = false;
        this.dismissedIdentifierConflictSignature = null;
        const dialogRef = this.identifierConflictDialogRef;
        this.identifierConflictDialogRef = null;
        dialogRef?.close?.();
    }
    tryResolveIdentifierConflicts() {
        const analysis = analyzeVariableIdentifiers(this.schemerService.varList, this.schemerService.codingScheme?.variableCodings || []);
        if (!analysis.hasProblems) {
            if (this.resolvingIdentifierConflicts ||
                this.identifierConflictDialogRef) {
                this.resetIdentifierConflictResolutionState();
            }
            else {
                this.dismissedIdentifierConflictSignature = null;
            }
            return false;
        }
        if (this.resolvingIdentifierConflicts) {
            return true;
        }
        if (this.dismissedIdentifierConflictSignature === analysis.signature) {
            return true;
        }
        this.resolvingIdentifierConflicts = true;
        const generation = this.identifierConflictResolutionGeneration;
        const dialogRef = this.dialog.open(ResolveIdentifierConflictsDialogComponent, {
            width: '850px',
            disableClose: true,
            data: {
                analysis
            }
        });
        this.identifierConflictDialogRef = dialogRef;
        dialogRef.afterClosed().subscribe(() => {
            if (generation !== this.identifierConflictResolutionGeneration)
                return;
            this.identifierConflictDialogRef = null;
            this.resolvingIdentifierConflicts = false;
            const currentAnalysis = analyzeVariableIdentifiers(this.schemerService.varList, this.schemerService.codingScheme?.variableCodings || []);
            this.dismissedIdentifierConflictSignature =
                currentAnalysis.hasProblems &&
                    currentAnalysis.signature === analysis.signature ?
                    analysis.signature :
                    null;
        });
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerFacadeService, deps: [{ token: SchemerService }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerFacadeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerFacadeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: SchemerService }, { type: i4.MatDialog }] });

class SchemerComponent {
    set varCodingElement(value) {
        this.varCodingChangedSubscription?.unsubscribe();
        this.varCodingChangedSubscription = null;
        if (!value)
            return;
        this.varCodingChangedSubscription = value.varCodingChanged
            .pipe(debounceTime(300))
            .subscribe(() => {
            this.updateVariableLists();
            if (!this.hasIdentifierConflict) {
                this.codingSchemeChanged.emit(this.schemerService.codingScheme);
            }
        });
    }
    set codingScheme(value) {
        this.schemerService.setCodingScheme(value);
        this.updateVariableLists();
    }
    get codingScheme() {
        return this.schemerService.codingScheme;
    }
    set userRole(value) {
        this.schemerService.setUserRole(value);
    }
    set varList(value) {
        this.schemerService.setVarList([]);
        if (value) {
            this.schemerService.setVarList(parseVarListInput(value));
            this.updateVariableLists();
        }
    }
    get varList() {
        return this.schemerService.varList;
    }
    constructor(translateService, schemerService, schemerFacade, messageDialog, showCodingProblemsDialog, showCodingSchemeDialog, selectVariableDialog, editSourceParametersDialog, inputDialog) {
        this.translateService = translateService;
        this.schemerService = schemerService;
        this.schemerFacade = schemerFacade;
        this.messageDialog = messageDialog;
        this.showCodingProblemsDialog = showCodingProblemsDialog;
        this.showCodingSchemeDialog = showCodingSchemeDialog;
        this.selectVariableDialog = selectVariableDialog;
        this.editSourceParametersDialog = editSourceParametersDialog;
        this.inputDialog = inputDialog;
        this.codingSchemeChanged = new EventEmitter();
        this.basicVariables = [];
        this.derivedVariables = [];
        this.codingStatus = {};
        this.selectedCoding$ = new BehaviorSubject(null);
        this.problems = [];
        this.hasIdentifierConflict = false;
        this.varCodingChangedSubscription = null;
    }
    tr(key, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    params) {
        return this.translateService.instant(key, params);
    }
    showSchemerInfo() {
        this.messageDialog.open(SchemerInfoDialogComponent, {
            width: '650px'
        });
    }
    updateVariableLists() {
        const previousSelectedId = this.selectedCoding$.value?.id;
        if (this.schemerFacade.tryResolveIdentifierConflicts()) {
            this.hasIdentifierConflict = true;
            this.selectVarScheme();
            this.basicVariables = [];
            this.derivedVariables = [];
            this.codingStatus = {};
            this.problems = [];
            return;
        }
        this.hasIdentifierConflict = false;
        if (this.schemerService.varList &&
            this.schemerService.varList.length > 0 &&
            this.schemerService.codingScheme &&
            this.schemerService.codingScheme.variableCodings) {
            // remove orphan+empty base variables
            const varListIds = this.schemerService.varList.map(v => v.id);
            const variableCodings = this.schemerService.codingScheme.variableCodings;
            const varCodingsToDelete = variableCodings.filter(bv => bv.sourceType === 'BASE' &&
                varListIds.indexOf(bv.id) < 0 &&
                SchemerComponent.isEmptyCoding(bv));
            if (varCodingsToDelete.length > 0) {
                varCodingsToDelete.forEach(vc => {
                    const varCodingIndexToDelete = variableCodings.indexOf(vc);
                    if (varCodingIndexToDelete >= 0) {
                        variableCodings.splice(varCodingIndexToDelete, 1);
                    }
                });
            }
            // add new base variables
            const allBaseVariableIds = this.schemerService.codingScheme.variableCodings
                .filter(v => v.sourceType === 'BASE')
                .map(bv => bv.id);
            this.schemerService.varList
                .filter(vi => allBaseVariableIds.indexOf(vi.id) < 0 && vi.type !== 'no-value')
                .forEach(vi => {
                const found = this.schemerService.codingScheme?.variableCodings.find(v => v.id === vi.id);
                if (!found) {
                    const newBaseVariable = CodingFactory.createCodingVariable(vi.id);
                    newBaseVariable.alias = vi.alias || vi.id;
                    if (this.schemerService.codingScheme) {
                        this.schemerService.codingScheme.variableCodings.push(newBaseVariable);
                    }
                }
            });
        }
        // update aliases
        this.schemerService.varList.forEach(vi => {
            if (this.schemerService.codingScheme &&
                this.schemerService.codingScheme.variableCodings) {
                const coding = this.schemerService.codingScheme.variableCodings.find(vc => vc.id === vi.id);
                if (coding)
                    coding.alias = vi.alias || vi.id;
            }
        });
        this.basicVariables =
            this.schemerService.codingScheme &&
                this.schemerService.codingScheme.variableCodings ?
                this.schemerService.codingScheme?.variableCodings
                    .filter(c => c.sourceType === 'BASE')
                    .sort((a, b) => {
                    const idA = (a.alias || a.id).toUpperCase();
                    const idB = (b.alias || b.id).toUpperCase();
                    if (idA < idB)
                        return -1;
                    if (idA > idB)
                        return 1;
                    return 0;
                }) :
                [];
        this.derivedVariables =
            this.schemerService.codingScheme &&
                this.schemerService.codingScheme.variableCodings ?
                this.schemerService.codingScheme?.variableCodings
                    .filter(c => c.sourceType !== 'BASE' && c.sourceType !== 'BASE_NO_VALUE')
                    .sort((a, b) => {
                    const idA = (a.alias || a.id).toUpperCase();
                    const idB = (b.alias || b.id).toUpperCase();
                    if (idA < idB)
                        return -1;
                    if (idA > idB)
                        return 1;
                    return 0;
                }) :
                [];
        this.schemerService.allVariableIds = this.schemerService.codingScheme ?
            this.schemerService.codingScheme.variableCodings.map(c => c.id) :
            [];
        this.codingStatus = {};
        if (this.schemerService.codingScheme &&
            this.schemerService.codingScheme.variableCodings) {
            try {
                this.problems = validateCodingScheme(this.schemerService.varList, this.schemerService.codingScheme.variableCodings);
            }
            catch (e) {
                // eslint-disable-next-line no-console
                console.error('validateCodingScheme failed', e);
                this.problems = [];
            }
            this.schemerService.codingScheme.variableCodings.forEach(v => {
                this.codingStatus[v.id] = 'OK';
                const breakingProblem = this.problems.find(p => p.variableId === (v.alias || v.id) && p.breaking);
                if (breakingProblem) {
                    this.codingStatus[v.id] = 'ERROR';
                }
                else {
                    const minorProblem = this.problems.find(p => p.variableId === (v.alias || v.id) && !p.breaking);
                    if (minorProblem)
                        this.codingStatus[v.id] = 'WARNING';
                }
            });
        }
        const availableVariables = [
            ...this.basicVariables,
            ...this.derivedVariables
        ];
        const nextSelection = availableVariables.find(variable => variable.id === previousSelectedId) ??
            this.derivedVariables[0] ??
            this.basicVariables[0] ??
            null;
        this.selectVarScheme(nextSelection);
    }
    selectVarScheme(coding = null) {
        this.selectedCoding$.next(coding);
    }
    async exportVariable() {
        if (!this.schemerService.codingScheme ||
            this.schemerService.codingScheme.variableCodings.length === 0) {
            this.messageDialog.open(MessageDialogComponent, {
                width: '400px',
                data: {
                    title: this.tr('schemer.export.title'),
                    content: this.tr('schemer.export.no-scheme'),
                    type: MessageType.info
                }
            });
            return;
        }
        const dialogRef = this.selectVariableDialog.open(SelectVariableDialogComponent, {
            width: '600px',
            data: {
                title: this.tr('schemer.export.select.title'),
                prompt: this.tr('schemer.export.select.prompt'),
                variables: this.schemerService.codingScheme.variableCodings,
                selectedVariable: this.selectedCoding$.getValue(),
                codingStatus: this.codingStatus,
                okButtonLabel: this.tr('schemer.export.select.ok')
            }
        });
        const selectedAliases = await firstValueFrom(dialogRef.afterClosed());
        const selectedAlias = Array.isArray(selectedAliases) && selectedAliases.length > 0 ?
            selectedAliases[0] :
            null;
        if (!selectedAlias)
            return;
        const selectedVar = this.schemerService.codingScheme.variableCodings.find(v => (v.alias || v.id) === selectedAlias);
        if (!selectedVar)
            return;
        const payload = {
            type: 'iqb-variable-export',
            version: 1,
            variableId: selectedVar.id,
            variableCoding: selectedVar
        };
        FileService.saveToFile(JSON.stringify(payload, null, 2), `${selectedVar.id}.variable.json`);
    }
    async importVariable() {
        if (this.schemerService.userRole === 'RO')
            return;
        if (!this.schemerService.codingScheme) {
            this.messageDialog.open(MessageDialogComponent, {
                width: '400px',
                data: {
                    title: this.tr('schemer.import.title'),
                    content: this.tr('schemer.import.no-scheme'),
                    type: MessageType.error
                }
            });
            return;
        }
        try {
            const parsed = JSON.parse(await FileService.loadFile(['.json']));
            if (!parsed ||
                parsed.type !== 'iqb-variable-export' ||
                parsed.version !== 1 ||
                !parsed.variableCoding) {
                throw new Error(this.tr('schemer.import.invalid-format'));
            }
            const importedVar = parsed.variableCoding;
            if (!importedVar.id) {
                throw new Error(this.tr('schemer.import.missing-id'));
            }
            const existingIndex = this.schemerService.codingScheme.variableCodings.findIndex(v => v.id === importedVar.id);
            const identifierAnalysis = validateVariableCodingChange(this.schemerService.varList, this.schemerService.codingScheme.variableCodings, {
                coding: importedVar,
                replacedCodingId: existingIndex >= 0 ? importedVar.id : undefined
            });
            if (identifierAnalysis.hasProblems) {
                throw new Error(this.tr('schemer.import.invalid-identifiers'));
            }
            if (existingIndex >= 0) {
                const confirmRef = this.messageDialog.open(ConfirmDialogComponent, {
                    width: '450px',
                    data: {
                        title: this.tr('schemer.import.overwrite.title'),
                        content: this.tr('schemer.import.overwrite.content', {
                            variable: importedVar.alias || importedVar.id
                        }),
                        confirmButtonLabel: this.tr('schemer.import.overwrite.confirm'),
                        showCancel: true
                    }
                });
                const confirmed = await firstValueFrom(confirmRef.afterClosed());
                if (!confirmed)
                    return;
                this.schemerService.codingScheme.variableCodings.splice(existingIndex, 1, importedVar);
            }
            else {
                this.schemerService.codingScheme.variableCodings.push(importedVar);
            }
            this.updateVariableLists();
            this.codingSchemeChanged.emit(this.schemerService.codingScheme);
        }
        catch (e) {
            this.messageDialog.open(MessageDialogComponent, {
                width: '450px',
                data: {
                    title: this.tr('schemer.import.error.title'),
                    content: e instanceof Error ?
                        e.message :
                        this.tr('schemer.import.error.unknown'),
                    type: MessageType.error
                }
            });
        }
    }
    static isEmptyCoding(coding) {
        return isEmptyVariableCoding(coding);
    }
    addVarScheme() {
        if (this.schemerService.userRole !== 'RO' &&
            this.schemerService.codingScheme) {
            const dialogRef = this.editSourceParametersDialog.open(EditSourceParametersDialog, {
                width: '600px',
                minHeight: '400px',
                data: {
                    selfId: '',
                    selfAlias: '',
                    sourceType: 'SUM_SCORE',
                    sourceParameters: {
                        processing: [],
                        solverExpression: ''
                    },
                    deriveSources: []
                }
            });
            dialogRef.afterClosed().subscribe(dialogResult => {
                if (dialogResult !== false && this.schemerService.codingScheme) {
                    const timestamp = new Date().getTime();
                    const dialogResultTyped = dialogResult;
                    const newVarScheme = {
                        id: `d_${timestamp}`,
                        alias: dialogResultTyped.selfAlias,
                        label: '',
                        sourceType: dialogResultTyped.sourceType,
                        sourceParameters: dialogResultTyped.sourceParameters,
                        deriveSources: dialogResultTyped.deriveSources,
                        processing: [],
                        codeModel: 'MANUAL_AND_RULES',
                        manualInstruction: '',
                        codes: [],
                        page: ''
                    };
                    const identifierAnalysis = validateVariableCodingChange(this.schemerService.varList, this.schemerService.codingScheme.variableCodings, { coding: newVarScheme });
                    let errorMessage = '';
                    if (identifierAnalysis.hasProblems) {
                        errorMessage = 'data-error.variable-id.double';
                    }
                    else {
                        this.schemerService.codingScheme.variableCodings.push(newVarScheme);
                        this.selectVarScheme(newVarScheme);
                    }
                    if (errorMessage) {
                        this.messageDialog.open(MessageDialogComponent, {
                            width: '400px',
                            data: {
                                title: this.tr('schemer.add.error.title'),
                                content: this.translateService.instant(errorMessage),
                                type: MessageType.error
                            }
                        });
                    }
                    else {
                        this.updateVariableLists();
                        this.codingSchemeChanged.emit(this.schemerService.codingScheme);
                    }
                }
            });
        }
    }
    deleteVarScheme() {
        if (this.schemerService.codingScheme) {
            const dialogData = {
                title: this.tr('schemer.delete.title'),
                prompt: this.tr('schemer.delete.prompt'),
                variables: this.schemerService.codingScheme.variableCodings.filter(c => c.sourceType !== 'BASE_NO_VALUE' &&
                    !this.schemerService.isProtectedBaseVariable(c)),
                selectedVariable: this.selectedCoding$.getValue(),
                codingStatus: this.codingStatus,
                okButtonLabel: this.tr('schemer.delete.ok')
            };
            const dialogRef = this.selectVariableDialog.open(SelectVariableDialogComponent, {
                width: '400px',
                data: dialogData
            });
            dialogRef.afterClosed().subscribe((variables) => {
                let changed = false;
                if (variables && variables.length > 0) {
                    if (this.schemerService && this.schemerService.codingScheme) {
                        const oldLength = this.schemerService.codingScheme.variableCodings.length;
                        this.schemerService.codingScheme.variableCodings =
                            this.schemerService.codingScheme.variableCodings.filter(c => this.schemerService.isProtectedBaseVariable(c) ||
                                !variables.includes(c.alias || c.id));
                        changed =
                            this.schemerService.codingScheme.variableCodings.length !==
                                oldLength;
                    }
                    if (changed) {
                        this.updateVariableLists();
                        this.codingSchemeChanged.emit(this.schemerService.codingScheme);
                    }
                }
            });
        }
    }
    renameVarScheme() {
        const selectedCoding = this.selectedCoding$.getValue();
        if (selectedCoding && selectedCoding.sourceType !== 'BASE') {
            const dialogData = {
                title: this.tr('schemer.rename.title'),
                prompt: this.tr('schemer.rename.prompt', {
                    variable: selectedCoding.alias
                }),
                placeholder: this.tr('schemer.rename.placeholder'),
                value: selectedCoding.alias,
                saveButtonLabel: this.tr('schemer.rename.save'),
                showCancel: true
            };
            const dialogRef = this.inputDialog.open(SimpleInputDialogComponent, {
                width: '400px',
                data: dialogData
            });
            dialogRef.afterClosed().subscribe(result => {
                if (result !== false) {
                    const variableCodings = this.schemerService.codingScheme?.variableCodings;
                    const identifierAnalysis = variableCodings ?
                        validateVariableCodingChange(this.schemerService.varList, variableCodings, {
                            coding: { ...selectedCoding, alias: result },
                            replacedCodingId: selectedCoding.id
                        }) :
                        null;
                    if (!identifierAnalysis || identifierAnalysis.hasProblems) {
                        const errorMessage = identifierAnalysis?.hasInvalid ?
                            'data-error.variable-id.character' :
                            'data-error.variable-id.double';
                        this.messageDialog.open(MessageDialogComponent, {
                            width: '400px',
                            data: {
                                title: this.tr('schemer.rename.error.title'),
                                content: this.translateService.instant(errorMessage),
                                type: MessageType.error
                            }
                        });
                    }
                    else {
                        selectedCoding.alias = result;
                        this.updateVariableLists();
                        this.codingSchemeChanged.emit(this.schemerService.codingScheme);
                    }
                }
            });
        }
        else {
            this.messageDialog.open(MessageDialogComponent, {
                width: '400px',
                data: {
                    title: this.tr('schemer.rename.title'),
                    content: this.tr('schemer.rename.select-derived-first'),
                    type: MessageType.error
                }
            });
        }
    }
    activateBaseNoValueVars() {
        if (this.schemerService.codingScheme) {
            const dialogData = {
                title: this.tr('schemer.activate-base-no-value.title'),
                prompt: this.tr('schemer.activate-base-no-value.prompt'),
                variables: this.schemerService.codingScheme.variableCodings.filter(c => c.sourceType === 'BASE_NO_VALUE'),
                okButtonLabel: this.tr('schemer.activate-base-no-value.ok')
            };
            const dialogRef = this.selectVariableDialog.open(SelectVariableDialogComponent, {
                width: '400px',
                data: dialogData
            });
            dialogRef.afterClosed().subscribe((variables) => {
                let changed = false;
                if (variables && variables.length > 0) {
                    variables.forEach(v => {
                        if (this.schemerService && this.schemerService.codingScheme) {
                            const targetCoding = this.schemerService.codingScheme.variableCodings.find(c => (c.alias || c.id) === v);
                            if (targetCoding) {
                                targetCoding.sourceType = 'BASE';
                                this.schemerService.codingScheme.variableCodings =
                                    this.schemerService.codingScheme.variableCodings.filter(c => c.id !== targetCoding.id);
                                this.schemerService.codingScheme.variableCodings.push(targetCoding);
                                const existingVariableInfo = this.schemerService.varList.find(vi => vi.id === targetCoding.id);
                                if (existingVariableInfo?.type === 'no-value') {
                                    existingVariableInfo.alias =
                                        targetCoding.alias || targetCoding.id;
                                    existingVariableInfo.type = 'string';
                                    existingVariableInfo.format = '';
                                    existingVariableInfo.multiple = true;
                                    existingVariableInfo.nullable = true;
                                    existingVariableInfo.values = [];
                                    existingVariableInfo.valuePositionLabels = [];
                                }
                                else if (!existingVariableInfo) {
                                    this.schemerService.varList.push({
                                        id: targetCoding.id,
                                        alias: targetCoding.alias || targetCoding.id,
                                        type: 'string',
                                        format: '',
                                        multiple: true,
                                        nullable: true,
                                        values: [],
                                        valuePositionLabels: []
                                    });
                                }
                                changed = true;
                            }
                        }
                    });
                    if (changed) {
                        this.updateVariableLists();
                        this.codingSchemeChanged.emit(this.schemerService.codingScheme);
                    }
                }
            });
        }
    }
    copyVarScheme() {
        const selectedCoding = this.selectedCoding$.getValue();
        if (selectedCoding && this.schemerService.codingScheme) {
            const dialogData = {
                title: this.tr('schemer.copy.title', {
                    variable: selectedCoding.alias || selectedCoding.id
                }),
                prompt: this.tr('schemer.copy.prompt'),
                variables: this.schemerService.codingScheme.variableCodings.filter(c => c.id !== selectedCoding.id && c.sourceType !== 'BASE_NO_VALUE'),
                selectedVariable: this.selectedCoding$.getValue(),
                codingStatus: this.codingStatus,
                okButtonLabel: this.tr('schemer.copy.ok')
            };
            const dialogRef = this.selectVariableDialog.open(SelectVariableDialogComponent, {
                width: '400px',
                data: dialogData
            });
            dialogRef.afterClosed().subscribe((variables) => {
                let changed = false;
                if (variables && variables.length > 0) {
                    variables.forEach(v => {
                        if (this.schemerService && this.schemerService.codingScheme) {
                            const targetCoding = this.schemerService.codingScheme.variableCodings.find(c => (c.alias || c.id) === v);
                            if (targetCoding) {
                                const stringifiedCoding = JSON.stringify(selectedCoding);
                                const newCoding = JSON.parse(stringifiedCoding);
                                newCoding.id = targetCoding.id;
                                newCoding.alias = targetCoding.alias;
                                this.schemerService.codingScheme.variableCodings =
                                    this.schemerService.codingScheme.variableCodings.filter(c => c.id !== targetCoding.id);
                                if (newCoding.sourceType !== 'BASE' ||
                                    targetCoding.sourceType !== 'BASE') {
                                    newCoding.sourceType = targetCoding.sourceType;
                                    newCoding.sourceParameters = targetCoding.sourceParameters;
                                    newCoding.deriveSources = targetCoding.deriveSources;
                                }
                                this.schemerService.codingScheme.variableCodings.push(newCoding);
                                changed = true;
                            }
                        }
                    });
                    if (changed) {
                        this.updateVariableLists();
                        this.codingSchemeChanged.emit(this.schemerService.codingScheme);
                    }
                }
            });
        }
    }
    checkVarScheme() {
        if (this.problems) {
            const dialogRef = this.showCodingProblemsDialog.open(ShowCodingProblemsDialogComponent, {
                width: '1000px',
                data: this.problems
            });
            dialogRef.afterClosed().subscribe();
        }
    }
    showCodingScheme() {
        if (!this.codingScheme) {
            return;
        }
        const payload = {
            variableCodings: this.codingScheme.variableCodings,
            version: `${CodingSchemeVersionMajor}.${CodingSchemeVersionMinor}`
        };
        this.showCodingSchemeDialog.open(CodingSchemeDialogComponent, {
            width: '600px',
            data: { codingScheme: payload }
        });
    }
    variableDependencyTree() {
        this.showCodingProblemsDialog
            .open(ShowDependencyTreeDialogComponent, {
            width: '1000px',
            data: this.codingScheme
        })
            .afterClosed()
            .subscribe();
    }
    ngOnDestroy() {
        if (this.varCodingChangedSubscription !== null)
            this.varCodingChangedSubscription.unsubscribe();
        this.schemerFacade.resetIdentifierConflictResolutionState();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerComponent, deps: [{ token: i1.TranslateService }, { token: SchemerService }, { token: SchemerFacadeService }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }, { token: i4.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SchemerComponent, isStandalone: true, selector: "iqb-schemer", inputs: { codingScheme: "codingScheme", userRole: "userRole", varList: "varList" }, outputs: { codingSchemeChanged: "codingSchemeChanged" }, viewQueries: [{ propertyName: "varCodingElement", first: true, predicate: VarCodingComponent, descendants: true }], ngImport: i0, template: "<div class=\"scheme-body fx-row-space-between-stretch\">\n  @if (hasIdentifierConflict) {\n  <div style=\"margin: 20px\">\n    <div style=\"margin-bottom: 12px;\">\n      Bitte korrigiere die betroffenen Variablenbezeichner an ihrer im Dialog\n      angegebenen Quelle und lade den Schemer neu.\n    </div>\n    <div class=\"fx-row-start-center fx-gap-10\">\n      <button mat-button (click)=\"showSchemerInfo()\">\n        <mat-icon>info</mat-icon>\n        {{ \"varList.info\" | translate }}\n      </button>\n      <button mat-button (click)=\"showCodingScheme()\">\n        <mat-icon>reorder</mat-icon>\n        {{ \"varList.show\" | translate }}\n      </button>\n    </div>\n  </div>\n  } @else {\n  @if (basicVariables && basicVariables.length !== 0) {\n  <div class=\"navi-bar fx-column-space-between-stretch\">\n    <div class=\"var-scheme-list fx-flex\">\n      <div class=\"var-list-header\">{{ \"varList.base\" | translate }}</div>\n      @for (varBasic of basicVariables; track varBasic) {\n      <mat-nav-list class=\"fx-column-start-stretch\">\n        <div class=\"fx-row-start-center\">\n          <div\n            [class]=\"'var-marker-' + codingStatus[varBasic.id]\"\n            [matTooltip]=\"\n              'coding-status.' + codingStatus[varBasic.id] | translate\n            \"\n          ></div>\n          <a\n            mat-list-item\n            style=\"height: 22px; text-overflow: ellipsis\"\n            class=\"var-list-entry\"\n            [class]=\"\n              varBasic.id === (selectedCoding$ | async)?.id\n                ? 'selected'\n                : 'not-selected'\n            \"\n            (click)=\"selectVarScheme(varBasic)\"\n          >\n            {{ varBasic.alias || varBasic.id }}\n          </a>\n        </div>\n      </mat-nav-list>\n      }\n      <div class=\"var-list-header\">{{ \"varList.derived\" | translate }}</div>\n      @for (varScheme of derivedVariables; track varScheme) {\n      <mat-nav-list class=\"fx-column-start-stretch\">\n        <div class=\"fx-row-start-center\">\n          <div\n            [class]=\"'var-marker-' + codingStatus[varScheme.id]\"\n            [matTooltip]=\"\n              'coding-status.' + codingStatus[varScheme.id] | translate\n            \"\n          ></div>\n          <a\n            mat-list-item\n            style=\"height: 22px; text-overflow: ellipsis\"\n            class=\"var-list-entry\"\n            (click)=\"selectVarScheme(varScheme)\"\n            [class]=\"\n              varScheme.id === (selectedCoding$ | async)?.id\n                ? 'selected'\n                : 'not-selected'\n            \"\n          >\n            {{ varScheme.alias || varScheme.id }}\n          </a>\n        </div>\n      </mat-nav-list>\n      }\n    </div>\n    <div class=\"var-list-buttons fx-row-space-between-center\">\n      <button\n        mat-button\n        (click)=\"addVarScheme()\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matTooltip]=\"'varList.add' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon class=\"bold-icon\">add</mat-icon>\n      </button>\n      <button\n        mat-button\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        (click)=\"deleteVarScheme()\"\n        [matTooltip]=\"'varList.delete' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>delete</mat-icon>\n      </button>\n      <button\n        mat-button\n        (click)=\"renameVarScheme()\"\n        [disabled]=\"\n          (selectedCoding$ | async) === null ||\n          (selectedCoding$ | async)?.sourceType === 'BASE' ||\n          schemerService.userRole === 'RO'\n        \"\n        [matTooltip]=\"'varList.rename' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>edit</mat-icon>\n      </button>\n      <button\n        mat-button\n        [disabled]=\"\n          (selectedCoding$ | async) === null || schemerService.userRole === 'RO'\n        \"\n        [matTooltip]=\"'varList.copy' | translate\"\n        (click)=\"copyVarScheme()\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>content_copy</mat-icon>\n      </button>\n      <button\n        mat-button\n        [matMenuTriggerFor]=\"otherFunctions\"\n        [matTooltip]=\"'varList.more-actions' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>menu</mat-icon>\n      </button>\n      <mat-menu #otherFunctions=\"matMenu\">\n        <button mat-menu-item (click)=\"showSchemerInfo()\">\n          <mat-icon>info</mat-icon>\n          {{ \"varList.info\" | translate }}\n        </button>\n        <mat-divider></mat-divider>\n        <button\n          mat-menu-item\n          (click)=\"activateBaseNoValueVars()\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n        >\n          <mat-icon>bolt</mat-icon>\n          {{ \"varList.activate-base-no-value\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"checkVarScheme()\">\n          <mat-icon>check</mat-icon>\n          {{ \"varList.check\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"showCodingScheme()\">\n          <mat-icon>reorder</mat-icon>\n          {{ \"varList.show\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"exportVariable()\">\n          <mat-icon>get_app</mat-icon>\n          {{ \"varList.export-variable\" | translate }}\n        </button>\n        <button\n          mat-menu-item\n          (click)=\"importVariable()\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n        >\n          <mat-icon>input</mat-icon>\n          {{ \"varList.import-variable\" | translate }}\n        </button>\n        <button\n          mat-menu-item\n          (click)=\"variableDependencyTree()\"\n          [disabled]=\"derivedVariables.length === 0\"\n        >\n          <mat-icon>account_tree</mat-icon>\n          {{ \"varList.derived-tree.title\" | translate }}\n        </button>\n      </mat-menu>\n    </div>\n  </div>\n  } @if (basicVariables && basicVariables.length === 0) {\n  <div style=\"margin: 20px\">\n    {{ \"data-error.base-variables-missing\" | translate }}\n  </div>\n  }\n  <var-coding\n    [varCoding]=\"selectedCoding$ | async\"\n    class=\"var-coding-container fx-flex-row-100\"\n  ></var-coding>\n  }\n</div>\n", styles: [":host{display:block;min-width:320px;container:schemer/inline-size}.scheme-body{height:100%;top:0;bottom:0;background-color:#fc0;padding:0}.navi-bar{height:100%;flex:0 0 210px;background-color:#f5f5f5;margin:0;border-left:5px solid #c4e6e8;min-height:0;min-width:0}.var-scheme-list{overflow:auto;min-height:0}.var-list-buttons{background-color:#c4e6e8}.var-list-buttons>.mat-mdc-button{padding:0;min-width:40px}.selected{background-color:#90d2d2}.var-coding-container{background-color:#fff;overflow-x:hidden;overflow-y:auto;min-width:0;min-height:0}@container schemer (max-width: 650px){.scheme-body{flex-direction:column}.navi-bar{flex:0 0 auto;height:180px;max-height:30%}}.var-list-header{height:20px;padding:4px 6px;font-size:14px;background-color:#c4e6e8;margin:0}.var-list-entry{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;padding-left:2px}.invalid-data-format{font-size:large;color:#ff8c00;font-weight:700;padding:20px}.var-marker-ERROR,.var-marker-WARNING,.var-marker-OK{flex:0 0 12px;height:12px;border-radius:0;margin-left:6px;margin-right:6px}.var-marker-ERROR{background:#f30}.var-marker-WARNING{background:#fc0}.var-marker-OK{background:transparent}.bold-icon{font-weight:700}\n"], dependencies: [{ kind: "component", type: MatNavList, selector: "mat-nav-list", exportAs: ["matNavList"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: VarCodingComponent, selector: "var-coding", inputs: ["varCoding"], outputs: ["varCodingChanged"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatDivider$1, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iqb-schemer', standalone: true, imports: [
                        MatNavList,
                        MatTooltipModule,
                        MatListItem,
                        MatButton,
                        MatIcon,
                        VarCodingComponent,
                        AsyncPipe,
                        TranslateModule,
                        MatMenu,
                        MatMenuItem,
                        MatMenuTrigger,
                        MatDivider$1
                    ], template: "<div class=\"scheme-body fx-row-space-between-stretch\">\n  @if (hasIdentifierConflict) {\n  <div style=\"margin: 20px\">\n    <div style=\"margin-bottom: 12px;\">\n      Bitte korrigiere die betroffenen Variablenbezeichner an ihrer im Dialog\n      angegebenen Quelle und lade den Schemer neu.\n    </div>\n    <div class=\"fx-row-start-center fx-gap-10\">\n      <button mat-button (click)=\"showSchemerInfo()\">\n        <mat-icon>info</mat-icon>\n        {{ \"varList.info\" | translate }}\n      </button>\n      <button mat-button (click)=\"showCodingScheme()\">\n        <mat-icon>reorder</mat-icon>\n        {{ \"varList.show\" | translate }}\n      </button>\n    </div>\n  </div>\n  } @else {\n  @if (basicVariables && basicVariables.length !== 0) {\n  <div class=\"navi-bar fx-column-space-between-stretch\">\n    <div class=\"var-scheme-list fx-flex\">\n      <div class=\"var-list-header\">{{ \"varList.base\" | translate }}</div>\n      @for (varBasic of basicVariables; track varBasic) {\n      <mat-nav-list class=\"fx-column-start-stretch\">\n        <div class=\"fx-row-start-center\">\n          <div\n            [class]=\"'var-marker-' + codingStatus[varBasic.id]\"\n            [matTooltip]=\"\n              'coding-status.' + codingStatus[varBasic.id] | translate\n            \"\n          ></div>\n          <a\n            mat-list-item\n            style=\"height: 22px; text-overflow: ellipsis\"\n            class=\"var-list-entry\"\n            [class]=\"\n              varBasic.id === (selectedCoding$ | async)?.id\n                ? 'selected'\n                : 'not-selected'\n            \"\n            (click)=\"selectVarScheme(varBasic)\"\n          >\n            {{ varBasic.alias || varBasic.id }}\n          </a>\n        </div>\n      </mat-nav-list>\n      }\n      <div class=\"var-list-header\">{{ \"varList.derived\" | translate }}</div>\n      @for (varScheme of derivedVariables; track varScheme) {\n      <mat-nav-list class=\"fx-column-start-stretch\">\n        <div class=\"fx-row-start-center\">\n          <div\n            [class]=\"'var-marker-' + codingStatus[varScheme.id]\"\n            [matTooltip]=\"\n              'coding-status.' + codingStatus[varScheme.id] | translate\n            \"\n          ></div>\n          <a\n            mat-list-item\n            style=\"height: 22px; text-overflow: ellipsis\"\n            class=\"var-list-entry\"\n            (click)=\"selectVarScheme(varScheme)\"\n            [class]=\"\n              varScheme.id === (selectedCoding$ | async)?.id\n                ? 'selected'\n                : 'not-selected'\n            \"\n          >\n            {{ varScheme.alias || varScheme.id }}\n          </a>\n        </div>\n      </mat-nav-list>\n      }\n    </div>\n    <div class=\"var-list-buttons fx-row-space-between-center\">\n      <button\n        mat-button\n        (click)=\"addVarScheme()\"\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        [matTooltip]=\"'varList.add' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon class=\"bold-icon\">add</mat-icon>\n      </button>\n      <button\n        mat-button\n        [disabled]=\"schemerService.userRole === 'RO'\"\n        (click)=\"deleteVarScheme()\"\n        [matTooltip]=\"'varList.delete' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>delete</mat-icon>\n      </button>\n      <button\n        mat-button\n        (click)=\"renameVarScheme()\"\n        [disabled]=\"\n          (selectedCoding$ | async) === null ||\n          (selectedCoding$ | async)?.sourceType === 'BASE' ||\n          schemerService.userRole === 'RO'\n        \"\n        [matTooltip]=\"'varList.rename' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>edit</mat-icon>\n      </button>\n      <button\n        mat-button\n        [disabled]=\"\n          (selectedCoding$ | async) === null || schemerService.userRole === 'RO'\n        \"\n        [matTooltip]=\"'varList.copy' | translate\"\n        (click)=\"copyVarScheme()\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>content_copy</mat-icon>\n      </button>\n      <button\n        mat-button\n        [matMenuTriggerFor]=\"otherFunctions\"\n        [matTooltip]=\"'varList.more-actions' | translate\"\n        matTooltipPosition=\"above\"\n      >\n        <mat-icon>menu</mat-icon>\n      </button>\n      <mat-menu #otherFunctions=\"matMenu\">\n        <button mat-menu-item (click)=\"showSchemerInfo()\">\n          <mat-icon>info</mat-icon>\n          {{ \"varList.info\" | translate }}\n        </button>\n        <mat-divider></mat-divider>\n        <button\n          mat-menu-item\n          (click)=\"activateBaseNoValueVars()\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n        >\n          <mat-icon>bolt</mat-icon>\n          {{ \"varList.activate-base-no-value\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"checkVarScheme()\">\n          <mat-icon>check</mat-icon>\n          {{ \"varList.check\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"showCodingScheme()\">\n          <mat-icon>reorder</mat-icon>\n          {{ \"varList.show\" | translate }}\n        </button>\n        <button mat-menu-item (click)=\"exportVariable()\">\n          <mat-icon>get_app</mat-icon>\n          {{ \"varList.export-variable\" | translate }}\n        </button>\n        <button\n          mat-menu-item\n          (click)=\"importVariable()\"\n          [disabled]=\"schemerService.userRole === 'RO'\"\n        >\n          <mat-icon>input</mat-icon>\n          {{ \"varList.import-variable\" | translate }}\n        </button>\n        <button\n          mat-menu-item\n          (click)=\"variableDependencyTree()\"\n          [disabled]=\"derivedVariables.length === 0\"\n        >\n          <mat-icon>account_tree</mat-icon>\n          {{ \"varList.derived-tree.title\" | translate }}\n        </button>\n      </mat-menu>\n    </div>\n  </div>\n  } @if (basicVariables && basicVariables.length === 0) {\n  <div style=\"margin: 20px\">\n    {{ \"data-error.base-variables-missing\" | translate }}\n  </div>\n  }\n  <var-coding\n    [varCoding]=\"selectedCoding$ | async\"\n    class=\"var-coding-container fx-flex-row-100\"\n  ></var-coding>\n  }\n</div>\n", styles: [":host{display:block;min-width:320px;container:schemer/inline-size}.scheme-body{height:100%;top:0;bottom:0;background-color:#fc0;padding:0}.navi-bar{height:100%;flex:0 0 210px;background-color:#f5f5f5;margin:0;border-left:5px solid #c4e6e8;min-height:0;min-width:0}.var-scheme-list{overflow:auto;min-height:0}.var-list-buttons{background-color:#c4e6e8}.var-list-buttons>.mat-mdc-button{padding:0;min-width:40px}.selected{background-color:#90d2d2}.var-coding-container{background-color:#fff;overflow-x:hidden;overflow-y:auto;min-width:0;min-height:0}@container schemer (max-width: 650px){.scheme-body{flex-direction:column}.navi-bar{flex:0 0 auto;height:180px;max-height:30%}}.var-list-header{height:20px;padding:4px 6px;font-size:14px;background-color:#c4e6e8;margin:0}.var-list-entry{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;padding-left:2px}.invalid-data-format{font-size:large;color:#ff8c00;font-weight:700;padding:20px}.var-marker-ERROR,.var-marker-WARNING,.var-marker-OK{flex:0 0 12px;height:12px;border-radius:0;margin-left:6px;margin-right:6px}.var-marker-ERROR{background:#f30}.var-marker-WARNING{background:#fc0}.var-marker-OK{background:transparent}.bold-icon{font-weight:700}\n"] }]
        }], ctorParameters: () => [{ type: i1.TranslateService }, { type: SchemerService }, { type: SchemerFacadeService }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }, { type: i4.MatDialog }], propDecorators: { varCodingElement: [{
                type: ViewChild,
                args: [VarCodingComponent]
            }], codingSchemeChanged: [{
                type: Output
            }], codingScheme: [{
                type: Input
            }], userRole: [{
                type: Input
            }], varList: [{
                type: Input
            }] } });

class SchemerStandaloneMenuComponent {
    constructor() {
        this.codingScheme = null;
        this.varList = [];
        this.userRole = 'RW_MAXIMAL';
        this.userRoleChanged = new EventEmitter();
        this.codingSchemeChanged = new EventEmitter();
        this.varListChanged = new EventEmitter();
    }
    saveCodingScheme() {
        const payload = {
            variableCodings: this.codingScheme?.variableCodings ?? [],
            version: `${CodingSchemeVersionMajor}.${CodingSchemeVersionMinor}`
        };
        FileService.saveToFile(JSON.stringify(payload, null, 2), 'coding-scheme.json');
    }
    async loadVariables() {
        this.varList = JSON.parse(await FileService.loadFile(['.json']));
        this.varListChanged.emit(this.varList);
    }
    async loadCodingScheme() {
        const codingsParsed = JSON.parse(await FileService.loadFile(['.json']));
        let variableCodings = [];
        if (Array.isArray(codingsParsed?.variableCodings)) {
            variableCodings = codingsParsed.variableCodings;
        }
        else if (Array.isArray(codingsParsed)) {
            variableCodings = codingsParsed;
        }
        this.codingScheme = new CodingScheme(variableCodings);
        this.codingSchemeChanged.emit(this.codingScheme);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerStandaloneMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: SchemerStandaloneMenuComponent, isStandalone: true, selector: "schemer-standalone-menu", inputs: { codingScheme: "codingScheme", varList: "varList", userRole: "userRole" }, outputs: { userRoleChanged: "userRoleChanged", codingSchemeChanged: "codingSchemeChanged", varListChanged: "varListChanged" }, ngImport: i0, template: `
    <button
      mat-fab
      [matMenuTriggerFor]="menu"
      [matTooltip]="'varList.load-save-user-role' | translate"
      matTooltipPosition="above"
    >
      <mat-icon>menu</mat-icon>
    </button>

    <mat-menu #menu="matMenu">
      <button mat-menu-item (click)="loadVariables()">
        <mat-icon>input</mat-icon>{{ 'varList.load-variables' | translate }}
      </button>
      <mat-divider></mat-divider>
      <button mat-menu-item (click)="loadCodingScheme()">
        <mat-icon>input</mat-icon>{{ 'varList.load-coding-scheme' | translate }}
      </button>
      <button mat-menu-item (click)="saveCodingScheme()">
        <mat-icon>get_app</mat-icon
        >{{ 'varList.save-coding-scheme' | translate }}
      </button>
      <mat-divider></mat-divider>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RO')"
        [disabled]="userRole === 'RO'"
      >
        @if (userRole === 'RO') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.ro' | translate }}
      </button>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RW_MINIMAL')"
        [disabled]="userRole === 'RW_MINIMAL'"
      >
        @if (userRole === 'RW_MINIMAL') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.rw-minimal' | translate }}
      </button>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RW_MAXIMAL')"
        [disabled]="userRole === 'RW_MAXIMAL'"
      >
        @if (userRole === 'RW_MAXIMAL') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.rw-maximal' | translate }}
      </button>
    </mat-menu>
  `, isInline: true, styles: [".mat-mdc-fab{z-index:999;position:absolute;top:4px;right:8px}\n"], dependencies: [{ kind: "component", type: MatFabButton, selector: "button[mat-fab], a[mat-fab], button[matFab], a[matFab]", inputs: ["extended"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i1.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: SchemerStandaloneMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'schemer-standalone-menu', template: `
    <button
      mat-fab
      [matMenuTriggerFor]="menu"
      [matTooltip]="'varList.load-save-user-role' | translate"
      matTooltipPosition="above"
    >
      <mat-icon>menu</mat-icon>
    </button>

    <mat-menu #menu="matMenu">
      <button mat-menu-item (click)="loadVariables()">
        <mat-icon>input</mat-icon>{{ 'varList.load-variables' | translate }}
      </button>
      <mat-divider></mat-divider>
      <button mat-menu-item (click)="loadCodingScheme()">
        <mat-icon>input</mat-icon>{{ 'varList.load-coding-scheme' | translate }}
      </button>
      <button mat-menu-item (click)="saveCodingScheme()">
        <mat-icon>get_app</mat-icon
        >{{ 'varList.save-coding-scheme' | translate }}
      </button>
      <mat-divider></mat-divider>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RO')"
        [disabled]="userRole === 'RO'"
      >
        @if (userRole === 'RO') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.ro' | translate }}
      </button>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RW_MINIMAL')"
        [disabled]="userRole === 'RW_MINIMAL'"
      >
        @if (userRole === 'RW_MINIMAL') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.rw-minimal' | translate }}
      </button>
      <button
        mat-menu-item
        (click)="this.userRoleChanged.emit('RW_MAXIMAL')"
        [disabled]="userRole === 'RW_MAXIMAL'"
      >
        @if (userRole === 'RW_MAXIMAL') {
        <mat-icon>check</mat-icon>
        } {{ 'varList.role.rw-maximal' | translate }}
      </button>
    </mat-menu>
  `, standalone: true, imports: [
                        MatFabButton,
                        MatTooltipModule,
                        MatMenuTrigger,
                        MatIcon,
                        MatMenu,
                        MatMenuItem,
                        MatDivider,
                        TranslateModule
                    ], styles: [".mat-mdc-fab{z-index:999;position:absolute;top:4px;right:8px}\n"] }]
        }], propDecorators: { codingScheme: [{
                type: Input
            }], varList: [{
                type: Input
            }], userRole: [{
                type: Input
            }], userRoleChanged: [{
                type: Output
            }], codingSchemeChanged: [{
                type: Output
            }], varListChanged: [{
                type: Output
            }] } });

const NGX_CODING_COMPONENTS_ELEMENT_TAGS = {
    'ngx-scheme-checker': 'ngx-scheme-checker',
    'ngx-schemer': 'ngx-schemer',
    'ngx-schemer-standalone-menu': 'ngx-schemer-standalone-menu',
    'ngx-var-coding': 'ngx-var-coding',
    'ngx-codes-title': 'ngx-codes-title',
    'ngx-single-code': 'ngx-single-code',
    'ngx-code-instruction': 'ngx-code-instruction',
    'ngx-code-rules': 'ngx-code-rules',
    'ngx-code-rule-list': 'ngx-code-rule-list',
    'ngx-rich-text-editor': 'ngx-rich-text-editor',
    'ngx-combo-button': 'ngx-combo-button'
};
const registerNgxCodingComponentsElements = (injector, options = {}) => {
    const prefix = (options.prefix || 'ngx').replace(/-+$/g, '');
    const tag = (name) => `${prefix}-${name}`.replace(/--+/g, '-');
    const defineElement = (tagName, elementConstructor) => {
        if (!customElements.get(tagName)) {
            customElements.define(tagName, elementConstructor);
        }
    };
    defineElement(tag('scheme-checker'), createCustomElement(SchemeCheckerComponent, { injector }));
    defineElement(tag('schemer'), createCustomElement(SchemerComponent, { injector }));
    defineElement(tag('schemer-standalone-menu'), createCustomElement(SchemerStandaloneMenuComponent, { injector }));
    defineElement(tag('var-coding'), createCustomElement(VarCodingComponent, { injector }));
    defineElement(tag('codes-title'), createCustomElement(CodesTitleComponent, { injector }));
    defineElement(tag('single-code'), createCustomElement(SingleCodeComponent, { injector }));
    defineElement(tag('code-instruction'), createCustomElement(CodeInstructionComponent, { injector }));
    defineElement(tag('code-rules'), createCustomElement(CodeRulesComponent, { injector }));
    defineElement(tag('code-rule-list'), createCustomElement(CodeRuleListComponent, { injector }));
    defineElement(tag('rich-text-editor'), createCustomElement(RichTextEditorComponent, { injector }));
    defineElement(tag('combo-button'), createCustomElement(ComboButtonComponent, { injector }));
};

/**
 * Generated bundle index. Do not edit.
 */

export { CodingSchemeDialogComponent, ConfirmDialogComponent, MessageDialogComponent, MessageType, NGX_CODING_COMPONENTS_ELEMENT_TAGS, SchemeCheckerComponent, SchemerComponent, SchemerStandaloneMenuComponent, SelectVariableDialogComponent, ShowCodingDialogComponent, ShowCodingProblemsDialogComponent, ShowCodingResultsComponent, SimpleInputDialogComponent, VarCodingComponent, registerNgxCodingComponentsElements };
//# sourceMappingURL=iqb-ngx-coding-components.mjs.map
