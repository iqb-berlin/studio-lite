import { ToTextFactory } from '@iqb/responses';
import { CodingScheme } from '@iqbspecs/coding-scheme';
import * as cheerio from 'cheerio';
import { load } from 'cheerio';
import { Packer, Paragraph, AlignmentType, HeadingLevel, TextRun, TableRow, TableCell, WidthType, Document, Footer, NumberFormat, PageNumber, Table, ImageRun, TextWrappingSide, TextWrappingType, VerticalPositionRelativeFrom, HorizontalPositionAlign, HorizontalPositionRelativeFrom, ImportedXmlComponent, Tab, TabStopType } from 'docx';
import { Buffer } from 'buffer';
import { imageSize } from 'image-size';
import katex from 'katex';
import { mml2omml } from 'mathml2omml';

class CodebookGenerationError extends Error {
    constructor() {
        super(...arguments);
        this.name = 'CodebookGenerationError';
    }
}

/** Rich-text instructions may consist entirely of an image or a formula. */
function hasCodebookManualInstruction(instruction) {
    if (!instruction)
        return false;
    const $ = load(instruction);
    $('script,style').remove();
    const text = $.root().text().replace(/[\s\p{Default_Ignorable_Code_Point}]/gu, '');
    if (text)
        return true;
    return $('img').toArray().some(element => /^data:image\/(png|jpeg|jpg|gif|bmp);base64,\S+$/i.test($(element).attr('src') || '')) ||
        $('span.iqb-math-formula').toArray().some(element => !!$(element).attr('data-latex')?.trim()) ||
        $('aspect-nodeview-math-formula').toArray().some(element => !!$(element).attr('formula')?.trim());
}

class CodebookGenerator {
    static getCodebookData(units, options, missings) {
        return [...units].sort((a, b) => (a.key < b.key ? -1 : Number(a.key > b.key))).map(unit => {
            let variables = [];
            if (unit.scheme) {
                try {
                    const data = JSON.parse(unit.scheme);
                    if (!Array.isArray(data.variableCodings) || data.variableCodings.some((variable) => !variable || typeof variable.id !== 'string' ||
                        (variable.codes !== undefined && (!Array.isArray(variable.codes) || variable.codes.some(code => !code || typeof code !== 'object'))))) {
                        throw new Error('Ungültige variableCodings');
                    }
                    variables = new CodingScheme(unit.scheme).variableCodings;
                }
                catch {
                    throw new CodebookGenerationError(`Ungültiges Kodierschema für Aufgabe ${unit.key}.`);
                }
            }
            const bookVariables = variables.map(variable => this.getVariable(variable, options))
                .filter((variable) => variable !== null)
                .sort((a, b) => (a.id < b.id ? -1 : Number(a.id > b.id)));
            return {
                key: unit.key, name: unit.name, variables: bookVariables, missings, items: unit.metadata?.items || []
            };
        });
    }
    static async generateCodebook(units, options, missings) {
        const data = this.getCodebookData(units, options, missings);
        if (options.exportFormat === 'docx') {
            const { CodebookDocxGenerator } = await Promise.resolve().then(function () { return codebookDocxGenerator; });
            return CodebookDocxGenerator.generateDocx(data, options);
        }
        return new Blob([JSON.stringify(data.map(({ key, name, variables, missings: unitMissings }) => ({
                key, name, variables, missings: unitMissings
            })))], { type: 'application/json' });
    }
    static isClosed(code) {
        return code.type === 'RESIDUAL_AUTO' || code.type === 'INTENDED_INCOMPLETE';
    }
    static isManual(code) {
        return !this.isClosed(code) && hasCodebookManualInstruction(code.manualInstruction);
    }
    static getVariable(variable, options) {
        const trainingRequired = variable.processing?.includes('CODER_TRAINING_REQUIRED') ?? false;
        if (options.trainingRequirement === 'required' && !trainingRequired)
            return null;
        if (options.trainingRequirement === 'not-required' && trainingRequired)
            return null;
        if (variable.sourceType === 'BASE_NO_VALUE' || (variable.sourceType !== 'BASE' && !options.hasDerivedVars))
            return null;
        const codes = (variable.codes || []).filter(code => code.id !== undefined && code.id !== null);
        const manual = codes.some(code => this.isManual(code));
        const closed = codes.some(code => this.isClosed(code));
        if ((options.hasOnlyManualCoding || options.hasClosedVars) &&
            !((options.hasOnlyManualCoding && manual) || (options.hasClosedVars && closed)))
            return null;
        const exportedCodes = options.hasOnlyManualCoding && !options.hasClosedVars ? codes.filter(code => this.isManual(code)) : codes;
        if (options.hasOnlyVarsWithCodes && !exportedCodes.length)
            return null;
        return {
            id: variable.alias || variable.id,
            label: variable.label || '',
            sourceType: variable.sourceType,
            generalInstruction: options.hasGeneralInstructions ? variable.manualInstruction || '' : '',
            codes: exportedCodes.map(code => this.getCode(code, options))
        };
    }
    static getCode(code, options) {
        const fallback = { id: `${code.id}`, label: '', description: '<p>Kodierschema mit Schemer Version ab 1.5 erzeugen!</p>' };
        if (options.showScore)
            fallback.score = '';
        if (Object.prototype.hasOwnProperty.call(code, 'rules'))
            return fallback;
        try {
            const text = ToTextFactory.codeAsText(code, 'SIMPLE');
            const rules = options.hasOnlyManualCoding && !options.hasClosedVars ? '' :
                (text.ruleSetDescriptions || []).filter(rule => rule !== 'Keine Regeln definiert.' || !code.manualInstruction)
                    .map(rule => `<p>${rule}</p>`).join('');
            const result = { id: `${code.id}`, label: options.codeLabelToUpper ? text.label.toUpperCase() : text.label, description: `${rules}${code.manualInstruction || ''}` };
            if (options.showScore)
                result.score = `${text.score}`;
            return result;
        }
        catch {
            return fallback;
        }
    }
}

/**
 * The CSS colour names and their hex values, for turning a colour a user picked by name into
 * something a generated document can paint with.
 */
class WebColors {
    /**
     * The hex value for a CSS colour name, or an empty string when the name is unknown. The name has
     * to be given in lower case -- the table is compared against it as it comes in.
     */
    static getHexFromWebColor(colorName) {
        const foundColor = WebColors.colors
            .find(color => color.name.toLowerCase() === colorName);
        return foundColor ? foundColor.hex : '';
    }
    /** The table itself: name, hex and rgb for every CSS colour. */
    static { this.colors = [
        {
            name: 'Lavender',
            hex: 'E6E6FA',
            rgb: {
                r: 230,
                g: 230,
                b: 250
            }
        },
        {
            name: 'Thistle',
            hex: 'D8BFD8',
            rgb: { r: 216, g: 191, b: 216 }
        },
        {
            name: 'Plum',
            hex: 'DDA0DD',
            rgb: {
                r: 221,
                g: 160,
                b: 221
            }
        },
        {
            name: 'Violet',
            hex: 'EE82EE',
            rgb: {
                r: 238,
                g: 130,
                b: 238
            }
        },
        {
            name: 'Orchid',
            hex: 'DA70D6',
            rgb: {
                r: 218,
                g: 112,
                b: 214
            }
        },
        {
            name: 'Fuchsia',
            hex: 'FF00FF',
            rgb: {
                r: 255,
                g: 0,
                b: 255
            }
        },
        {
            name: 'Magenta',
            hex: 'FF00FF',
            rgb: {
                r: 255,
                g: 0,
                b: 255
            }
        },
        {
            name: 'MediumOrchid',
            hex: 'BA55D3',
            rgb: {
                r: 186,
                g: 85,
                b: 211
            }
        },
        {
            name: 'MediumPurple',
            hex: '9370DB',
            rgb: {
                r: 147,
                g: 112,
                b: 219
            }
        },
        {
            name: 'BlueViolet',
            hex: '8A2BE2',
            rgb: {
                r: 138,
                g: 43,
                b: 226
            }
        },
        {
            name: 'DarkViolet',
            hex: '9400D3',
            rgb: {
                r: 148,
                g: 0,
                b: 211
            }
        },
        {
            name: 'DarkOrchid',
            hex: '9932CC',
            rgb: {
                r: 153,
                g: 50,
                b: 204
            }
        },
        {
            name: 'DarkMagenta',
            hex: '8B008B',
            rgb: {
                r: 139,
                g: 0,
                b: 139
            }
        },
        {
            name: 'Purple',
            hex: '800080',
            rgb: {
                r: 128,
                g: 0,
                b: 128
            }
        },
        {
            name: 'Indigo',
            hex: '4B0082',
            rgb: {
                r: 75,
                g: 0,
                b: 130
            }
        },
        {
            name: 'DarkSlateBlue',
            hex: '483D8B',
            rgb: {
                r: 72,
                g: 61,
                b: 139
            }
        },
        {
            name: 'SlateBlue',
            hex: '6A5ACD',
            rgb: {
                r: 106,
                g: 90,
                b: 205
            }
        },
        {
            name: 'MediumSlateBlue',
            hex: '7B68EE',
            rgb: {
                r: 123,
                g: 104,
                b: 238
            }
        },
        {
            name: 'Pink',
            hex: 'FFC0CB',
            rgb: {
                r: 255,
                g: 192,
                b: 203
            }
        },
        {
            name: 'LightPink',
            hex: 'FFB6C1',
            rgb: {
                r: 255,
                g: 182,
                b: 193
            }
        },
        {
            name: 'HotPink',
            hex: 'FF69B4',
            rgb: {
                r: 255,
                g: 105,
                b: 180
            }
        },
        {
            name: 'DeepPink',
            hex: 'FF1493',
            rgb: {
                r: 255,
                g: 20,
                b: 147
            }
        },
        {
            name: 'PaleVioletRed',
            hex: 'DB7093',
            rgb: {
                r: 219,
                g: 112,
                b: 147
            }
        },
        {
            name: 'MediumVioletRed',
            hex: 'C71585',
            rgb: {
                r: 199,
                g: 21,
                b: 133
            }
        },
        {
            name: 'LightSalmon',
            hex: 'FFA07A',
            rgb: {
                r: 255,
                g: 160,
                b: 122
            }
        },
        {
            name: 'Salmon',
            hex: 'FA8072',
            rgb: {
                r: 250,
                g: 128,
                b: 114
            }
        },
        {
            name: 'DarkSalmon',
            hex: 'E9967A',
            rgb: {
                r: 233,
                g: 150,
                b: 122
            }
        },
        {
            name: 'LightCoral',
            hex: 'F08080',
            rgb: {
                r: 240,
                g: 128,
                b: 128
            }
        },
        {
            name: 'IndianRed',
            hex: 'CD5C5C',
            rgb: {
                r: 205,
                g: 92,
                b: 92
            }
        },
        {
            name: 'Crimson',
            hex: 'DC143C',
            rgb: {
                r: 220,
                g: 20,
                b: 60
            }
        },
        {
            name: 'FireBrick',
            hex: 'B22222',
            rgb: {
                r: 178,
                g: 34,
                b: 34
            }
        },
        {
            name: 'DarkRed',
            hex: '8B0000',
            rgb: {
                r: 139,
                g: 0,
                b: 0
            }
        },
        {
            name: 'Red',
            hex: 'FF0000',
            rgb: {
                r: 255,
                g: 0,
                b: 0
            }
        },
        {
            name: 'OrangeRed',
            hex: 'FF4500',
            rgb: {
                r: 255,
                g: 69,
                b: 0
            }
        },
        {
            name: 'Tomato',
            hex: 'FF6347',
            rgb: {
                r: 255,
                g: 99,
                b: 71
            }
        },
        {
            name: 'Coral',
            hex: 'FF7F50',
            rgb: {
                r: 255,
                g: 127,
                b: 80
            }
        },
        {
            name: 'DarkOrange',
            hex: 'FF8C00',
            rgb: {
                r: 255,
                g: 140,
                b: 0
            }
        },
        {
            name: 'Orange',
            hex: 'FFA500',
            rgb: {
                r: 255,
                g: 165,
                b: 0
            }
        },
        {
            name: 'Yellow',
            hex: 'FFFF00',
            rgb: {
                r: 255,
                g: 255,
                b: 0
            }
        },
        {
            name: 'LightYellow',
            hex: 'FFFFE0',
            rgb: {
                r: 255,
                g: 255,
                b: 224
            }
        },
        {
            name: 'LemonChiffon',
            hex: 'FFFACD',
            rgb: {
                r: 255,
                g: 250,
                b: 205
            }
        },
        {
            name: 'LightGoldenrodYellow',
            hex: 'FAFAD2',
            rgb: {
                r: 250,
                g: 250,
                b: 210
            }
        },
        {
            name: 'PapayaWhip',
            hex: 'FFEFD5',
            rgb: {
                r: 255,
                g: 239,
                b: 213
            }
        },
        {
            name: 'Moccasin',
            hex: 'FFE4B5',
            rgb: {
                r: 255,
                g: 228,
                b: 181
            }
        },
        {
            name: 'PeachPuff',
            hex: 'FFDAB9',
            rgb: {
                r: 255,
                g: 218,
                b: 185
            }
        },
        {
            name: 'PaleGoldenrod',
            hex: 'EEE8AA',
            rgb: {
                r: 238,
                g: 232,
                b: 170
            }
        },
        {
            name: 'Khaki',
            hex: 'F0E68C',
            rgb: {
                r: 240,
                g: 230,
                b: 140
            }
        },
        {
            name: 'DarkKhaki',
            hex: 'BDB76B',
            rgb: {
                r: 189,
                g: 183,
                b: 107
            }
        },
        {
            name: 'Gold',
            hex: 'FFD700',
            rgb: {
                r: 255,
                g: 215,
                b: 0
            }
        },
        {
            name: 'Cornsilk',
            hex: 'FFF8DC',
            rgb: {
                r: 255,
                g: 248,
                b: 220
            }
        },
        {
            name: 'BlanchedAlmond',
            hex: 'FFEBCD',
            rgb: {
                r: 255,
                g: 235,
                b: 205
            }
        },
        {
            name: 'Bisque',
            hex: 'FFE4C4',
            rgb: {
                r: 255,
                g: 228,
                b: 196
            }
        },
        {
            name: 'NavajoWhite',
            hex: 'FFDEAD',
            rgb: {
                r: 255,
                g: 222,
                b: 173
            }
        },
        {
            name: 'Wheat',
            hex: 'F5DEB3',
            rgb: {
                r: 245,
                g: 222,
                b: 179
            }
        },
        {
            name: 'BurlyWood',
            hex: 'DEB887',
            rgb: {
                r: 222,
                g: 184,
                b: 135
            }
        },
        {
            name: 'Tan',
            hex: 'D2B48C',
            rgb: {
                r: 210,
                g: 180,
                b: 140
            }
        },
        {
            name: 'RosyBrown',
            hex: 'BC8F8F',
            rgb: {
                r: 188,
                g: 143,
                b: 143
            }
        },
        {
            name: 'SandyBrown',
            hex: 'F4A460',
            rgb: {
                r: 244,
                g: 164,
                b: 96
            }
        },
        {
            name: 'Goldenrod',
            hex: 'DAA520',
            rgb: {
                r: 218,
                g: 165,
                b: 32
            }
        },
        {
            name: 'DarkGoldenrod',
            hex: 'B8860B',
            rgb: {
                r: 184,
                g: 134,
                b: 11
            }
        },
        {
            name: 'Peru',
            hex: 'CD853F',
            rgb: {
                r: 205,
                g: 133,
                b: 63
            }
        },
        {
            name: 'Chocolate',
            hex: 'D2691E',
            rgb: {
                r: 210,
                g: 105,
                b: 30
            }
        },
        {
            name: 'SaddleBrown',
            hex: '8B4513',
            rgb: {
                r: 139,
                g: 69,
                b: 19
            }
        },
        {
            name: 'Sienna',
            hex: 'A0522D',
            rgb: {
                r: 160,
                g: 82,
                b: 45
            }
        },
        {
            name: 'Brown',
            hex: 'A52A2A',
            rgb: {
                r: 165,
                g: 42,
                b: 42
            }
        },
        {
            name: 'Maroon',
            hex: '800000',
            rgb: {
                r: 128,
                g: 0,
                b: 0
            }
        },
        {
            name: 'DarkOliveGreen',
            hex: '556B2F',
            rgb: {
                r: 85,
                g: 107,
                b: 47
            }
        },
        {
            name: 'Olive',
            hex: '808000',
            rgb: {
                r: 128,
                g: 128,
                b: 0
            }
        },
        {
            name: 'OliveDrab',
            hex: '6B8E23',
            rgb: {
                r: 107,
                g: 142,
                b: 35
            }
        },
        {
            name: 'YellowGreen',
            hex: '9ACD32',
            rgb: {
                r: 154,
                g: 205,
                b: 50
            }
        },
        {
            name: 'LimeGreen',
            hex: '32CD32',
            rgb: {
                r: 50,
                g: 205,
                b: 50
            }
        },
        {
            name: 'Lime',
            hex: '00FF00',
            rgb: {
                r: 0,
                g: 255,
                b: 0
            }
        },
        {
            name: 'LawnGreen',
            hex: '7CFC00',
            rgb: {
                r: 124,
                g: 252,
                b: 0
            }
        },
        {
            name: 'Chartreuse',
            hex: '7FFF00',
            rgb: {
                r: 127,
                g: 255,
                b: 0
            }
        },
        {
            name: 'GreenYellow',
            hex: 'ADFF2F',
            rgb: {
                r: 173,
                g: 255,
                b: 47
            }
        },
        {
            name: 'SpringGreen',
            hex: '00FF7F',
            rgb: {
                r: 0,
                g: 255,
                b: 127
            }
        },
        {
            name: 'MediumSpringGreen',
            hex: '00FA9A',
            rgb: {
                r: 0,
                g: 250,
                b: 154
            }
        },
        {
            name: 'LightGreen',
            hex: '90EE90',
            rgb: {
                r: 144,
                g: 238,
                b: 144
            }
        },
        {
            name: 'PaleGreen',
            hex: '98FB98',
            rgb: {
                r: 152,
                g: 251,
                b: 152
            }
        },
        {
            name: 'DarkSeaGreen',
            hex: '8FBC8F',
            rgb: {
                r: 143,
                g: 188,
                b: 143
            }
        },
        {
            name: 'MediumSeaGreen',
            hex: '3CB371',
            rgb: {
                r: 60,
                g: 179,
                b: 113
            }
        },
        {
            name: 'SeaGreen',
            hex: '2E8B57',
            rgb: {
                r: 46,
                g: 139,
                b: 87
            }
        },
        {
            name: 'ForestGreen',
            hex: '228B22',
            rgb: {
                r: 34,
                g: 139,
                b: 34
            }
        },
        {
            name: 'Green',
            hex: '008000',
            rgb: {
                r: 0,
                g: 128,
                b: 0
            }
        },
        {
            name: 'DarkGreen',
            hex: '006400',
            rgb: {
                r: 0,
                g: 100,
                b: 0
            }
        },
        {
            name: 'MediumAquamarine',
            hex: '66CDAA',
            rgb: {
                r: 102,
                g: 205,
                b: 170
            }
        },
        {
            name: 'Aqua',
            hex: '00FFFF',
            rgb: {
                r: 0,
                g: 255,
                b: 255
            }
        },
        {
            name: 'Cyan',
            hex: '00FFFF',
            rgb: {
                r: 0,
                g: 255,
                b: 255
            }
        },
        {
            name: 'LightCyan',
            hex: 'E0FFFF',
            rgb: {
                r: 224,
                g: 255,
                b: 255
            }
        },
        {
            name: 'PaleTurquoise',
            hex: 'AFEEEE',
            rgb: {
                r: 175,
                g: 238,
                b: 238
            }
        },
        {
            name: 'Aquamarine',
            hex: '7FFFD4',
            rgb: {
                r: 127,
                g: 255,
                b: 212
            }
        },
        {
            name: 'Turquoise',
            hex: '40E0D0',
            rgb: {
                r: 64,
                g: 224,
                b: 208
            }
        },
        {
            name: 'MediumTurquoise',
            hex: '48D1CC',
            rgb: {
                r: 72,
                g: 209,
                b: 204
            }
        },
        {
            name: 'DarkTurquoise',
            hex: '00CED1',
            rgb: {
                r: 0,
                g: 206,
                b: 209
            }
        },
        {
            name: 'LightSeaGreen',
            hex: '20B2AA',
            rgb: {
                r: 32,
                g: 178,
                b: 170
            }
        },
        {
            name: 'CadetBlue',
            hex: '5F9EA0',
            rgb: {
                r: 95,
                g: 158,
                b: 160
            }
        },
        {
            name: 'DarkCyan',
            hex: '008B8B',
            rgb: {
                r: 0,
                g: 139,
                b: 139
            }
        },
        {
            name: 'Teal',
            hex: '008080',
            rgb: {
                r: 0,
                g: 128,
                b: 128
            }
        },
        {
            name: 'LightSteelBlue',
            hex: 'B0C4DE',
            rgb: {
                r: 176,
                g: 196,
                b: 222
            }
        },
        {
            name: 'PowderBlue',
            hex: 'B0E0E6',
            rgb: {
                r: 176,
                g: 224,
                b: 230
            }
        },
        {
            name: 'LightBlue',
            hex: 'ADD8E6',
            rgb: {
                r: 173,
                g: 216,
                b: 230
            }
        },
        {
            name: 'SkyBlue',
            hex: '87CEEB',
            rgb: {
                r: 135,
                g: 206,
                b: 235
            }
        },
        {
            name: 'LightSkyBlue',
            hex: '87CEFA',
            rgb: {
                r: 135,
                g: 206,
                b: 250
            }
        },
        {
            name: 'DeepSkyBlue',
            hex: '00BFFF',
            rgb: {
                r: 0,
                g: 191,
                b: 255
            }
        },
        {
            name: 'DodgerBlue',
            hex: '1E90FF',
            rgb: {
                r: 30,
                g: 144,
                b: 255
            }
        },
        {
            name: 'CornflowerBlue',
            hex: '6495ED',
            rgb: {
                r: 100,
                g: 149,
                b: 237
            }
        },
        {
            name: 'SteelBlue',
            hex: '4682B4',
            rgb: {
                r: 70,
                g: 130,
                b: 180
            }
        },
        {
            name: 'RoyalBlue',
            hex: '4169E1',
            rgb: {
                r: 65,
                g: 105,
                b: 225
            }
        },
        {
            name: 'Blue',
            hex: '0000FF',
            rgb: {
                r: 0,
                g: 0,
                b: 255
            }
        },
        {
            name: 'MediumBlue',
            hex: '0000CD',
            rgb: {
                r: 0,
                g: 0,
                b: 205
            }
        },
        {
            name: 'DarkBlue',
            hex: '00008B',
            rgb: {
                r: 0,
                g: 0,
                b: 139
            }
        },
        {
            name: 'Navy',
            hex: '000080',
            rgb: {
                r: 0,
                g: 0,
                b: 128
            }
        },
        {
            name: 'MidnightBlue',
            hex: '191970',
            rgb: {
                r: 25,
                g: 25,
                b: 112
            }
        },
        {
            name: 'White',
            hex: 'FFFFFF',
            rgb: {
                r: 255,
                g: 255,
                b: 255
            }
        },
        {
            name: 'Snow',
            hex: 'FFFAFA',
            rgb: {
                r: 255,
                g: 250,
                b: 250
            }
        },
        {
            name: 'Honeydew',
            hex: 'F0FFF0',
            rgb: {
                r: 240,
                g: 255,
                b: 240
            }
        },
        {
            name: 'MintCream',
            hex: 'F5FFFA',
            rgb: {
                r: 245,
                g: 255,
                b: 250
            }
        },
        {
            name: 'Azure',
            hex: 'F0FFFF',
            rgb: {
                r: 240,
                g: 255,
                b: 255
            }
        },
        {
            name: 'AliceBlue',
            hex: 'F0F8FF',
            rgb: {
                r: 240,
                g: 248,
                b: 255
            }
        },
        {
            name: 'GhostWhite',
            hex: 'F8F8FF',
            rgb: {
                r: 248,
                g: 248,
                b: 255
            }
        },
        {
            name: 'WhiteSmoke',
            hex: 'F5F5F5',
            rgb: {
                r: 245,
                g: 245,
                b: 245
            }
        },
        {
            name: 'Seashell',
            hex: 'FFF5EE',
            rgb: {
                r: 255,
                g: 245,
                b: 238
            }
        },
        {
            name: 'Beige',
            hex: 'F5F5DC',
            rgb: {
                r: 245,
                g: 245,
                b: 220
            }
        },
        {
            name: 'OldLace',
            hex: 'FDF5E6',
            rgb: {
                r: 253,
                g: 245,
                b: 230
            }
        },
        {
            name: 'FloralWhite',
            hex: 'FFFAF0',
            rgb: {
                r: 255,
                g: 250,
                b: 240
            }
        },
        {
            name: 'Ivory',
            hex: 'FFFFF0',
            rgb: {
                r: 255,
                g: 255,
                b: 240
            }
        },
        {
            name: 'AntiqueWhite',
            hex: 'FAEBD7',
            rgb: {
                r: 250,
                g: 235,
                b: 215
            }
        },
        {
            name: 'Linen',
            hex: 'FAF0E6',
            rgb: {
                r: 250,
                g: 240,
                b: 230
            }
        },
        {
            name: 'LavenderBlush',
            hex: 'FFF0F5',
            rgb: {
                r: 255,
                g: 240,
                b: 245
            }
        },
        {
            name: 'MistyRose',
            hex: 'FFE4E1',
            rgb: {
                r: 255,
                g: 228,
                b: 225
            }
        },
        {
            name: 'Gainsboro',
            hex: 'DCDCDC',
            rgb: {
                r: 220,
                g: 220,
                b: 220
            }
        },
        {
            name: 'LightGray',
            hex: 'D3D3D3',
            rgb: {
                r: 211,
                g: 211,
                b: 211
            }
        },
        {
            name: 'Silver',
            hex: 'C0C0C0',
            rgb: {
                r: 192,
                g: 192,
                b: 192
            }
        },
        {
            name: 'DarkGray',
            hex: 'A9A9A9',
            rgb: {
                r: 169,
                g: 169,
                b: 169
            }
        },
        {
            name: 'Gray',
            hex: '808080',
            rgb: {
                r: 128,
                g: 128,
                b: 128
            }
        },
        {
            name: 'DimGray',
            hex: '696969',
            rgb: {
                r: 105,
                g: 105,
                b: 105
            }
        },
        {
            name: 'LightSlateGray',
            hex: '778899',
            rgb: {
                r: 119,
                g: 136,
                b: 153
            }
        },
        {
            name: 'SlateGray',
            hex: '708090',
            rgb: {
                r: 112,
                g: 128,
                b: 144
            }
        },
        {
            name: 'DarkSlateGray',
            hex: '2F4F4F',
            rgb: {
                r: 47,
                g: 79,
                b: 79
            }
        },
        {
            name: 'Black',
            hex: '000000',
            rgb: {
                r: 0,
                g: 0,
                b: 0
            }
        }
    ]; }
}

class CodebookDocxGenerator {
    static { this.ommlCache = {}; }
    static async generateDocx(codingBookUnits, contentSetting) {
        const units = [];
        const missingDefinitions = new Map();
        codingBookUnits.forEach(unit => {
            unit.missings.forEach(missing => missingDefinitions.set(JSON.stringify(missing), missing));
            if (unit.variables.length) {
                units.push(...this.createDocXForUnit(unit.items || [], unit.variables, contentSetting, this.getUnitHeader(unit)));
            }
        });
        const missings = this.getMissings({
            key: '', name: '', variables: [], missings: [...missingDefinitions.values()]
        });
        return Packer.toBlob(this.setDocXDocument(units, missings));
    }
    static getUnitHeader(variableCoding) {
        return new Paragraph({
            border: {
                bottom: {
                    color: '#000000',
                    style: 'single',
                    size: 10
                },
                top: {
                    color: '#000000',
                    style: 'single',
                    size: 10
                }
            },
            spacing: {
                after: 200
            },
            text: `${variableCoding.key}  ${variableCoding.name}`,
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER
        });
    }
    static getMissings(variableCoding) {
        const missings = [];
        try {
            variableCoding.missings.forEach(missing => {
                if (missing.code !== undefined && missing.code !== null && `${missing.code}` !== '' && missing.label && missing.description) {
                    missings.push(new Paragraph({
                        children: [
                            new TextRun({
                                text: `${missing.code} ${missing.label}`,
                                bold: true
                            })
                        ],
                        spacing: {
                            after: 20
                        }
                    }));
                    missings.push(new Paragraph({
                        text: `${missing.description}`,
                        spacing: {
                            after: 100
                        }
                    }));
                }
                else {
                    missings.push(new Paragraph({
                        text: 'kein valides Missing ',
                        spacing: {
                            after: 200
                        }
                    }));
                }
            });
        }
        catch {
            missings.push(new Paragraph({
                text: 'kein validen Missings gefunden',
                spacing: {
                    after: 200
                }
            }));
        }
        return missings;
    }
    static get TableBoarders() {
        return {
            top: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            bottom: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            left: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            right: {
                size: 1,
                color: '#000000',
                style: 'single'
            }
        };
    }
    static getCodeRows(variable, contentSetting) {
        return variable.codes.map(code => new TableRow({
            cantSplit: true,
            children: [
                CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.id), CodebookDocxGenerator.getColumnWidths(contentSetting)[0]),
                CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.label), CodebookDocxGenerator.getColumnWidths(contentSetting)[1]),
                ...(contentSetting.showScore ?
                    [
                        CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.score ?? ''), CodebookDocxGenerator.getColumnWidths(contentSetting)[2])
                    ] :
                    []),
                CodebookDocxGenerator.createCodeCell([...CodebookDocxGenerator.htmlToDocx(code.description, contentSetting)], CodebookDocxGenerator.getColumnWidths(contentSetting)[CodebookDocxGenerator.getColumnWidths(contentSetting).length - 1])
            ]
        }));
    }
    static createCellChildren(value) {
        return [
            new Paragraph({
                text: value,
                spacing: {
                    before: 100,
                    after: 100
                },
                indent: { start: 100, end: 100 }
            })
        ];
    }
    static createCodeCell(children, width) {
        return new TableCell({
            borders: CodebookDocxGenerator.TableBoarders,
            children: children,
            // Need for Word, but not for Writer
            width: {
                size: width,
                type: WidthType.PERCENTAGE
            }
        });
    }
    static setDocXDocument(units, missings) {
        return new Document({
            background: {
                color: '#FFFFFF'
            },
            sections: [
                {
                    properties: {
                        page: {
                            pageNumbers: {
                                start: 1,
                                formatType: NumberFormat.DECIMAL
                            }
                        }
                    },
                    footers: {
                        default: new Footer({
                            children: [
                                new Paragraph({
                                    alignment: AlignmentType.CENTER,
                                    children: [
                                        new TextRun('IQB Codebook '),
                                        new TextRun(new Date().toLocaleDateString())
                                    ]
                                }),
                                new Paragraph({
                                    alignment: AlignmentType.CENTER,
                                    children: [
                                        new TextRun({
                                            color: '000000',
                                            children: [' Seite ', PageNumber.CURRENT]
                                        }),
                                        new TextRun({
                                            color: '000000',
                                            children: [' von ', PageNumber.TOTAL_PAGES]
                                        })
                                    ]
                                })
                            ]
                        })
                    },
                    children: [...missings, ...units]
                }
            ]
        });
    }
    static getVariableHeader(variable) {
        return new Paragraph({
            text: `${variable.id}  ${variable.label}`,
            heading: HeadingLevel.HEADING_2,
            alignment: AlignmentType.LEFT,
            spacing: {
                before: 200,
                after: 200
            }
        });
    }
    static getVariableItems(variable, varItems) {
        const filteredVarItems = varItems.filter(item => item.variableId === variable.id);
        let itemString = '';
        filteredVarItems.forEach(item => {
            itemString += `${item.id}   `;
        });
        if (filteredVarItems.length === 0) {
            return [];
        }
        return [new Paragraph({
                text: `Item(s): ${itemString}`,
                heading: HeadingLevel.HEADING_3,
                alignment: AlignmentType.LEFT,
                spacing: {
                    before: 200,
                    after: 200
                }
            })];
    }
    static getGeneralInstructions(contentSetting, codeBookVariable) {
        return contentSetting.hasGeneralInstructions ?
            CodebookDocxGenerator.htmlToDocx(codeBookVariable.generalInstruction, contentSetting) :
            [];
    }
    static getCodeTable(codeBookVariable, contentSetting) {
        return new Table({
            rows: CodebookDocxGenerator.getCodeRows(codeBookVariable, contentSetting),
            width: {
                size: 100,
                type: WidthType.PERCENTAGE
            },
            columnWidths: CodebookDocxGenerator.getColumnWidths(contentSetting) // Need for Writer, but not for Word
        });
    }
    static getColumnWidths(contentSetting) {
        return contentSetting.showScore ? [8, 24, 8, 60] : [8, 24, 68];
    }
    static getVariables(codeBookVariable, contentSetting, varItems) {
        const variables = [];
        codeBookVariable.forEach(variable => {
            variables.push(...[
                CodebookDocxGenerator.getVariableHeader(variable),
                ...(contentSetting.hideItemVarRelation ? [] : CodebookDocxGenerator.getVariableItems(variable, varItems)),
                ...CodebookDocxGenerator.getGeneralInstructions(contentSetting, variable),
                CodebookDocxGenerator.getCodeTable(variable, contentSetting)
            ]);
        });
        return variables;
    }
    static createDocXForUnit(varItems, codeBookVariable, contentSetting, unitHeader) {
        return [
            unitHeader,
            ...CodebookDocxGenerator.getVariables(codeBookVariable, contentSetting, varItems),
            new Paragraph({
                text: '',
                spacing: {
                    before: 100,
                    after: 100
                }
            })
        ];
    }
    static getChildren(cheerioAPI, elem) {
        return cheerioAPI(elem).toArray();
    }
    static processInlineElements(nodes, children, colorParsed, backgroundColor, size, formatting = {}, imageWidth = 334) {
        const runStyle = {
            ...formatting,
            color: colorParsed,
            shading: { fill: backgroundColor },
            size: CodebookDocxGenerator.getFontSize(size)
        };
        nodes.forEach(node => {
            if (node.type === 'text') {
                // Preserve non-breaking spaces and repeated spacing from Studio instructions.
                node.data.split('\n').forEach((line, index) => {
                    if (index)
                        children.push(new TextRun({ break: 1, ...runStyle }));
                    if (line)
                        children.push(new TextRun({ text: line, ...runStyle }));
                });
                return;
            }
            if (node.type !== 'tag')
                return;
            const element = node;
            const tagName = element.name.toLowerCase();
            const styles = CodebookDocxGenerator.inlineStyles(element);
            const nestedColor = CodebookDocxGenerator.cssColor(styles['color'], colorParsed);
            const nestedBackground = CodebookDocxGenerator.cssColor(styles['background-color'], backgroundColor);
            const nestedSize = styles['font-size'] || size;
            if ((tagName === 'span' && element.attribs?.['class']?.split(/\s+/).includes('iqb-math-formula')) ||
                tagName === 'aspect-nodeview-math-formula') {
                const storedLatex = element.attribs?.['data-latex'] || element.attribs?.['formula'] || '';
                const latex = CodebookDocxGenerator.decodeLatex(storedLatex).trim();
                if (latex) {
                    const mathStyle = {
                        ...formatting,
                        size: CodebookDocxGenerator.getFontSize(nestedSize),
                        color: nestedColor,
                        shading: { fill: nestedBackground }
                    };
                    children.push(CodebookDocxGenerator.latexToOmml(latex, mathStyle) || new TextRun({ text: latex, ...mathStyle }));
                }
                return;
            }
            if (tagName === 'img') {
                try {
                    const fontPixels = (CodebookDocxGenerator.getFontSize(size) * 2) / 3;
                    children.push(CodebookDocxGenerator.createImageRun(element, imageWidth, fontPixels));
                }
                catch {
                    // An invalid image must not discard the surrounding instruction paragraph.
                    children.push(new TextRun({ text: 'HTML konnte nicht verarbeitet werden.', ...runStyle }));
                }
                return;
            }
            if (tagName === 'br') {
                children.push(new TextRun({ break: 1, ...runStyle }));
                return;
            }
            const nestedFormatting = { ...formatting };
            if (tagName === 'strong' || tagName === 'b')
                nestedFormatting.bold = true;
            if (tagName === 'em' || tagName === 'i')
                nestedFormatting.italics = true;
            if (tagName === 'u')
                nestedFormatting.underline = {};
            if (tagName === 's' || tagName === 'strike')
                nestedFormatting.strike = true;
            if (tagName === 'sub') {
                nestedFormatting.subScript = true;
                nestedFormatting.superScript = false;
            }
            if (tagName === 'sup') {
                nestedFormatting.superScript = true;
                nestedFormatting.subScript = false;
            }
            CodebookDocxGenerator.processInlineElements(element.children, children, nestedColor, nestedBackground, nestedSize, nestedFormatting, imageWidth);
        });
    }
    static getImageSize(imageBuffer) {
        const size = imageSize(imageBuffer);
        if (!size.width || !size.height)
            throw new Error('Ungültige Bildgröße');
        return { width: size.width, height: size.height };
    }
    static getTransformation(actualSize, max) {
        const transformedSize = {
            width: actualSize.width,
            height: actualSize.height
        };
        const maxWidth = max;
        const maxHeight = max;
        if (actualSize.width > maxWidth || actualSize.height > maxHeight) {
            const ratio = Math.min(maxWidth / actualSize.width, maxHeight / actualSize.height);
            transformedSize.width = actualSize.width * ratio;
            transformedSize.height = actualSize.height * ratio;
        }
        return transformedSize;
    }
    static createImagePragraph(elem, contentSetting) {
        return new Paragraph({
            spacing: {
                before: 100,
                after: 100
            },
            indent: {
                start: 100,
                end: 100
            },
            children: [
                CodebookDocxGenerator.createImageRun(elem, contentSetting.showScore ? 334 : 382)
            ]
        });
    }
    static createImageRun(elem, maxWidth, fontPixels = 20) {
        const source = elem.attribs['src'] || '';
        const imageBuffer = Buffer.from(source.substring(source.indexOf(',') + 1), 'base64');
        const actual = CodebookDocxGenerator.getImageSize(imageBuffer);
        const styles = CodebookDocxGenerator.inlineStyles(elem);
        let height = actual.height;
        if (styles['height'] === '1em')
            height = fontPixels;
        else if (/^\d+(\.\d+)?px$/.test(styles['height'] || ''))
            height = parseFloat(styles['height']);
        const width = /^\d+(\.\d+)?px$/.test(styles['width'] || '') ?
            parseFloat(styles['width']) : (actual.width * height) / actual.height;
        const side = styles['float'];
        return new ImageRun({
            data: imageBuffer,
            transformation: CodebookDocxGenerator.getTransformation({ width, height }, maxWidth),
            ...(side === 'left' || side === 'right' ? {
                floating: {
                    horizontalPosition: {
                        relative: HorizontalPositionRelativeFrom.COLUMN,
                        align: side === 'left' ? HorizontalPositionAlign.LEFT : HorizontalPositionAlign.RIGHT
                    },
                    verticalPosition: { relative: VerticalPositionRelativeFrom.PARAGRAPH, offset: 0 },
                    layoutInCell: true,
                    allowOverlap: false,
                    wrap: {
                        type: TextWrappingType.SQUARE,
                        side: side === 'left' ? TextWrappingSide.RIGHT : TextWrappingSide.LEFT,
                        margins: { [side === 'left' ? 'right' : 'left']: 9525 * 10 }
                    }
                }
            } : {})
        });
    }
    static inlineStyles(elem) {
        return Object.fromEntries((elem.attribs['style'] || '').split(';').flatMap(declaration => {
            const colon = declaration.indexOf(':');
            if (colon < 0)
                return [];
            const property = declaration.substring(0, colon).trim().toLowerCase();
            const value = declaration.substring(colon + 1).trim();
            return [[property, value]];
        }));
    }
    static cssColor(value, fallback) {
        if (!value || value === 'inherit' || value === 'initial' || value === 'currentColor')
            return fallback;
        if (/^#[0-9a-f]{6}$/i.test(value))
            return value.substring(1).toUpperCase();
        if (/^#[0-9a-f]{3}$/i.test(value)) {
            return value.substring(1).split('').map(part => part + part).join('')
                .toUpperCase();
        }
        if (value.startsWith('rgb')) {
            const rgb = CodebookDocxGenerator.parseCssRgbString(value);
            if (rgb?.length === 3 && rgb.every(component => Number.isFinite(component))) {
                return CodebookDocxGenerator.toHex(rgb[0], rgb[1], rgb[2]).toUpperCase();
            }
        }
        return WebColors.getHexFromWebColor(value.toLowerCase())?.replace(/^#/, '').toUpperCase() || fallback;
    }
    static getTextAlignment(cheerioAPI, elem) {
        return cheerioAPI(elem).css('text-align') || 'left';
    }
    static stripFromLeadingEmptyParagraph(html) {
        return html.replace(/^<p><\/p>/, '');
    }
    static prepareHtml(html) {
        // Newlines in LaTeX/HTML attributes are data, not paragraph breaks.
        return CodebookDocxGenerator.stripFromLeadingEmptyParagraph(html);
    }
    static decodeLatex(latex) {
        if (!latex)
            return '';
        try {
            return decodeURIComponent(latex);
        }
        catch {
            return latex;
        }
    }
    static latexToOmml(latex, style) {
        const trimmed = latex.trim();
        if (!trimmed)
            return null;
        try {
            if (!CodebookDocxGenerator.ommlCache[trimmed]) {
                const mathml = katex.renderToString(trimmed, {
                    output: 'mathml',
                    throwOnError: false,
                    strict: 'ignore'
                });
                CodebookDocxGenerator.ommlCache[trimmed] = CodebookDocxGenerator.normalizeStretchyBars(mathml, mml2omml(mathml));
            }
            const omml = CodebookDocxGenerator.styleMathRuns(CodebookDocxGenerator.ommlCache[trimmed], style);
            return CodebookDocxGenerator.unwrapImportedXmlRoot(ImportedXmlComponent.fromXmlString(CodebookDocxGenerator.sanitizeOmmlXml(omml)));
        }
        catch {
            return null;
        }
    }
    /** The converter treats wide over/underlines as fixed-width accents and loses their position. */
    static normalizeStretchyBars(mathml, omml) {
        const math = cheerio.load(mathml, { xml: true }, false);
        const positions = [];
        math('mover,munder').each((_, node) => {
            const operator = math(node).children().last();
            if (operator[0]?.name === 'mo' && operator.text() === '\u203e') {
                let position;
                if (operator.attr('stretchy') !== 'false')
                    position = node.name === 'munder' ? 'bot' : 'top';
                positions.push(position);
            }
        });
        if (!positions.some(position => position))
            return omml;
        const $ = cheerio.load(omml, { xml: true }, false);
        let index = 0;
        $('m\\:acc').each((_, node) => {
            const accent = $(node);
            if (accent.children('m\\:accPr').children('m\\:chr').attr('m:val') !== '\u203e')
                return;
            const position = positions[index];
            index += 1;
            if (!position)
                return;
            const bar = $('<m:bar/>');
            const properties = $('<m:barPr/>').append(`<m:pos m:val="${position}"/>`);
            properties.append(accent.children('m\\:accPr').children('m\\:ctrlPr'));
            bar.append(properties).append(accent.children('m\\:e'));
            accent.replaceWith(bar);
        });
        return $.xml();
    }
    /** Apply surrounding editor marks without changing cached LaTeX or unstyled Studio math. */
    static styleMathRuns(omml, style) {
        if (!style)
            return omml;
        const properties = {};
        if (style.bold)
            properties['b'] = {};
        if (style.italics)
            properties['i'] = {};
        if (style.underline)
            properties['u'] = { 'w:val': 'single' };
        if (style.strike)
            properties['strike'] = {};
        if (style.size !== 20) {
            properties['sz'] = { 'w:val': String(style.size) };
            properties['szCs'] = { 'w:val': String(style.size) };
        }
        if (style.color && !['#000000', '000000'].includes(style.color)) {
            properties['color'] = { 'w:val': style.color.replace(/^#/, '') };
        }
        const fill = style.shading?.fill;
        if (fill && !['#FFFFFF', 'FFFFFF'].includes(fill))
            properties['shd'] = { 'w:fill': fill.replace(/^#/, '') };
        if (!Object.keys(properties).length)
            return omml;
        const $ = cheerio.load(omml, { xml: true }, false);
        const applyProperties = (parent) => {
            let runProperties = parent.children('w\\:rPr').first();
            if (!runProperties.length) {
                parent.append('<w:rPr/>');
                runProperties = parent.children('w\\:rPr').first();
            }
            Object.entries(properties).forEach(([name, attributes]) => {
                runProperties.children(`w\\:${name}`).remove();
                runProperties.append(`<w:${name}/>`);
                runProperties.children(`w\\:${name}`).last().attr(attributes);
            });
            const order = ['b', 'bCs', 'i', 'iCs', 'strike', 'color', 'sz', 'szCs', 'u', 'shd'];
            const children = runProperties.children().toArray().sort((a, b) => (order.indexOf(a.name.substring(2)) - order.indexOf(b.name.substring(2))));
            runProperties.empty().append(children);
        };
        $('m\\:r').each((_, run) => {
            const element = $(run);
            applyProperties(element);
            element.prepend(element.children('w\\:rPr').remove());
            const mathProperties = element.children('m\\:rPr').remove();
            if (mathProperties.length)
                element.prepend(mathProperties);
        });
        // Math control properties also style fraction bars, radicals and large operators.
        ['acc', 'bar', 'borderBox', 'box', 'd', 'eqArr', 'f', 'func', 'groupChr',
            'limLow', 'limUpp', 'm', 'nary', 'phant', 'rad', 'sPre', 'sSub', 'sSubSup', 'sSup'].forEach(name => {
            $(`m\\:${name}`).each((_, node) => {
                const element = $(node);
                let structureProperties = element.children(`m\\:${name}Pr`).first();
                if (!structureProperties.length) {
                    element.prepend(`<m:${name}Pr/>`);
                    structureProperties = element.children(`m\\:${name}Pr`).first();
                }
                let control = structureProperties.children('m\\:ctrlPr').first();
                if (!control.length) {
                    structureProperties.append('<m:ctrlPr/>');
                    control = structureProperties.children('m\\:ctrlPr').first();
                }
                applyProperties(control);
            });
        });
        return $.xml();
    }
    static unwrapImportedXmlRoot(component) {
        const importedComponent = component;
        if (importedComponent.rootKey !== undefined) {
            return component;
        }
        const firstChild = importedComponent.root?.[0];
        return typeof firstChild === 'object' && firstChild !== null ?
            firstChild :
            component;
    }
    static isMathComponent(child) {
        if (typeof child !== 'object' || child === null) {
            return false;
        }
        const importedChild = child;
        return importedChild.rootKey === 'm:oMath' ||
            importedChild.rootKey === 'm:oMathPara';
    }
    static createLeftAlignedMathParagraph(mathChildren, alignment = 'left') {
        const mathParagraph = new ImportedXmlComponent('m:oMathPara');
        const mathParagraphProperties = new ImportedXmlComponent('m:oMathParaPr');
        mathParagraphProperties.push(new ImportedXmlComponent('m:jc', { 'm:val': ['center', 'right'].includes(alignment) ? alignment : 'left' }));
        mathParagraph.push(mathParagraphProperties);
        mathChildren.forEach(mathChild => mathParagraph.push(mathChild));
        return mathParagraph;
    }
    static normalizeParagraphChildren(children, alignment = 'left') {
        if (!children.length) {
            return children;
        }
        const mathChildren = children.filter(CodebookDocxGenerator.isMathComponent);
        if (mathChildren.length === children.length) {
            return [CodebookDocxGenerator.createLeftAlignedMathParagraph(mathChildren, alignment)];
        }
        return children;
    }
    static sanitizeOmmlXml(omml) {
        if (!omml)
            return omml;
        return omml.replace(/(<m:t\b[^>]*>)([\s\S]*?)(<\/m:t>)/g, (_, prefix, rawText, suffix) => `${prefix}${CodebookDocxGenerator.escapeXmlText(rawText)}${suffix}`);
    }
    static escapeXmlText(text) {
        return text
            .replace(/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    static normalizeMathTokens(html) {
        return html.replace(/\[\[iqb-math:([\s\S]*?)]]/g, (_, encodedFormula) => {
            const latex = this.decodeLatex(encodedFormula);
            const escapedLatex = latex.replace(/"/g, '&quot;');
            return `<span class="iqb-math-formula" data-latex="${escapedLatex}"></span>`;
        });
    }
    /** Put loose text and inline marks into paragraphs without duplicating existing blocks. */
    static wrapInlineParagraphs(cheerioAPI, parent) {
        let inlineNodes = [];
        const flush = () => {
            if (inlineNodes.some(node => node.type === 'tag' || (node.type === 'text' && node.data.trim()))) {
                cheerioAPI(inlineNodes).wrapAll('<p></p>');
            }
            inlineNodes = [];
        };
        cheerioAPI(parent).contents().toArray().forEach(node => {
            if (node.type === 'tag' && (/^(p|h[1-4]|img|hr|ul|ol|li|div|blockquote)$/.test(node.name) ||
                cheerioAPI(node).find('p,h1,h2,h3,h4,img,hr,ul,ol').length > 0)) {
                flush();
                if (!/^(p|h[1-4]|img|hr)$/.test(node.name)) {
                    CodebookDocxGenerator.wrapInlineParagraphs(cheerioAPI, node);
                }
            }
            else if (node.type === 'text' || node.type === 'tag') {
                inlineNodes.push(node);
            }
        });
        flush();
    }
    static htmlToDocx(html, contentSetting) {
        if (!html.trim())
            return [];
        const normalizedHtml = CodebookDocxGenerator.normalizeMathTokens(html);
        const blockHtml = /<(p|h[1-4]|img|hr|ul|ol)\b/i.test(normalizedHtml) ? normalizedHtml : `<p>${normalizedHtml}</p>`;
        const cheerioAPI = cheerio.load(CodebookDocxGenerator.prepareHtml(blockHtml), null, false);
        CodebookDocxGenerator.wrapInlineParagraphs(cheerioAPI, cheerioAPI.root()[0]);
        const elements = [];
        const walk = (parent, context) => {
            cheerioAPI(parent).contents().toArray().forEach(node => {
                if (node.type !== 'tag')
                    return;
                const elem = node;
                const styles = CodebookDocxGenerator.inlineStyles(elem);
                const size = styles['font-size'] || context.size;
                const color = CodebookDocxGenerator.cssColor(styles['color'], context.color);
                const background = CodebookDocxGenerator.cssColor(styles['background-color'], context.background);
                const inherited = {
                    ...context, size, color, background
                };
                try {
                    if (elem.name === 'img') {
                        elements.push(CodebookDocxGenerator.createImagePragraph(elem, contentSetting));
                    }
                    else if (/^(p|h[1-4])$/.test(elem.name)) {
                        const headingSize = {
                            h1: '20px', h2: '18px', h3: '16px', h4: '16px'
                        }[elem.name];
                        elements.push(CodebookDocxGenerator.createParagraph(cheerioAPI, elem.children, CodebookDocxGenerator.getTextAlignment(cheerioAPI, elem), color, background, styles['font-size'] || headingSize || size, !!context.legacyBullet, {
                            element: elem,
                            marker: context.marker,
                            listDepth: context.listDepth,
                            listIndent: context.listIndent,
                            quoteDepth: context.quoteDepth,
                            imageWidth: contentSetting.showScore ? 334 : 382
                        }));
                        context.marker = undefined;
                        context.legacyBullet = false;
                    }
                    else if (elem.name === 'ul' || elem.name === 'ol') {
                        const style = styles['list-style-type'] || styles['list-style'] || (elem.name === 'ol' ? 'decimal' : 'disc');
                        const legacy = elem.name === 'ul' && !styles['list-style-type'] &&
                            !styles['list-style'] && context.listNesting === 0;
                        const parsedStart = Number.parseInt(elem.attribs['start'], 10);
                        const start = Number.isFinite(parsedStart) ? parsedStart : 1;
                        cheerioAPI(elem).children('li').toArray().forEach((li, index) => {
                            const padding = parseFloat(CodebookDocxGenerator.inlineStyles(li)['padding-left']) || 0;
                            walk(li, {
                                ...inherited,
                                marker: legacy ? undefined : CodebookDocxGenerator.listMarker(style, start + index),
                                legacyBullet: legacy,
                                listDepth: legacy ? 0 : context.listNesting + 1,
                                listNesting: context.listNesting + 1,
                                listIndent: context.listIndent + Math.round(padding * 15)
                            });
                        });
                    }
                    else if (elem.name === 'hr') {
                        const short = styles['width'] === '20%' || elem.attribs['short'] === 'true';
                        elements.push(new Paragraph({
                            border: { bottom: { color: '000000', style: 'single', size: 6 } },
                            indent: short ? { end: Math.round((contentSetting.showScore ? 334 : 382) * 15 * 0.8) } : undefined,
                            spacing: { before: 100, after: 100 }
                        }));
                    }
                    else {
                        walk(elem, { ...inherited, quoteDepth: context.quoteDepth + Number(elem.name === 'blockquote') });
                    }
                }
                catch {
                    elements.push(new Paragraph({ text: 'HTML konnte nicht verarbeitet werden.' }));
                }
            });
        };
        walk(cheerioAPI.root()[0], {
            listDepth: 0,
            listNesting: 0,
            listIndent: 0,
            quoteDepth: 0,
            size: '10pt',
            color: '#000000',
            background: '#FFFFFF'
        });
        return elements.filter(e => e !== undefined && e !== null);
    }
    /** Literal markers retain all CSS list styles, including Greek, in a static Word export. */
    static listMarker(style, value) {
        const bullets = { disc: '•', circle: '○', square: '▪' };
        if (bullets[style])
            return bullets[style];
        if (style.includes('roman')) {
            let remainder = Math.min(10000, Math.max(1, Math.floor(value)));
            let roman = '';
            const numbers = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'],
                [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
            numbers.forEach(([number, symbol]) => {
                while (remainder >= number) {
                    roman += symbol;
                    remainder -= number;
                }
            });
            return `${style.startsWith('lower') ? roman.toLowerCase() : roman}.`;
        }
        if (['lower-latin', 'upper-latin', 'lower-alpha', 'upper-alpha', 'lower-greek'].includes(style)) {
            const alphabet = style === 'lower-greek' ? 'αβγδεζηθικλμνξοπρστυφχψω' : 'abcdefghijklmnopqrstuvwxyz';
            let number = Math.max(1, Math.floor(value));
            let marker = '';
            while (number > 0) {
                number -= 1;
                marker = alphabet[number % alphabet.length] + marker;
                number = Math.floor(number / alphabet.length);
            }
            return `${style.startsWith('upper') ? marker.toUpperCase() : marker}.`;
        }
        return `${value}.`;
    }
    static getFontSize(size) {
        const sizeTypes = [
            'xx-small',
            'x-small',
            'small',
            'medium',
            'large',
            'x-large',
            'xx-large'
        ];
        if (sizeTypes.includes(size))
            return 20;
        const number = parseFloat(size);
        if (!Number.isFinite(number) || number <= 0)
            return 20;
        // CSS pixels are 1/96 inch; Word stores font sizes in half-points (1/144 inch).
        return Math.max(1, Math.min(1638, Math.round(number * (size.endsWith('px') ? 1.5 : 2))));
    }
    static getAlignment(textAlignment) {
        switch (textAlignment) {
            case 'center':
                return AlignmentType.CENTER;
            case 'right':
                return AlignmentType.RIGHT;
            case 'justify':
                return AlignmentType.JUSTIFIED;
            default:
                return AlignmentType.LEFT;
        }
    }
    static createParagraph(cheerioAPI, elem, textAlignment, colorParsed, backgroundColor, size, isListParagraph, options) {
        const children = [];
        if (options?.marker) {
            children.push(new TextRun({
                children: [options.marker, new Tab()], size: CodebookDocxGenerator.getFontSize(size)
            }));
        }
        const childNodes = CodebookDocxGenerator.getChildren(cheerioAPI, elem);
        CodebookDocxGenerator.processInlineElements(childNodes, children, colorParsed, backgroundColor, size, options?.element.name.match(/^h[1-3]$/) ? { bold: true } : {}, options?.imageWidth);
        const normalizedChildren = CodebookDocxGenerator.normalizeParagraphChildren(children, textAlignment);
        const styles = options ? CodebookDocxGenerator.inlineStyles(options.element) : {};
        const pixels = (value) => {
            const amount = parseFloat(value || '');
            return Number.isFinite(amount) ? Math.round(amount * (value?.endsWith('pt') ? 20 : 15)) : undefined;
        };
        const listStart = (options?.listDepth || 0) * 600 + (options?.listIndent || 0);
        const start = (pixels(styles['padding-left']) ?? (isListParagraph ? 0 : 100)) + listStart + (options?.quoteDepth || 0) * 600;
        const textIndent = pixels(styles['text-indent']) || 0;
        const indent = options?.marker ? { start, hanging: 300 } : {
            start,
            end: 100,
            ...(textIndent < 0 ? { hanging: -textIndent } : {}),
            ...(textIndent > 0 ? { firstLine: textIndent } : {})
        };
        return new Paragraph({
            alignment: CodebookDocxGenerator.getAlignment(textAlignment),
            spacing: {
                before: pixels(styles['margin-top']) ?? 100,
                after: pixels(styles['margin-bottom']) ?? 100
            },
            indent: isListParagraph ? undefined : indent,
            bullet: isListParagraph ? { level: 0 } : undefined,
            ...(options?.marker ? { tabStops: [{ type: TabStopType.LEFT, position: start }] } : {}),
            children: normalizedChildren
        });
    }
    static parseCssRgbString(input) {
        const parts = input
            ?.replace(/rgba?\(([^)]+)\)/, '$1')
            .split(/[,\s/]+/)
            .filter(Boolean);
        if (parts?.length < 3) {
            return;
        }
        const parseValue = (value, max) => {
            // eslint-disable-next-line no-param-reassign
            value = value.trim();
            if (value.endsWith('%')) {
                return Math.min((Number.parseFloat(value) * max) / 100, max);
            }
            return Math.min(Number.parseFloat(value), max);
        };
        const red = parseValue(parts[0], 255);
        const green = parseValue(parts[1], 255);
        const blue = parseValue(parts[2], 255);
        // eslint-disable-next-line consistent-return
        return [red, green, blue];
    }
    // Convert RGB color to HEX https://github.com/sindresorhus/rgb-hex
    // eslint-disable-next-line no-bitwise
    static { this.toHex = (red, green, blue) => (blue | (green << 8) | (red << 16) | (1 << 24)).toString(16).slice(1); }
}

var codebookDocxGenerator = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CodebookDocxGenerator: CodebookDocxGenerator
});

/**
 * Generated bundle index. Do not edit.
 */

export { CodebookDocxGenerator, CodebookGenerationError, CodebookGenerator, hasCodebookManualInstruction };
//# sourceMappingURL=iqb-ngx-coding-components-codebook-generator.mjs.map
