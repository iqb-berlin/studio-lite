import { ToTextFactory } from '@iqb/responses';
import { CodingScheme } from '@iqbspecs/coding-scheme';
import * as cheerio from 'cheerio';
import { load } from 'cheerio';
import { Packer, Paragraph, AlignmentType, HeadingLevel, TextRun, TableRow, TableCell, WidthType, Document, Footer, NumberFormat, PageNumber, Table, ImageRun, ImportedXmlComponent } from 'docx';
import { Buffer } from 'buffer';
import { imageSize } from 'image-size';
import katex from 'katex';
import { mml2omml } from 'mathml2omml';

class CodebookGenerationError extends Error {
    constructor() {
        super(...arguments);
        this.name = 'CodebookGenerationError';
    }
}

/** Rich-text instructions may consist entirely of an image or a formula. */
function hasCodebookManualInstruction(instruction) {
    if (!instruction)
        return false;
    const $ = load(instruction);
    $('script,style').remove();
    const text = $.root().text().replace(/[\s\u200b-\u200d\ufeff]/g, '');
    if (text)
        return true;
    return $('img').toArray().some(element => /^data:image\/(png|jpeg|jpg|gif|bmp);base64,\S+$/i.test($(element).attr('src') || '')) ||
        $('span.iqb-math-formula').toArray().some(element => !!$(element).attr('data-latex')?.trim());
}

class CodebookGenerator {
    static getCodebookData(units, options, missings) {
        return [...units].sort((a, b) => (a.key < b.key ? -1 : Number(a.key > b.key))).map(unit => {
            let variables = [];
            if (unit.scheme) {
                try {
                    const data = JSON.parse(unit.scheme);
                    if (!Array.isArray(data.variableCodings) || data.variableCodings.some((variable) => !variable || typeof variable.id !== 'string' ||
                        (variable.codes !== undefined && (!Array.isArray(variable.codes) || variable.codes.some(code => !code || typeof code !== 'object'))))) {
                        throw new Error('Ungültige variableCodings');
                    }
                    variables = new CodingScheme(unit.scheme).variableCodings;
                }
                catch {
                    throw new CodebookGenerationError(`Ungültiges Kodierschema für Aufgabe ${unit.key}.`);
                }
            }
            const bookVariables = variables.map(variable => this.getVariable(variable, options))
                .filter((variable) => variable !== null)
                .sort((a, b) => (a.id < b.id ? -1 : Number(a.id > b.id)));
            return {
                key: unit.key, name: unit.name, variables: bookVariables, missings, items: unit.metadata?.items || []
            };
        });
    }
    static async generateCodebook(units, options, missings) {
        const data = this.getCodebookData(units, options, missings);
        if (options.exportFormat === 'docx') {
            const { CodebookDocxGenerator } = await Promise.resolve().then(function () { return codebookDocxGenerator; });
            return CodebookDocxGenerator.generateDocx(data, options);
        }
        return new Blob([JSON.stringify(data.map(({ key, name, variables, missings: unitMissings }) => ({
                key, name, variables, missings: unitMissings
            })))], { type: 'application/json' });
    }
    static isClosed(code) {
        return code.type === 'RESIDUAL_AUTO' || code.type === 'INTENDED_INCOMPLETE';
    }
    static isManual(code) {
        return !this.isClosed(code) && hasCodebookManualInstruction(code.manualInstruction);
    }
    static getVariable(variable, options) {
        if (variable.sourceType === 'BASE_NO_VALUE' || (variable.sourceType !== 'BASE' && !options.hasDerivedVars))
            return null;
        const codes = (variable.codes || []).filter(code => code.id !== undefined && code.id !== null);
        const manual = codes.some(code => this.isManual(code));
        const closed = codes.some(code => this.isClosed(code));
        if ((options.hasOnlyManualCoding || options.hasClosedVars) &&
            !((options.hasOnlyManualCoding && manual) || (options.hasClosedVars && closed)))
            return null;
        const exportedCodes = options.hasOnlyManualCoding && !options.hasClosedVars ? codes.filter(code => this.isManual(code)) : codes;
        if (options.hasOnlyVarsWithCodes && !exportedCodes.length)
            return null;
        return {
            id: variable.alias || variable.id,
            label: variable.label || '',
            sourceType: variable.sourceType,
            generalInstruction: options.hasGeneralInstructions ? variable.manualInstruction || '' : '',
            codes: exportedCodes.map(code => this.getCode(code, options))
        };
    }
    static getCode(code, options) {
        const fallback = { id: `${code.id}`, label: '', description: '<p>Kodierschema mit Schemer Version ab 1.5 erzeugen!</p>' };
        if (options.showScore)
            fallback.score = '';
        if (Object.prototype.hasOwnProperty.call(code, 'rules'))
            return fallback;
        try {
            const text = ToTextFactory.codeAsText(code, 'SIMPLE');
            const rules = options.hasOnlyManualCoding && !options.hasClosedVars ? '' :
                (text.ruleSetDescriptions || []).filter(rule => rule !== 'Keine Regeln definiert.' || !code.manualInstruction)
                    .map(rule => `<p>${rule}</p>`).join('');
            const result = { id: `${code.id}`, label: options.codeLabelToUpper ? text.label.toUpperCase() : text.label, description: `${rules}${code.manualInstruction || ''}` };
            if (options.showScore)
                result.score = `${text.score}`;
            return result;
        }
        catch {
            return fallback;
        }
    }
}

/**
 * The CSS colour names and their hex values, for turning a colour a user picked by name into
 * something a generated document can paint with.
 */
class WebColors {
    /**
     * The hex value for a CSS colour name, or an empty string when the name is unknown. The name has
     * to be given in lower case -- the table is compared against it as it comes in.
     */
    static getHexFromWebColor(colorName) {
        const foundColor = WebColors.colors
            .find(color => color.name.toLowerCase() === colorName);
        return foundColor ? foundColor.hex : '';
    }
    /** The table itself: name, hex and rgb for every CSS colour. */
    static { this.colors = [
        {
            name: 'Lavender',
            hex: 'E6E6FA',
            rgb: {
                r: 230,
                g: 230,
                b: 250
            }
        },
        {
            name: 'Thistle',
            hex: 'D8BFD8',
            rgb: { r: 216, g: 191, b: 216 }
        },
        {
            name: 'Plum',
            hex: 'DDA0DD',
            rgb: {
                r: 221,
                g: 160,
                b: 221
            }
        },
        {
            name: 'Violet',
            hex: 'EE82EE',
            rgb: {
                r: 238,
                g: 130,
                b: 238
            }
        },
        {
            name: 'Orchid',
            hex: 'DA70D6',
            rgb: {
                r: 218,
                g: 112,
                b: 214
            }
        },
        {
            name: 'Fuchsia',
            hex: 'FF00FF',
            rgb: {
                r: 255,
                g: 0,
                b: 255
            }
        },
        {
            name: 'Magenta',
            hex: 'FF00FF',
            rgb: {
                r: 255,
                g: 0,
                b: 255
            }
        },
        {
            name: 'MediumOrchid',
            hex: 'BA55D3',
            rgb: {
                r: 186,
                g: 85,
                b: 211
            }
        },
        {
            name: 'MediumPurple',
            hex: '9370DB',
            rgb: {
                r: 147,
                g: 112,
                b: 219
            }
        },
        {
            name: 'BlueViolet',
            hex: '8A2BE2',
            rgb: {
                r: 138,
                g: 43,
                b: 226
            }
        },
        {
            name: 'DarkViolet',
            hex: '9400D3',
            rgb: {
                r: 148,
                g: 0,
                b: 211
            }
        },
        {
            name: 'DarkOrchid',
            hex: '9932CC',
            rgb: {
                r: 153,
                g: 50,
                b: 204
            }
        },
        {
            name: 'DarkMagenta',
            hex: '8B008B',
            rgb: {
                r: 139,
                g: 0,
                b: 139
            }
        },
        {
            name: 'Purple',
            hex: '800080',
            rgb: {
                r: 128,
                g: 0,
                b: 128
            }
        },
        {
            name: 'Indigo',
            hex: '4B0082',
            rgb: {
                r: 75,
                g: 0,
                b: 130
            }
        },
        {
            name: 'DarkSlateBlue',
            hex: '483D8B',
            rgb: {
                r: 72,
                g: 61,
                b: 139
            }
        },
        {
            name: 'SlateBlue',
            hex: '6A5ACD',
            rgb: {
                r: 106,
                g: 90,
                b: 205
            }
        },
        {
            name: 'MediumSlateBlue',
            hex: '7B68EE',
            rgb: {
                r: 123,
                g: 104,
                b: 238
            }
        },
        {
            name: 'Pink',
            hex: 'FFC0CB',
            rgb: {
                r: 255,
                g: 192,
                b: 203
            }
        },
        {
            name: 'LightPink',
            hex: 'FFB6C1',
            rgb: {
                r: 255,
                g: 182,
                b: 193
            }
        },
        {
            name: 'HotPink',
            hex: 'FF69B4',
            rgb: {
                r: 255,
                g: 105,
                b: 180
            }
        },
        {
            name: 'DeepPink',
            hex: 'FF1493',
            rgb: {
                r: 255,
                g: 20,
                b: 147
            }
        },
        {
            name: 'PaleVioletRed',
            hex: 'DB7093',
            rgb: {
                r: 219,
                g: 112,
                b: 147
            }
        },
        {
            name: 'MediumVioletRed',
            hex: 'C71585',
            rgb: {
                r: 199,
                g: 21,
                b: 133
            }
        },
        {
            name: 'LightSalmon',
            hex: 'FFA07A',
            rgb: {
                r: 255,
                g: 160,
                b: 122
            }
        },
        {
            name: 'Salmon',
            hex: 'FA8072',
            rgb: {
                r: 250,
                g: 128,
                b: 114
            }
        },
        {
            name: 'DarkSalmon',
            hex: 'E9967A',
            rgb: {
                r: 233,
                g: 150,
                b: 122
            }
        },
        {
            name: 'LightCoral',
            hex: 'F08080',
            rgb: {
                r: 240,
                g: 128,
                b: 128
            }
        },
        {
            name: 'IndianRed',
            hex: 'CD5C5C',
            rgb: {
                r: 205,
                g: 92,
                b: 92
            }
        },
        {
            name: 'Crimson',
            hex: 'DC143C',
            rgb: {
                r: 220,
                g: 20,
                b: 60
            }
        },
        {
            name: 'FireBrick',
            hex: 'B22222',
            rgb: {
                r: 178,
                g: 34,
                b: 34
            }
        },
        {
            name: 'DarkRed',
            hex: '8B0000',
            rgb: {
                r: 139,
                g: 0,
                b: 0
            }
        },
        {
            name: 'Red',
            hex: 'FF0000',
            rgb: {
                r: 255,
                g: 0,
                b: 0
            }
        },
        {
            name: 'OrangeRed',
            hex: 'FF4500',
            rgb: {
                r: 255,
                g: 69,
                b: 0
            }
        },
        {
            name: 'Tomato',
            hex: 'FF6347',
            rgb: {
                r: 255,
                g: 99,
                b: 71
            }
        },
        {
            name: 'Coral',
            hex: 'FF7F50',
            rgb: {
                r: 255,
                g: 127,
                b: 80
            }
        },
        {
            name: 'DarkOrange',
            hex: 'FF8C00',
            rgb: {
                r: 255,
                g: 140,
                b: 0
            }
        },
        {
            name: 'Orange',
            hex: 'FFA500',
            rgb: {
                r: 255,
                g: 165,
                b: 0
            }
        },
        {
            name: 'Yellow',
            hex: 'FFFF00',
            rgb: {
                r: 255,
                g: 255,
                b: 0
            }
        },
        {
            name: 'LightYellow',
            hex: 'FFFFE0',
            rgb: {
                r: 255,
                g: 255,
                b: 224
            }
        },
        {
            name: 'LemonChiffon',
            hex: 'FFFACD',
            rgb: {
                r: 255,
                g: 250,
                b: 205
            }
        },
        {
            name: 'LightGoldenrodYellow',
            hex: 'FAFAD2',
            rgb: {
                r: 250,
                g: 250,
                b: 210
            }
        },
        {
            name: 'PapayaWhip',
            hex: 'FFEFD5',
            rgb: {
                r: 255,
                g: 239,
                b: 213
            }
        },
        {
            name: 'Moccasin',
            hex: 'FFE4B5',
            rgb: {
                r: 255,
                g: 228,
                b: 181
            }
        },
        {
            name: 'PeachPuff',
            hex: 'FFDAB9',
            rgb: {
                r: 255,
                g: 218,
                b: 185
            }
        },
        {
            name: 'PaleGoldenrod',
            hex: 'EEE8AA',
            rgb: {
                r: 238,
                g: 232,
                b: 170
            }
        },
        {
            name: 'Khaki',
            hex: 'F0E68C',
            rgb: {
                r: 240,
                g: 230,
                b: 140
            }
        },
        {
            name: 'DarkKhaki',
            hex: 'BDB76B',
            rgb: {
                r: 189,
                g: 183,
                b: 107
            }
        },
        {
            name: 'Gold',
            hex: 'FFD700',
            rgb: {
                r: 255,
                g: 215,
                b: 0
            }
        },
        {
            name: 'Cornsilk',
            hex: 'FFF8DC',
            rgb: {
                r: 255,
                g: 248,
                b: 220
            }
        },
        {
            name: 'BlanchedAlmond',
            hex: 'FFEBCD',
            rgb: {
                r: 255,
                g: 235,
                b: 205
            }
        },
        {
            name: 'Bisque',
            hex: 'FFE4C4',
            rgb: {
                r: 255,
                g: 228,
                b: 196
            }
        },
        {
            name: 'NavajoWhite',
            hex: 'FFDEAD',
            rgb: {
                r: 255,
                g: 222,
                b: 173
            }
        },
        {
            name: 'Wheat',
            hex: 'F5DEB3',
            rgb: {
                r: 245,
                g: 222,
                b: 179
            }
        },
        {
            name: 'BurlyWood',
            hex: 'DEB887',
            rgb: {
                r: 222,
                g: 184,
                b: 135
            }
        },
        {
            name: 'Tan',
            hex: 'D2B48C',
            rgb: {
                r: 210,
                g: 180,
                b: 140
            }
        },
        {
            name: 'RosyBrown',
            hex: 'BC8F8F',
            rgb: {
                r: 188,
                g: 143,
                b: 143
            }
        },
        {
            name: 'SandyBrown',
            hex: 'F4A460',
            rgb: {
                r: 244,
                g: 164,
                b: 96
            }
        },
        {
            name: 'Goldenrod',
            hex: 'DAA520',
            rgb: {
                r: 218,
                g: 165,
                b: 32
            }
        },
        {
            name: 'DarkGoldenrod',
            hex: 'B8860B',
            rgb: {
                r: 184,
                g: 134,
                b: 11
            }
        },
        {
            name: 'Peru',
            hex: 'CD853F',
            rgb: {
                r: 205,
                g: 133,
                b: 63
            }
        },
        {
            name: 'Chocolate',
            hex: 'D2691E',
            rgb: {
                r: 210,
                g: 105,
                b: 30
            }
        },
        {
            name: 'SaddleBrown',
            hex: '8B4513',
            rgb: {
                r: 139,
                g: 69,
                b: 19
            }
        },
        {
            name: 'Sienna',
            hex: 'A0522D',
            rgb: {
                r: 160,
                g: 82,
                b: 45
            }
        },
        {
            name: 'Brown',
            hex: 'A52A2A',
            rgb: {
                r: 165,
                g: 42,
                b: 42
            }
        },
        {
            name: 'Maroon',
            hex: '800000',
            rgb: {
                r: 128,
                g: 0,
                b: 0
            }
        },
        {
            name: 'DarkOliveGreen',
            hex: '556B2F',
            rgb: {
                r: 85,
                g: 107,
                b: 47
            }
        },
        {
            name: 'Olive',
            hex: '808000',
            rgb: {
                r: 128,
                g: 128,
                b: 0
            }
        },
        {
            name: 'OliveDrab',
            hex: '6B8E23',
            rgb: {
                r: 107,
                g: 142,
                b: 35
            }
        },
        {
            name: 'YellowGreen',
            hex: '9ACD32',
            rgb: {
                r: 154,
                g: 205,
                b: 50
            }
        },
        {
            name: 'LimeGreen',
            hex: '32CD32',
            rgb: {
                r: 50,
                g: 205,
                b: 50
            }
        },
        {
            name: 'Lime',
            hex: '00FF00',
            rgb: {
                r: 0,
                g: 255,
                b: 0
            }
        },
        {
            name: 'LawnGreen',
            hex: '7CFC00',
            rgb: {
                r: 124,
                g: 252,
                b: 0
            }
        },
        {
            name: 'Chartreuse',
            hex: '7FFF00',
            rgb: {
                r: 127,
                g: 255,
                b: 0
            }
        },
        {
            name: 'GreenYellow',
            hex: 'ADFF2F',
            rgb: {
                r: 173,
                g: 255,
                b: 47
            }
        },
        {
            name: 'SpringGreen',
            hex: '00FF7F',
            rgb: {
                r: 0,
                g: 255,
                b: 127
            }
        },
        {
            name: 'MediumSpringGreen',
            hex: '00FA9A',
            rgb: {
                r: 0,
                g: 250,
                b: 154
            }
        },
        {
            name: 'LightGreen',
            hex: '90EE90',
            rgb: {
                r: 144,
                g: 238,
                b: 144
            }
        },
        {
            name: 'PaleGreen',
            hex: '98FB98',
            rgb: {
                r: 152,
                g: 251,
                b: 152
            }
        },
        {
            name: 'DarkSeaGreen',
            hex: '8FBC8F',
            rgb: {
                r: 143,
                g: 188,
                b: 143
            }
        },
        {
            name: 'MediumSeaGreen',
            hex: '3CB371',
            rgb: {
                r: 60,
                g: 179,
                b: 113
            }
        },
        {
            name: 'SeaGreen',
            hex: '2E8B57',
            rgb: {
                r: 46,
                g: 139,
                b: 87
            }
        },
        {
            name: 'ForestGreen',
            hex: '228B22',
            rgb: {
                r: 34,
                g: 139,
                b: 34
            }
        },
        {
            name: 'Green',
            hex: '008000',
            rgb: {
                r: 0,
                g: 128,
                b: 0
            }
        },
        {
            name: 'DarkGreen',
            hex: '006400',
            rgb: {
                r: 0,
                g: 100,
                b: 0
            }
        },
        {
            name: 'MediumAquamarine',
            hex: '66CDAA',
            rgb: {
                r: 102,
                g: 205,
                b: 170
            }
        },
        {
            name: 'Aqua',
            hex: '00FFFF',
            rgb: {
                r: 0,
                g: 255,
                b: 255
            }
        },
        {
            name: 'Cyan',
            hex: '00FFFF',
            rgb: {
                r: 0,
                g: 255,
                b: 255
            }
        },
        {
            name: 'LightCyan',
            hex: 'E0FFFF',
            rgb: {
                r: 224,
                g: 255,
                b: 255
            }
        },
        {
            name: 'PaleTurquoise',
            hex: 'AFEEEE',
            rgb: {
                r: 175,
                g: 238,
                b: 238
            }
        },
        {
            name: 'Aquamarine',
            hex: '7FFFD4',
            rgb: {
                r: 127,
                g: 255,
                b: 212
            }
        },
        {
            name: 'Turquoise',
            hex: '40E0D0',
            rgb: {
                r: 64,
                g: 224,
                b: 208
            }
        },
        {
            name: 'MediumTurquoise',
            hex: '48D1CC',
            rgb: {
                r: 72,
                g: 209,
                b: 204
            }
        },
        {
            name: 'DarkTurquoise',
            hex: '00CED1',
            rgb: {
                r: 0,
                g: 206,
                b: 209
            }
        },
        {
            name: 'LightSeaGreen',
            hex: '20B2AA',
            rgb: {
                r: 32,
                g: 178,
                b: 170
            }
        },
        {
            name: 'CadetBlue',
            hex: '5F9EA0',
            rgb: {
                r: 95,
                g: 158,
                b: 160
            }
        },
        {
            name: 'DarkCyan',
            hex: '008B8B',
            rgb: {
                r: 0,
                g: 139,
                b: 139
            }
        },
        {
            name: 'Teal',
            hex: '008080',
            rgb: {
                r: 0,
                g: 128,
                b: 128
            }
        },
        {
            name: 'LightSteelBlue',
            hex: 'B0C4DE',
            rgb: {
                r: 176,
                g: 196,
                b: 222
            }
        },
        {
            name: 'PowderBlue',
            hex: 'B0E0E6',
            rgb: {
                r: 176,
                g: 224,
                b: 230
            }
        },
        {
            name: 'LightBlue',
            hex: 'ADD8E6',
            rgb: {
                r: 173,
                g: 216,
                b: 230
            }
        },
        {
            name: 'SkyBlue',
            hex: '87CEEB',
            rgb: {
                r: 135,
                g: 206,
                b: 235
            }
        },
        {
            name: 'LightSkyBlue',
            hex: '87CEFA',
            rgb: {
                r: 135,
                g: 206,
                b: 250
            }
        },
        {
            name: 'DeepSkyBlue',
            hex: '00BFFF',
            rgb: {
                r: 0,
                g: 191,
                b: 255
            }
        },
        {
            name: 'DodgerBlue',
            hex: '1E90FF',
            rgb: {
                r: 30,
                g: 144,
                b: 255
            }
        },
        {
            name: 'CornflowerBlue',
            hex: '6495ED',
            rgb: {
                r: 100,
                g: 149,
                b: 237
            }
        },
        {
            name: 'SteelBlue',
            hex: '4682B4',
            rgb: {
                r: 70,
                g: 130,
                b: 180
            }
        },
        {
            name: 'RoyalBlue',
            hex: '4169E1',
            rgb: {
                r: 65,
                g: 105,
                b: 225
            }
        },
        {
            name: 'Blue',
            hex: '0000FF',
            rgb: {
                r: 0,
                g: 0,
                b: 255
            }
        },
        {
            name: 'MediumBlue',
            hex: '0000CD',
            rgb: {
                r: 0,
                g: 0,
                b: 205
            }
        },
        {
            name: 'DarkBlue',
            hex: '00008B',
            rgb: {
                r: 0,
                g: 0,
                b: 139
            }
        },
        {
            name: 'Navy',
            hex: '000080',
            rgb: {
                r: 0,
                g: 0,
                b: 128
            }
        },
        {
            name: 'MidnightBlue',
            hex: '191970',
            rgb: {
                r: 25,
                g: 25,
                b: 112
            }
        },
        {
            name: 'White',
            hex: 'FFFFFF',
            rgb: {
                r: 255,
                g: 255,
                b: 255
            }
        },
        {
            name: 'Snow',
            hex: 'FFFAFA',
            rgb: {
                r: 255,
                g: 250,
                b: 250
            }
        },
        {
            name: 'Honeydew',
            hex: 'F0FFF0',
            rgb: {
                r: 240,
                g: 255,
                b: 240
            }
        },
        {
            name: 'MintCream',
            hex: 'F5FFFA',
            rgb: {
                r: 245,
                g: 255,
                b: 250
            }
        },
        {
            name: 'Azure',
            hex: 'F0FFFF',
            rgb: {
                r: 240,
                g: 255,
                b: 255
            }
        },
        {
            name: 'AliceBlue',
            hex: 'F0F8FF',
            rgb: {
                r: 240,
                g: 248,
                b: 255
            }
        },
        {
            name: 'GhostWhite',
            hex: 'F8F8FF',
            rgb: {
                r: 248,
                g: 248,
                b: 255
            }
        },
        {
            name: 'WhiteSmoke',
            hex: 'F5F5F5',
            rgb: {
                r: 245,
                g: 245,
                b: 245
            }
        },
        {
            name: 'Seashell',
            hex: 'FFF5EE',
            rgb: {
                r: 255,
                g: 245,
                b: 238
            }
        },
        {
            name: 'Beige',
            hex: 'F5F5DC',
            rgb: {
                r: 245,
                g: 245,
                b: 220
            }
        },
        {
            name: 'OldLace',
            hex: 'FDF5E6',
            rgb: {
                r: 253,
                g: 245,
                b: 230
            }
        },
        {
            name: 'FloralWhite',
            hex: 'FFFAF0',
            rgb: {
                r: 255,
                g: 250,
                b: 240
            }
        },
        {
            name: 'Ivory',
            hex: 'FFFFF0',
            rgb: {
                r: 255,
                g: 255,
                b: 240
            }
        },
        {
            name: 'AntiqueWhite',
            hex: 'FAEBD7',
            rgb: {
                r: 250,
                g: 235,
                b: 215
            }
        },
        {
            name: 'Linen',
            hex: 'FAF0E6',
            rgb: {
                r: 250,
                g: 240,
                b: 230
            }
        },
        {
            name: 'LavenderBlush',
            hex: 'FFF0F5',
            rgb: {
                r: 255,
                g: 240,
                b: 245
            }
        },
        {
            name: 'MistyRose',
            hex: 'FFE4E1',
            rgb: {
                r: 255,
                g: 228,
                b: 225
            }
        },
        {
            name: 'Gainsboro',
            hex: 'DCDCDC',
            rgb: {
                r: 220,
                g: 220,
                b: 220
            }
        },
        {
            name: 'LightGray',
            hex: 'D3D3D3',
            rgb: {
                r: 211,
                g: 211,
                b: 211
            }
        },
        {
            name: 'Silver',
            hex: 'C0C0C0',
            rgb: {
                r: 192,
                g: 192,
                b: 192
            }
        },
        {
            name: 'DarkGray',
            hex: 'A9A9A9',
            rgb: {
                r: 169,
                g: 169,
                b: 169
            }
        },
        {
            name: 'Gray',
            hex: '808080',
            rgb: {
                r: 128,
                g: 128,
                b: 128
            }
        },
        {
            name: 'DimGray',
            hex: '696969',
            rgb: {
                r: 105,
                g: 105,
                b: 105
            }
        },
        {
            name: 'LightSlateGray',
            hex: '778899',
            rgb: {
                r: 119,
                g: 136,
                b: 153
            }
        },
        {
            name: 'SlateGray',
            hex: '708090',
            rgb: {
                r: 112,
                g: 128,
                b: 144
            }
        },
        {
            name: 'DarkSlateGray',
            hex: '2F4F4F',
            rgb: {
                r: 47,
                g: 79,
                b: 79
            }
        },
        {
            name: 'Black',
            hex: '000000',
            rgb: {
                r: 0,
                g: 0,
                b: 0
            }
        }
    ]; }
}

class CodebookDocxGenerator {
    static { this.ommlCache = {}; }
    static async generateDocx(codingBookUnits, contentSetting) {
        const units = [];
        const missingDefinitions = new Map();
        codingBookUnits.forEach(unit => {
            unit.missings.forEach(missing => missingDefinitions.set(JSON.stringify(missing), missing));
            if (unit.variables.length) {
                units.push(...this.createDocXForUnit(unit.items || [], unit.variables, contentSetting, this.getUnitHeader(unit)));
            }
        });
        const missings = this.getMissings({
            key: '', name: '', variables: [], missings: [...missingDefinitions.values()]
        });
        return Packer.toBlob(this.setDocXDocument(units, missings));
    }
    static getUnitHeader(variableCoding) {
        return new Paragraph({
            border: {
                bottom: {
                    color: '#000000',
                    style: 'single',
                    size: 10
                },
                top: {
                    color: '#000000',
                    style: 'single',
                    size: 10
                }
            },
            spacing: {
                after: 200
            },
            text: `${variableCoding.key}  ${variableCoding.name}`,
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER
        });
    }
    static getMissings(variableCoding) {
        const missings = [];
        try {
            variableCoding.missings.forEach(missing => {
                if (missing.code !== undefined && missing.code !== null && `${missing.code}` !== '' && missing.label && missing.description) {
                    missings.push(new Paragraph({
                        children: [
                            new TextRun({
                                text: `${missing.code} ${missing.label}`,
                                bold: true
                            })
                        ],
                        spacing: {
                            after: 20
                        }
                    }));
                    missings.push(new Paragraph({
                        text: `${missing.description}`,
                        spacing: {
                            after: 100
                        }
                    }));
                }
                else {
                    missings.push(new Paragraph({
                        text: 'kein valides Missing ',
                        spacing: {
                            after: 200
                        }
                    }));
                }
            });
        }
        catch {
            missings.push(new Paragraph({
                text: 'kein validen Missings gefunden',
                spacing: {
                    after: 200
                }
            }));
        }
        return missings;
    }
    static get TableBoarders() {
        return {
            top: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            bottom: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            left: {
                size: 1,
                color: '#000000',
                style: 'single'
            },
            right: {
                size: 1,
                color: '#000000',
                style: 'single'
            }
        };
    }
    static getCodeRows(variable, contentSetting) {
        return variable.codes.map(code => new TableRow({
            cantSplit: true,
            children: [
                CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.id), CodebookDocxGenerator.getColumnWidths(contentSetting)[0]),
                CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.label), CodebookDocxGenerator.getColumnWidths(contentSetting)[1]),
                ...(contentSetting.showScore ?
                    [
                        CodebookDocxGenerator.createCodeCell(CodebookDocxGenerator.createCellChildren(code.score ?? ''), CodebookDocxGenerator.getColumnWidths(contentSetting)[2])
                    ] :
                    []),
                CodebookDocxGenerator.createCodeCell([...CodebookDocxGenerator.htmlToDocx(code.description, contentSetting)], CodebookDocxGenerator.getColumnWidths(contentSetting)[CodebookDocxGenerator.getColumnWidths(contentSetting).length - 1])
            ]
        }));
    }
    static createCellChildren(value) {
        return [
            new Paragraph({
                text: value,
                spacing: {
                    before: 100,
                    after: 100
                },
                indent: { start: 100, end: 100 }
            })
        ];
    }
    static createCodeCell(children, width) {
        return new TableCell({
            borders: CodebookDocxGenerator.TableBoarders,
            children: children,
            // Need for Word, but not for Writer
            width: {
                size: width,
                type: WidthType.PERCENTAGE
            }
        });
    }
    static setDocXDocument(units, missings) {
        return new Document({
            background: {
                color: '#FFFFFF'
            },
            sections: [
                {
                    properties: {
                        page: {
                            pageNumbers: {
                                start: 1,
                                formatType: NumberFormat.DECIMAL
                            }
                        }
                    },
                    footers: {
                        default: new Footer({
                            children: [
                                new Paragraph({
                                    alignment: AlignmentType.CENTER,
                                    children: [
                                        new TextRun('IQB Codebook '),
                                        new TextRun(new Date().toLocaleDateString())
                                    ]
                                }),
                                new Paragraph({
                                    alignment: AlignmentType.CENTER,
                                    children: [
                                        new TextRun({
                                            color: '000000',
                                            children: [' Seite ', PageNumber.CURRENT]
                                        }),
                                        new TextRun({
                                            color: '000000',
                                            children: [' von ', PageNumber.TOTAL_PAGES]
                                        })
                                    ]
                                })
                            ]
                        })
                    },
                    children: [...missings, ...units]
                }
            ]
        });
    }
    static getVariableHeader(variable) {
        return new Paragraph({
            text: `${variable.id}  ${variable.label}`,
            heading: HeadingLevel.HEADING_2,
            alignment: AlignmentType.LEFT,
            spacing: {
                before: 200,
                after: 200
            }
        });
    }
    static getVariableItems(variable, varItems) {
        const filteredVarItems = varItems.filter(item => item.variableId === variable.id);
        let itemString = '';
        filteredVarItems.forEach(item => {
            itemString += `${item.id}   `;
        });
        if (filteredVarItems.length === 0) {
            return [];
        }
        return [new Paragraph({
                text: `Item(s): ${itemString}`,
                heading: HeadingLevel.HEADING_3,
                alignment: AlignmentType.LEFT,
                spacing: {
                    before: 200,
                    after: 200
                }
            })];
    }
    static getGeneralInstructions(contentSetting, codeBookVariable) {
        return contentSetting.hasGeneralInstructions ?
            CodebookDocxGenerator.htmlToDocx(codeBookVariable.generalInstruction, contentSetting) :
            [];
    }
    static getCodeTable(codeBookVariable, contentSetting) {
        return new Table({
            rows: CodebookDocxGenerator.getCodeRows(codeBookVariable, contentSetting),
            width: {
                size: 100,
                type: WidthType.PERCENTAGE
            },
            columnWidths: CodebookDocxGenerator.getColumnWidths(contentSetting) // Need for Writer, but not for Word
        });
    }
    static getColumnWidths(contentSetting) {
        return contentSetting.showScore ? [8, 24, 8, 60] : [8, 24, 68];
    }
    static getVariables(codeBookVariable, contentSetting, varItems) {
        const variables = [];
        codeBookVariable.forEach(variable => {
            variables.push(...[
                CodebookDocxGenerator.getVariableHeader(variable),
                ...(contentSetting.hideItemVarRelation ? [] : CodebookDocxGenerator.getVariableItems(variable, varItems)),
                ...CodebookDocxGenerator.getGeneralInstructions(contentSetting, variable),
                CodebookDocxGenerator.getCodeTable(variable, contentSetting)
            ]);
        });
        return variables;
    }
    static createDocXForUnit(varItems, codeBookVariable, contentSetting, unitHeader) {
        return [
            unitHeader,
            ...CodebookDocxGenerator.getVariables(codeBookVariable, contentSetting, varItems),
            new Paragraph({
                text: '',
                spacing: {
                    before: 100,
                    after: 100
                }
            })
        ];
    }
    static getChildren(cheerioAPI, elem) {
        return cheerioAPI(elem).toArray();
    }
    static processInlineElements(nodes, children, colorParsed, backgroundColor, size) {
        nodes.forEach(node => {
            if (node.type === 'text') {
                if ('data' in node && node.data && node.data.trim()) {
                    children.push(new TextRun({
                        text: node.data.replace(/\s+/g, ' '),
                        color: colorParsed,
                        shading: {
                            fill: backgroundColor
                        },
                        size: CodebookDocxGenerator.getFontSize(size)
                    }));
                }
            }
            else if (node.type === 'tag') {
                const element = node;
                const tagName = element.name.toLowerCase();
                if (tagName === 'span' &&
                    element.attribs?.['class']?.includes('iqb-math-formula')) {
                    const rawLatex = element.attribs?.['data-latex'] || '';
                    const latex = CodebookDocxGenerator.decodeLatex(rawLatex).trim();
                    if (latex) {
                        const ommlComponent = CodebookDocxGenerator.latexToOmml(latex);
                        if (ommlComponent) {
                            children.push(ommlComponent);
                        }
                        else {
                            children.push(new TextRun({
                                text: latex,
                                color: colorParsed,
                                shading: {
                                    fill: backgroundColor
                                },
                                size: CodebookDocxGenerator.getFontSize(size)
                            }));
                        }
                    }
                    return;
                }
                if (tagName === 'strong' || tagName === 'b') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    bold: true,
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 'em' || tagName === 'i') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    italics: true,
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 'u') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    underline: {},
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 's') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    strike: true,
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 'sub') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    subScript: true,
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 'sup') {
                    if (element.children) {
                        element.children.forEach(child => {
                            if (child.type === 'text' && child.data) {
                                children.push(new TextRun({
                                    text: child.data.replace(/\s+/g, ' '),
                                    superScript: true,
                                    color: colorParsed,
                                    shading: {
                                        fill: backgroundColor
                                    },
                                    size: CodebookDocxGenerator.getFontSize(size)
                                }));
                            }
                        });
                    }
                }
                else if (tagName === 'br') {
                    children.push(new TextRun({
                        break: 1,
                        color: colorParsed,
                        shading: {
                            fill: backgroundColor
                        },
                        size: CodebookDocxGenerator.getFontSize(size)
                    }));
                }
                else if (element.children && element.children.length > 0) {
                    CodebookDocxGenerator.processInlineElements(element.children, children, colorParsed, backgroundColor, size);
                }
            }
        });
    }
    static getImageSize(imageBuffer) {
        const size = imageSize(imageBuffer);
        if (!size.width || !size.height)
            throw new Error('Ungültige Bildgröße');
        return { width: size.width, height: size.height };
    }
    static getTransformation(actualSize, max) {
        const transformedSize = {
            width: actualSize.width,
            height: actualSize.height
        };
        const maxWidth = max;
        const maxHeight = max;
        if (actualSize.width > maxWidth || actualSize.height > maxHeight) {
            const ratio = Math.min(maxWidth / actualSize.width, maxHeight / actualSize.height);
            transformedSize.width = actualSize.width * ratio;
            transformedSize.height = actualSize.height * ratio;
        }
        return transformedSize;
    }
    static createImagePragraph(elem, contentSetting) {
        const imageBuffer = Buffer.from(elem.attribs['src'].substring(elem.attribs['src'].indexOf(',') + 1), 'base64');
        const size = CodebookDocxGenerator.getImageSize(imageBuffer);
        return new Paragraph({
            spacing: {
                before: 100,
                after: 100
            },
            indent: {
                start: 100,
                end: 100
            },
            children: [
                new ImageRun({
                    data: imageBuffer,
                    transformation: CodebookDocxGenerator.getTransformation(size, contentSetting.showScore ? 334 : 382)
                })
            ]
        });
    }
    static getBackgroundColor(cheerioAPI, elem) {
        const mark = cheerioAPI(elem).find('mark');
        return cheerioAPI(mark).css('background-color') || '#FFFFFF';
    }
    static getColor(cheerioAPI, tag) {
        const color = cheerioAPI(tag).css('color');
        // const name = elem.name;
        let colorParsed = '#000000';
        if (color) {
            if (color.startsWith('#')) {
                colorParsed = color;
            }
            else if (color.startsWith('rgb')) {
                const rgbString = CodebookDocxGenerator.parseCssRgbString(color);
                if (rgbString) {
                    colorParsed = CodebookDocxGenerator.toHex(rgbString[0], rgbString[1], rgbString[2]);
                }
            }
            else if (WebColors.getHexFromWebColor(color.toLowerCase())) {
                colorParsed = `#${WebColors.getHexFromWebColor(color.toLowerCase())}`;
            }
        }
        return colorParsed;
    }
    static getSize(cheerioAPI, tag) {
        return cheerioAPI(tag).css('font-size') || '20pt';
    }
    static getTextAlignment(cheerioAPI, elem) {
        return cheerioAPI(elem).css('text-align') || 'left';
    }
    static stripFromLeadingEmptyParagraph(html) {
        return html.replace(/^<p><\/p>/, '');
    }
    static convertLineBreaksToHTMLBreaks(html) {
        return html.replace(/\n/g, '<br>');
    }
    static prepareHtml(html) {
        return CodebookDocxGenerator.convertLineBreaksToHTMLBreaks(CodebookDocxGenerator.stripFromLeadingEmptyParagraph(html));
    }
    static decodeLatex(latex) {
        if (!latex)
            return '';
        try {
            return decodeURIComponent(latex);
        }
        catch {
            return latex;
        }
    }
    static latexToOmml(latex) {
        const trimmed = latex.trim();
        if (!trimmed)
            return null;
        try {
            if (!CodebookDocxGenerator.ommlCache[trimmed]) {
                const mathml = katex.renderToString(trimmed, {
                    output: 'mathml',
                    throwOnError: false,
                    strict: 'ignore'
                });
                CodebookDocxGenerator.ommlCache[trimmed] = mml2omml(mathml);
            }
            const omml = CodebookDocxGenerator.ommlCache[trimmed];
            return CodebookDocxGenerator.unwrapImportedXmlRoot(ImportedXmlComponent.fromXmlString(CodebookDocxGenerator.sanitizeOmmlXml(omml)));
        }
        catch {
            return null;
        }
    }
    static unwrapImportedXmlRoot(component) {
        const importedComponent = component;
        if (importedComponent.rootKey !== undefined) {
            return component;
        }
        const firstChild = importedComponent.root?.[0];
        return typeof firstChild === 'object' && firstChild !== null ?
            firstChild :
            component;
    }
    static isMathComponent(child) {
        if (typeof child !== 'object' || child === null) {
            return false;
        }
        const importedChild = child;
        return importedChild.rootKey === 'm:oMath' ||
            importedChild.rootKey === 'm:oMathPara';
    }
    static createLeftAlignedMathParagraph(mathChildren) {
        const mathParagraph = new ImportedXmlComponent('m:oMathPara');
        const mathParagraphProperties = new ImportedXmlComponent('m:oMathParaPr');
        mathParagraphProperties.push(new ImportedXmlComponent('m:jc', { 'm:val': 'left' }));
        mathParagraph.push(mathParagraphProperties);
        mathChildren.forEach(mathChild => mathParagraph.push(mathChild));
        return mathParagraph;
    }
    static normalizeParagraphChildren(children) {
        if (!children.length) {
            return children;
        }
        const mathChildren = children.filter(CodebookDocxGenerator.isMathComponent);
        if (mathChildren.length === children.length) {
            return [CodebookDocxGenerator.createLeftAlignedMathParagraph(mathChildren)];
        }
        return children;
    }
    static sanitizeOmmlXml(omml) {
        if (!omml)
            return omml;
        return omml.replace(/(<m:t\b[^>]*>)([\s\S]*?)(<\/m:t>)/g, (_, prefix, rawText, suffix) => `${prefix}${CodebookDocxGenerator.escapeXmlText(rawText)}${suffix}`);
    }
    static escapeXmlText(text) {
        return text
            .replace(/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    static normalizeMathTokens(html) {
        return html.replace(/\[\[iqb-math:([\s\S]*?)]]/g, (_, encodedFormula) => {
            const latex = this.decodeLatex(encodedFormula);
            const escapedLatex = latex.replace(/"/g, '&quot;');
            return `<span class="iqb-math-formula" data-latex="${escapedLatex}"></span>`;
        });
    }
    static isListParagraph(elem) {
        return !!elem.parent && elem.parent.name === 'li';
    }
    static htmlToDocx(html, contentSetting) {
        const normalizedHtml = CodebookDocxGenerator.normalizeMathTokens(html);
        const blockHtml = /<(p|h[1-4]|img|ul|ol)\b/i.test(normalizedHtml) ? normalizedHtml : `<p>${normalizedHtml}</p>`;
        const cheerioAPI = cheerio.load(CodebookDocxGenerator.prepareHtml(blockHtml), null, false);
        const elements = [];
        cheerioAPI('p,h1,h2,h3,h4,img').each((i, elem) => {
            try {
                const span = cheerioAPI(elem).find('span');
                if (elem.name === 'img') {
                    elements.push(CodebookDocxGenerator.createImagePragraph(elem, contentSetting));
                }
                else {
                    elements.push(CodebookDocxGenerator.createParagraph(cheerioAPI, elem.children, CodebookDocxGenerator.getTextAlignment(cheerioAPI, elem), CodebookDocxGenerator.getColor(cheerioAPI, span), CodebookDocxGenerator.getBackgroundColor(cheerioAPI, elem), CodebookDocxGenerator.getSize(cheerioAPI, span), CodebookDocxGenerator.isListParagraph(elem)));
                }
            }
            catch {
                elements.push(new Paragraph({
                    text: 'HTML konnte nicht verarbeitet werden.'
                }));
            }
        });
        return elements.filter(e => e !== undefined && e !== null);
    }
    static getFontSize(size) {
        const sizeTypes = [
            'xx-small',
            'x-small',
            'small',
            'medium',
            'large',
            'x-large',
            'xx-large'
        ];
        return sizeTypes.includes(size) ? 20 : parseInt(size, 10);
    }
    static getAlignment(textAlignment) {
        switch (textAlignment) {
            case 'center':
                return AlignmentType.CENTER;
            case 'right':
                return AlignmentType.RIGHT;
            case 'justify':
                return AlignmentType.JUSTIFIED;
            default:
                return AlignmentType.LEFT;
        }
    }
    static createParagraph(cheerioAPI, elem, textAlignment, colorParsed, backgroundColor, size, isListParagraph) {
        const children = [];
        const childNodes = CodebookDocxGenerator.getChildren(cheerioAPI, elem);
        CodebookDocxGenerator.processInlineElements(childNodes, children, colorParsed, backgroundColor, size);
        const normalizedChildren = CodebookDocxGenerator.normalizeParagraphChildren(children);
        return new Paragraph({
            alignment: CodebookDocxGenerator.getAlignment(textAlignment),
            spacing: {
                before: 100,
                after: 100
            },
            indent: !isListParagraph ? { start: 100, end: 100 } : undefined,
            bullet: isListParagraph ? { level: 0 } : undefined,
            children: normalizedChildren
        });
    }
    static parseCssRgbString(input) {
        const parts = input
            ?.replace(/rgba?\(([^)]+)\)/, '$1')
            .split(/[,\s/]+/)
            .filter(Boolean);
        if (parts?.length < 3) {
            return;
        }
        const parseValue = (value, max) => {
            // eslint-disable-next-line no-param-reassign
            value = value.trim();
            if (value.endsWith('%')) {
                return Math.min((Number.parseFloat(value) * max) / 100, max);
            }
            return Math.min(Number.parseFloat(value), max);
        };
        const red = parseValue(parts[0], 255);
        const green = parseValue(parts[1], 255);
        const blue = parseValue(parts[2], 255);
        // eslint-disable-next-line consistent-return
        return [red, green, blue];
    }
    // Convert RGB color to HEX https://github.com/sindresorhus/rgb-hex
    // eslint-disable-next-line no-bitwise
    static { this.toHex = (red, green, blue) => (blue | (green << 8) | (red << 16) | (1 << 24)).toString(16).slice(1); }
}

var codebookDocxGenerator = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CodebookDocxGenerator: CodebookDocxGenerator
});

/**
 * Generated bundle index. Do not edit.
 */

export { CodebookDocxGenerator, CodebookGenerationError, CodebookGenerator, hasCodebookManualInstruction };
//# sourceMappingURL=iqb-ngx-coding-components-codebook-generator.mjs.map
