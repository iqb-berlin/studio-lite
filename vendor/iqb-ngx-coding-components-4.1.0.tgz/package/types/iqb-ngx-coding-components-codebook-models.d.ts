import { VariableInfo } from '@iqbspecs/variable-info/variable-info.interface';

/**
 * Item metadata for codebook
 */
interface ItemMetadata {
    id: string;
    variableId: string;
}
/**
 * Settings for codebook content generation
 */
interface CodeBookContentSetting {
    /** Export format (docx or json) */
    exportFormat: 'json' | 'docx';
    /** Missings profile name */
    missingsProfile: string;
    /** Include only manual coding */
    hasOnlyManualCoding: boolean;
    /** Include general instructions */
    hasGeneralInstructions: boolean;
    /** Include derived variables */
    hasDerivedVars: boolean;
    /** Include only variables with codes */
    hasOnlyVarsWithCodes: boolean;
    /** Include closed variables */
    hasClosedVars: boolean;
    /** Convert code labels to uppercase */
    codeLabelToUpper: boolean;
    /** Show score */
    showScore: boolean;
    /** Hide item-variable relation */
    hideItemVarRelation: boolean;
}
/**
 * Missing code definition
 */
interface Missing {
    /** Missing code */
    code: string | number;
    /** Missing label */
    label: string;
    /** Missing description */
    description: string;
}
/**
 * Code information for codebook
 */
interface CodeInfo {
    /** Code ID */
    id: string;
    /** Code label */
    label: string;
    /** Code description */
    description: string;
    /** Code score (optional) */
    score?: string;
}
/**
 * Variable information for codebook
 */
interface BookVariable {
    /** Variable ID */
    id: string;
    /** Variable label */
    label: string;
    /** Variable source type */
    sourceType: string;
    /** General instruction */
    generalInstruction: string;
    /** Codes */
    codes: CodeInfo[];
}
/**
 * Unit data for codebook
 */
interface CodebookUnitDto {
    /** Unit key */
    key: string;
    /** Unit name */
    name: string;
    /** Variables */
    variables: BookVariable[];
    /** Missings */
    missings: Missing[];
    /** Items (optional) */
    items?: ItemMetadata[];
}
/**
 * Unit properties for codebook generation
 */
interface UnitPropertiesForCodebook {
    /** Unit ID */
    id: number;
    /** Unit key */
    key: string;
    /** Unit name */
    name: string;
    /** Coding scheme */
    scheme?: string;
    /** Scheme type */
    schemeType?: string;
    /** Metadata */
    metadata?: {
        /** Items */
        items?: ItemMetadata[];
    };
    /** Variables */
    variables?: VariableInfo[];
}
/**
 * Unit selection item for codebook export UI
 */
interface UnitSelectionItem {
    /** Unit ID */
    unitId: number;
    /** Unit name */
    unitName: string;
    /** Unit alias */
    unitAlias?: string | null;
    key: string;
    groupName?: string;
    disabled?: boolean;
}
/**
 * Missings profile for selection
 */
interface MissingsProfile {
    /** Profile ID */
    id: number;
    /** Profile label */
    label: string;
    /** Missings data */
    missings?: Missing[] | string;
}
/**
 * Codebook export configuration
 */
interface CodebookExportConfig {
    /** Selected unit IDs */
    selectedUnits: number[];
    /** Content options */
    contentOptions: CodeBookContentSetting;
    /** Selected missings profile ID */
    missingsProfileId: number;
}

export type { BookVariable, CodeBookContentSetting, CodeInfo, CodebookExportConfig, CodebookUnitDto, ItemMetadata, Missing, MissingsProfile, UnitPropertiesForCodebook, UnitSelectionItem };
