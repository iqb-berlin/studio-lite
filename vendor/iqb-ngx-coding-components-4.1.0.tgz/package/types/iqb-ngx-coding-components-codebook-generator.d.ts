import { UnitPropertiesForCodebook, CodeBookContentSetting, Missing, CodebookUnitDto } from '@iqb/ngx-coding-components/codebook-models';
export * from '@iqb/ngx-coding-components/codebook-models';

declare class CodebookGenerator {
    static getCodebookData(units: UnitPropertiesForCodebook[], options: CodeBookContentSetting, missings: Missing[]): CodebookUnitDto[];
    static generateCodebook(units: UnitPropertiesForCodebook[], options: CodeBookContentSetting, missings: Missing[]): Promise<Blob>;
    private static isClosed;
    private static isManual;
    private static getVariable;
    private static getCode;
}

declare class CodebookDocxGenerator {
    private static ommlCache;
    static generateDocx(codingBookUnits: CodebookUnitDto[], contentSetting: CodeBookContentSetting): Promise<Blob>;
    private static getUnitHeader;
    private static getMissings;
    private static get TableBoarders();
    private static getCodeRows;
    private static createCellChildren;
    private static createCodeCell;
    private static setDocXDocument;
    private static getVariableHeader;
    private static getVariableItems;
    private static getGeneralInstructions;
    private static getCodeTable;
    private static getColumnWidths;
    private static getVariables;
    private static createDocXForUnit;
    private static getChildren;
    private static processInlineElements;
    private static getImageSize;
    private static getTransformation;
    private static createImagePragraph;
    private static createImageRun;
    private static inlineStyles;
    private static cssColor;
    private static getTextAlignment;
    private static stripFromLeadingEmptyParagraph;
    private static prepareHtml;
    private static decodeLatex;
    private static latexToOmml;
    /** The converter treats wide over/underlines as fixed-width accents and loses their position. */
    private static normalizeStretchyBars;
    /** Apply surrounding editor marks without changing cached LaTeX or unstyled Studio math. */
    private static styleMathRuns;
    private static unwrapImportedXmlRoot;
    private static isMathComponent;
    private static createLeftAlignedMathParagraph;
    private static normalizeParagraphChildren;
    private static sanitizeOmmlXml;
    private static escapeXmlText;
    private static normalizeMathTokens;
    /** Put loose text and inline marks into paragraphs without duplicating existing blocks. */
    private static wrapInlineParagraphs;
    private static htmlToDocx;
    /** Literal markers retain all CSS list styles, including Greek, in a static Word export. */
    private static listMarker;
    private static getFontSize;
    private static getAlignment;
    private static createParagraph;
    private static parseCssRgbString;
    private static toHex;
}

/** Rich-text instructions may consist entirely of an image or a formula. */
declare function hasCodebookManualInstruction(instruction?: string | null): boolean;

declare class CodebookGenerationError extends Error {
    name: string;
}

export { CodebookDocxGenerator, CodebookGenerationError, CodebookGenerator, hasCodebookManualInstruction };
