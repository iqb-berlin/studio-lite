import * as _iqb_ngx_coding_components_codebook_models from '@iqb/ngx-coding-components/codebook-models';
import { UnitSelectionItem, MissingsProfile, CodeBookContentSetting, CodebookExportConfig } from '@iqb/ngx-coding-components/codebook-models';
export * from '@iqb/ngx-coding-components/codebook-models';
import * as node_modules__angular_material_types__paginator_chunk from 'node_modules/@angular/material/types/_paginator-chunk';
import * as i0 from '@angular/core';
import { OnChanges, AfterViewInit, EventEmitter, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

declare const DEFAULT_CODEBOOK_OPTIONS: CodeBookContentSetting;
/** Studio's export form. Loading data, downloading and job handling belong to the host. */
declare class CodebookExportComponent implements OnChanges, AfterViewInit {
    availableUnits: UnitSelectionItem[];
    missingsProfiles: MissingsProfile[];
    selectedUnitIds: number[];
    selectedMissingsProfileId: number;
    defaultContentOptions: Partial<CodeBookContentSetting>;
    showGroupColumn: boolean;
    loading: boolean;
    busy: boolean;
    workspaceChanges: boolean;
    selectionChanged: EventEmitter<number[]>;
    exportRequested: EventEmitter<CodebookExportConfig>;
    cancel: EventEmitter<void>;
    sort: MatSort;
    dataSource: MatTableDataSource<UnitSelectionItem, node_modules__angular_material_types__paginator_chunk.MatPaginator>;
    columns: string[];
    selection: number[];
    filter: string;
    contentOptions: {
        exportFormat: "json" | "docx";
        missingsProfile: string;
        hasOnlyManualCoding: boolean;
        hasGeneralInstructions: boolean;
        hasDerivedVars: boolean;
        hasOnlyVarsWithCodes: boolean;
        hasClosedVars: boolean;
        codeLabelToUpper: boolean;
        showScore: boolean;
        hideItemVarRelation: boolean;
        trainingRequirement?: _iqb_ngx_coding_components_codebook_models.CodebookTrainingRequirementFilter;
    };
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    get allSelected(): boolean;
    get exportDisabled(): boolean;
    applyFilter(): void;
    toggle(unit: UnitSelectionItem): void;
    toggleAll(): void;
    exportCodingBook(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodebookExportComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodebookExportComponent, "ngx-codebook-export", never, { "availableUnits": { "alias": "availableUnits"; "required": false; }; "missingsProfiles": { "alias": "missingsProfiles"; "required": false; }; "selectedUnitIds": { "alias": "selectedUnitIds"; "required": false; }; "selectedMissingsProfileId": { "alias": "selectedMissingsProfileId"; "required": false; }; "defaultContentOptions": { "alias": "defaultContentOptions"; "required": false; }; "showGroupColumn": { "alias": "showGroupColumn"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "busy": { "alias": "busy"; "required": false; }; "workspaceChanges": { "alias": "workspaceChanges"; "required": false; }; }, { "selectionChanged": "selectionChanged"; "exportRequested": "exportRequested"; "cancel": "cancel"; }, never, ["[codebookFilters]", "[codebookStatus]"], true, never>;
}

export { CodebookExportComponent, DEFAULT_CODEBOOK_OPTIONS };
