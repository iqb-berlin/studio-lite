import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { CodingScheme } from '@iqbspecs/coding-scheme';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, OnChanges, EventEmitter, SimpleChanges, Injector } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSort } from '@angular/material/sort';
import { Response } from '@iqbspecs/response/response.interface';
import { VariableCodingData, CodeType, CodeData } from '@iqbspecs/coding-scheme/coding-scheme.interface';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { VariableInfo } from '@iqbspecs/variable-info/variable-info.interface';
import { CodingToTextMode, CodingSchemeProblem, CodingAsText } from '@iqb/responses';
export { NGX_CODING_COMPONENTS_DE_TRANSLATIONS, NgxCodingComponentsTranslateLoader } from '@iqb/ngx-coding-components/translations';
import { MatSelectionList } from '@angular/material/list';
import { Clipboard } from '@angular/cdk/clipboard';
import { MatSnackBar } from '@angular/material/snack-bar';

declare class SchemeCheckerComponent {
    private showCodingResultsDialog;
    values: {
        [Key in string]: string;
    };
    _codingScheme: CodingScheme | null;
    set codingScheme(value: CodingScheme | null);
    constructor(showCodingResultsDialog: MatDialog);
    private static parseInputValue;
    updateInputValue(sourceElement: EventTarget | null, targetVariable: string): void;
    startEvaluation(): void;
    protected readonly Object: ObjectConstructor;
    protected readonly JSON: JSON;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemeCheckerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SchemeCheckerComponent, "scheme-checker", never, { "codingScheme": { "alias": "codingScheme"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Data required when opening {@link ShowCodingResultsComponent} as a dialog.
 */
interface ShowCodingResultsData {
    responses: Response[];
    varsWithCodes: string[];
    variableCodings: VariableCodingData[];
}
declare class ShowCodingResultsComponent implements OnInit {
    data: ShowCodingResultsData;
    dataSource: MatTableDataSource<Record<string, unknown>>;
    displayedColumns: string[];
    isLoading: boolean;
    codedVariablesOnly: boolean;
    rawResponsesView: boolean;
    transformedValueView: boolean;
    constructor(data: ShowCodingResultsData);
    sort: MatSort;
    get transformedValuesAvailable(): boolean;
    matSort(sort: MatSort): void;
    ngOnInit(): void;
    private rebuildTableData;
    private mapResponseToRow;
    private static stringifyValue;
    private getTransformedValue;
    protected transformValue(value: Response['value'], fragmenting: string, sortArray: boolean): unknown;
    applyFilter(event: Event): void;
    toggleChange(event: MatSlideToggleChange): void;
    protected readonly JSON: JSON;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowCodingResultsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShowCodingResultsComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

type UserRoleType = 'RO' | 'RW_MINIMAL' | 'RW_MAXIMAL';
declare class SchemerService {
    private readonly _codingScheme;
    private readonly _varList;
    allVariableIds: string[];
    ruleMethodParameterCount: {
        MATCH: number;
        MATCH_REGEX: number;
        NUMERIC_MATCH: number;
        NUMERIC_RANGE: number;
        NUMERIC_FULL_RANGE: number;
        NUMERIC_LESS_THAN: number;
        NUMERIC_MORE_THAN: number;
        NUMERIC_MAX: number;
        NUMERIC_MIN: number;
        IS_EMPTY: number;
        IS_NULL: number;
        IS_TRUE: number;
        IS_FALSE: number;
    };
    private readonly _userRole;
    private readonly _copiedCode;
    private readonly _codingToTextMode;
    orderOfCodeTypes: CodeType[];
    get codingScheme(): CodingScheme | null;
    setCodingScheme(value: CodingScheme | null): void;
    get varList(): VariableInfo[];
    setVarList(value: VariableInfo[]): void;
    get userRole(): UserRoleType;
    setUserRole(value: UserRoleType): void;
    get copiedCode(): CodeData | null;
    setCopiedCode(value: CodeData | null): void;
    get codingToTextMode(): CodingToTextMode;
    setCodingToTextMode(value: CodingToTextMode): void;
    getVarInfoByCoding(varCoding: VariableCodingData): VariableInfo | undefined;
    copySingleCode(code: CodeData): boolean;
    canPasteSingleCodeInto(codeList: CodeData[]): boolean;
    getPasteSingleCodeWarningKeys(targetCoding?: VariableCodingData | null, targetVarInfo?: VariableInfo): string[];
    pasteSingleCode(codeList: CodeData[]): CodeData | string;
    getCodingProblemsForVarCoding(varCoding: VariableCodingData | null | undefined): CodingSchemeProblem[];
    addCode(codeList: CodeData[], codeType: CodeType): CodeData | string;
    deleteCode(codeList: CodeData[], codeIndex: number): boolean;
    duplicateCode(codeList: CodeData[], codeIndex: number): CodeData | string;
    sortCodes(codeList: CodeData[], normaliseCodeIds?: boolean): void;
    getVariableAliasById(varId: string): string;
    getVariableAliasByIdListString(varIds: string[], maxEntries: number): string;
    private getCopiedCode;
    getBaseVarsList(): VariableCodingData[];
    isProtectedBaseVariable(varCoding: VariableCodingData | null | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SchemerService>;
}

declare class VarCodingComponent implements OnInit, OnDestroy, OnChanges {
    schemerService: SchemerService;
    private sanitizer;
    private translateService;
    private editTextDialog;
    private showCodingDialog;
    private confirmDialog;
    private generateCodingDialog;
    private messageDialog;
    private editSourceParametersDialog;
    varCodingChanged: EventEmitter<VariableCodingData | null>;
    _varCoding: VariableCodingData | null;
    set varCoding(value: VariableCodingData | null);
    get varCoding(): VariableCodingData | null;
    lastChangeFrom$: BehaviorSubject<string>;
    lastChangeFromSubscription: Subscription | null;
    varInfo: VariableInfo | undefined;
    hasResidualAutoCode: boolean;
    hasIntendedIncompleteAutoCode: boolean;
    constructor(schemerService: SchemerService, sanitizer: DomSanitizer, translateService: TranslateService, editTextDialog: MatDialog, showCodingDialog: MatDialog, confirmDialog: MatDialog, generateCodingDialog: MatDialog, messageDialog: MatDialog, editSourceParametersDialog: MatDialog);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateVarInfo(): void;
    updateHasResidualAutoCode(): void;
    updateHasIntendedIncompleteAutoCode(): void;
    applySolverResidualAutoInstructionDefault(): void;
    getSanitizedText(text: string): SafeHtml;
    editTextDialog_manualInstruction(): void;
    wipeInstructions(): void;
    codingAsText(): void;
    deactivateBaseVar(): void;
    smartSchemer(event: MouseEvent): void;
    addCode(codeType: CodeType): void;
    canPasteSingleCode(): boolean;
    pasteSingleCode(): void;
    private performPasteSingleCode;
    private static getNewCodingProblems;
    private static getCodingProblemKey;
    private showPasteValidationWarning;
    editSourceParameters(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VarCodingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VarCodingComponent, "var-coding", never, { "varCoding": { "alias": "varCoding"; "required": false; }; }, { "varCodingChanged": "varCodingChanged"; }, never, never, true, never>;
}

declare class SchemerFacadeService {
    private schemerService;
    private dialog;
    private resolvingIdentifierConflicts;
    private dismissedIdentifierConflictSignature;
    private identifierConflictResolutionGeneration;
    private identifierConflictDialogRef;
    constructor(schemerService: SchemerService, dialog: MatDialog);
    setVarList(value: VariableInfo[]): void;
    resetIdentifierConflictResolutionState(): void;
    tryResolveIdentifierConflicts(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemerFacadeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SchemerFacadeService>;
}

declare const CYCLIC_DERIVATION_PROBLEM_TYPE = "CYCLIC_DERIVATION";
type CodingSchemeValidationProblemType = CodingSchemeProblem['type'] | typeof CYCLIC_DERIVATION_PROBLEM_TYPE;
interface CodingSchemeValidationProblem extends Omit<CodingSchemeProblem, 'type'> {
    type: CodingSchemeValidationProblemType;
}

declare class SchemerComponent implements OnDestroy {
    private translateService;
    schemerService: SchemerService;
    private schemerFacade;
    private messageDialog;
    private showCodingProblemsDialog;
    private showCodingSchemeDialog;
    private selectVariableDialog;
    private editSourceParametersDialog;
    private inputDialog;
    set varCodingElement(value: VarCodingComponent | undefined);
    codingSchemeChanged: EventEmitter<CodingScheme | null>;
    set codingScheme(value: CodingScheme | null);
    get codingScheme(): CodingScheme | null;
    set userRole(value: UserRoleType);
    set varList(value: any);
    get varList(): VariableInfo[];
    basicVariables: VariableCodingData[];
    derivedVariables: VariableCodingData[];
    codingStatus: {
        [id: string]: string;
    };
    selectedCoding$: BehaviorSubject<VariableCodingData | null>;
    problems: CodingSchemeValidationProblem[];
    hasIdentifierConflict: boolean;
    varCodingChangedSubscription: Subscription | null;
    constructor(translateService: TranslateService, schemerService: SchemerService, schemerFacade: SchemerFacadeService, messageDialog: MatDialog, showCodingProblemsDialog: MatDialog, showCodingSchemeDialog: MatDialog, selectVariableDialog: MatDialog, editSourceParametersDialog: MatDialog, inputDialog: MatDialog);
    private tr;
    showSchemerInfo(): void;
    updateVariableLists(): void;
    selectVarScheme(coding?: VariableCodingData | null): void;
    exportVariable(): Promise<void>;
    importVariable(): Promise<void>;
    private static isEmptyCoding;
    addVarScheme(): void;
    deleteVarScheme(): void;
    renameVarScheme(): void;
    activateBaseNoValueVars(): void;
    copyVarScheme(): void;
    checkVarScheme(): void;
    showCodingScheme(): void;
    variableDependencyTree(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SchemerComponent, "iqb-schemer", never, { "codingScheme": { "alias": "codingScheme"; "required": false; }; "userRole": { "alias": "userRole"; "required": false; }; "varList": { "alias": "varList"; "required": false; }; }, { "codingSchemeChanged": "codingSchemeChanged"; }, never, never, true, never>;
}

declare class SchemerStandaloneMenuComponent {
    codingScheme: CodingScheme | null;
    varList: VariableInfo[];
    userRole: UserRoleType;
    userRoleChanged: EventEmitter<UserRoleType>;
    codingSchemeChanged: EventEmitter<CodingScheme | null>;
    varListChanged: EventEmitter<VariableInfo[] | null>;
    saveCodingScheme(): void;
    loadVariables(): Promise<void>;
    loadCodingScheme(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemerStandaloneMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SchemerStandaloneMenuComponent, "schemer-standalone-menu", never, { "codingScheme": { "alias": "codingScheme"; "required": false; }; "varList": { "alias": "varList"; "required": false; }; "userRole": { "alias": "userRole"; "required": false; }; }, { "userRoleChanged": "userRoleChanged"; "codingSchemeChanged": "codingSchemeChanged"; "varListChanged": "varListChanged"; }, never, never, true, never>;
}

declare class ConfirmDialogComponent implements OnInit {
    confirmData: ConfirmDialogData;
    showCancel: boolean;
    constructor(confirmData: ConfirmDialogData);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
interface ConfirmDialogData {
    title: string;
    content: string;
    confirmButtonLabel: string;
    showCancel: boolean;
}

declare class ShowCodingProblemsDialogComponent {
    private codingProblems;
    codingProblemsGrouped: {
        [key: string]: CodingSchemeValidationProblem[];
    };
    allVariables: string[];
    constructor(codingProblems: CodingSchemeValidationProblem[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowCodingProblemsDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShowCodingProblemsDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

declare enum MessageType {
    error = 0,
    warning = 1,
    info = 2
}
declare class MessageDialogComponent implements OnInit {
    messageData: MessageDialogData;
    private translate;
    constructor(messageData: MessageDialogData, translate: TranslateService);
    ngOnInit(): void;
    private getDefaultTitle;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
interface MessageDialogData {
    type: MessageType;
    title: string;
    content: string;
    closeButtonLabel: string;
}

declare class SelectVariableDialogComponent implements OnInit {
    selectData: SelectVariableDialogData;
    dialogRef: MatDialogRef<SelectVariableDialogComponent>;
    variablesElement?: MatSelectionList;
    constructor(selectData: SelectVariableDialogData, dialogRef: MatDialogRef<SelectVariableDialogComponent>);
    ngOnInit(): void;
    getSelected(): string[];
    okButtonClick(): void;
    private setSelectedValues;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectVariableDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectVariableDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
interface SelectVariableDialogData {
    title: string;
    prompt: string;
    variables: VariableCodingData[];
    selectedVariable: VariableCodingData | null;
    codingStatus: {
        [id: string]: string;
    };
    okButtonLabel: string;
}

interface ShowCodingData {
    varCoding: VariableCodingData;
    mode: CodingToTextMode;
}
declare class ShowCodingDialogComponent {
    showCodingData: ShowCodingData;
    varCoding: VariableCodingData;
    varCodingText: CodingAsText | undefined;
    mode: CodingToTextMode | undefined;
    isSimpleMode: boolean;
    constructor(showCodingData: ShowCodingData);
    updateText(newValue: MatSlideToggleChange | boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowCodingDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShowCodingDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class SimpleInputDialogComponent implements OnInit {
    inputData: SimpleInputDialogData;
    showCancel: boolean;
    constructor(inputData: SimpleInputDialogData);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleInputDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleInputDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
interface SimpleInputDialogData {
    title: string;
    prompt: string;
    placeholder: string;
    saveButtonLabel: string;
    value: string;
    showCancel: boolean;
}

declare class CodingSchemeDialogComponent {
    private dialogRef;
    private clipboard;
    private snackBar;
    private translate;
    data: {
        codingScheme: unknown;
    };
    jsonData: string;
    constructor(dialogRef: MatDialogRef<CodingSchemeDialogComponent>, clipboard: Clipboard, snackBar: MatSnackBar, translate: TranslateService, data: {
        codingScheme: unknown;
    });
    onCopy(): void;
    onClose(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodingSchemeDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodingSchemeDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

type NgxCodingComponentsElementTagName = 'ngx-scheme-checker' | 'ngx-schemer' | 'ngx-schemer-standalone-menu' | 'ngx-var-coding' | 'ngx-codes-title' | 'ngx-single-code' | 'ngx-code-instruction' | 'ngx-code-rules' | 'ngx-code-rule-list' | 'ngx-rich-text-editor' | 'ngx-combo-button';
declare const NGX_CODING_COMPONENTS_ELEMENT_TAGS: Record<NgxCodingComponentsElementTagName, NgxCodingComponentsElementTagName>;
type RegisterNgxCodingComponentsElementsOptions = {
    prefix?: string;
};
declare const registerNgxCodingComponentsElements: (injector: Injector, options?: RegisterNgxCodingComponentsElementsOptions) => void;

export { CodingSchemeDialogComponent, ConfirmDialogComponent, MessageDialogComponent, MessageType, NGX_CODING_COMPONENTS_ELEMENT_TAGS, SchemeCheckerComponent, SchemerComponent, SchemerStandaloneMenuComponent, SelectVariableDialogComponent, ShowCodingDialogComponent, ShowCodingProblemsDialogComponent, ShowCodingResultsComponent, SimpleInputDialogComponent, VarCodingComponent, registerNgxCodingComponentsElements };
export type { ConfirmDialogData, MessageDialogData, NgxCodingComponentsElementTagName, RegisterNgxCodingComponentsElementsOptions, SelectVariableDialogData, ShowCodingData, ShowCodingResultsData, SimpleInputDialogData };
