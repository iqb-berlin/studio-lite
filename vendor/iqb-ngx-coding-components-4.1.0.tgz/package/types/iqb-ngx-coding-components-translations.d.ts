import { TranslateLoader } from '@ngx-translate/core';
import { Observable } from 'rxjs';

declare const NGX_CODING_COMPONENTS_DE_TRANSLATIONS: Record<string, unknown>;
declare class NgxCodingComponentsTranslateLoader implements TranslateLoader {
    getTranslation(): Observable<Record<string, unknown>>;
}

export { NGX_CODING_COMPONENTS_DE_TRANSLATIONS, NgxCodingComponentsTranslateLoader };
